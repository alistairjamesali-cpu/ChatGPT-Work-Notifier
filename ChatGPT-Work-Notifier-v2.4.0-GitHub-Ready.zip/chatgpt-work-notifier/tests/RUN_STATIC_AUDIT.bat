@echo off
setlocal
cd /d "%~dp0\.."
rem Prefer the Python launcher because the Windows Store python.exe alias may exist
rem without an installed Store package. Fall back to a directly installed Python.
py -3 -c "import sys" >nul 2>&1
if not errorlevel 1 (
  py -3 "%~dp0static-audit.py"
) else (
  python -c "import sys" >nul 2>&1
  if errorlevel 1 (
    echo ERROR: Python 3 is required to run the static audit.
    exit /b 1
  )
  python "%~dp0static-audit.py"
)
if errorlevel 1 exit /b 1
node --check service-worker.js
if errorlevel 1 exit /b 1
node --check content.js
if errorlevel 1 exit /b 1
node --check popup.js
if errorlevel 1 exit /b 1
echo.
echo STATIC AUDIT PASS
exit /b 0
