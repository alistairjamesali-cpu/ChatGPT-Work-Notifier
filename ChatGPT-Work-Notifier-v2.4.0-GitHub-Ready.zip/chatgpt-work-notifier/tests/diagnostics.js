(async () => {
  const params = new URL(location.href).searchParams;
  let action = null;
  if (params.has("moveTabId") && params.has("windowId")) {
    const tabId = Number(params.get("moveTabId"));
    const windowId = Number(params.get("windowId"));
    await chrome.tabs.move(tabId, { windowId, index: -1 });
    if (params.has("url")) await chrome.tabs.update(tabId, { url: params.get("url") });
    action = { moveTabId: tabId, windowId, ok: true };
  }
  const windows = await chrome.windows.getAll({ populate: true });
  const notifications = await chrome.notifications.getAll();
  const local = await chrome.storage.local.get({ managedWindowId: null, managedSessionToken: null, tabs: {}, events: [] });
  document.getElementById("output").textContent = JSON.stringify({ action, windows, notifications, ...local }, null, 2);
})();
