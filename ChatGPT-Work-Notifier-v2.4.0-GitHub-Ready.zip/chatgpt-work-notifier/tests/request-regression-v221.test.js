const fs = require('fs');
const path = require('path');
const assert = require('assert');
const E = require('../state-engine.js');

const root = path.join(__dirname, '..');
const content = fs.readFileSync(path.join(root, 'content.js'), 'utf8');
const sw = fs.readFileSync(path.join(root, 'service-worker.js'), 'utf8');
const tray = fs.readFileSync(path.join(root, 'runtime', 'tray-host.ps1'), 'utf8');

// Exact failure wording from the supplied timeout capture.
let r = E.classify({
  errorText: 'Message delivery timed out. Please try again.',
  assistantText: '100% complete.',
  stableMs: 60000,
  generationObserved: true
});
assert.strictEqual(r.status, 'TIMEOUT');
assert.strictEqual(r.safeCompletion, false);
assert.strictEqual(r.refreshEligible, true);

// Exact long-pause signature from the supplied 25m47s / 75% capture.
r = E.classify({
  assistantText: '75% complete. I have checked 175/175 questions individually.',
  workedText: 'Worked for 25m 47s',
  stableMs: 12000,
  generationObserved: true
});
assert.strictEqual(r.status, 'PAUSED');
assert.strictEqual(r.progress, 75);
assert.strictEqual(r.resumeEligible, true);
assert.strictEqual(r.safeCompletion, false);

// Supplied stuck-Thinking failure family.
r = E.classify({
  hasThinkingIndicator: true,
  hasStopButton: false,
  thinkingStableMs: E.constants.STUCK_THINKING_MS + 1,
  stableMs: E.constants.STUCK_THINKING_MS + 1,
  generationObserved: true
});
assert.strictEqual(r.status, 'STUCK_THINKING');
assert.strictEqual(r.resumeEligible, true);
assert.strictEqual(r.safeCompletion, false);


// Supplied September 3 running indicators: platform extended-thinking notice + active tool step/Stop control.
r = E.classify({
  hasExtendedThinkingBanner: true,
  hasActiveToolActivity: true,
  activeToolText: 'Inspecting Tests and Static Audits',
  hasStopButton: false,
  hasThinkingIndicator: true,
  thinkingStableMs: E.constants.STUCK_THINKING_MS + 60000,
  stableMs: E.constants.STUCK_THINKING_MS + 60000,
  generationObserved: true
});
assert.strictEqual(r.status, 'RUNNING');
assert.strictEqual(r.safeCompletion, false);
assert.strictEqual(r.resumeEligible, false);

r = E.classify({
  hasActiveToolActivity: true,
  activeToolText: 'Inspecting Tests and Static Audits',
  hasStopButton: true,
  stableMs: 600000,
  generationObserved: true
});
assert.strictEqual(r.status, 'RUNNING');

r = E.classify({
  hasActiveToolActivity: true,
  activeToolText: 'Inspecting Tests and Static Audits',
  hasStopButton: false,
  hasExtendedThinkingBanner: false,
  generationObserved: false,
  stableMs: 600000
});
assert.strictEqual(r.status, 'IDLE', 'historical tool-status text alone must not manufacture a fresh run');

assert.ok(content.includes('Our systems are thinking a bit more about this request before responding'));
assert.ok(content.includes("el.closest('[data-message-author-role=\"assistant\"],[data-message-author-role=\"user\"]')"), 'quoted banner text inside message bodies must not count as platform RUNNING evidence');
assert.ok(content.includes('activeToolStatusText'));
assert.ok(content.includes('hasExtendedThinkingBanner'));
assert.ok(content.includes('hasActiveToolActivity'));
assert.ok(content.includes('stop || thinking || extendedThinkingText || awaitingAssistant'));

// Explicit progress must not be contaminated by unrelated later percentages.
assert.strictEqual(E.parseProgressPercent('75% complete. Unit tests are 100% passing.'), 75);
assert.strictEqual(E.parseProgressPercent('Progress: 76%. Coverage: 100%.'), 76);
assert.strictEqual(E.parseProgressPercent('Coverage: 100%. Pass rate: 75%.'), null);

// Negated completion must fail closed.
r = E.classify({assistantText:'This is not 100% complete. Final verification remains.',stableMs:20000,generationObserved:true});
assert.notStrictEqual(r.status, 'COMPLETE');
assert.strictEqual(r.safeCompletion, false);


// Historical response DOM must not manufacture new completion/manual alerts after extension startup.
r = E.classify({ assistantText: '100% complete. Final ZIP is ready.', stableMs: 30000, generationObserved: false, workLike: true });
assert.strictEqual(r.status, 'IDLE');
assert.strictEqual(r.safeCompletion, false);
r = E.classify({ assistantText: 'This task remains incomplete. I still need to run the final tests.', stableMs: 30000, generationObserved: false, workLike: true });
assert.strictEqual(r.status, 'IDLE', 'historical incomplete text must not create a false Resume alert');
r = E.classify({ assistantText: '65% complete.', progressPercent: 65, hasCompletedResponseControls: true, stableMs: 30000, generationObserved: false, workLike: true });
assert.strictEqual(r.status, 'IDLE', 'finalized historical progress must not create a false Resume alert');
r = E.classify({ assistantText: '35% complete. The response stopped while working.', progressPercent: 35, stableMs: 30000, generationObserved: false, workLike: true });
assert.strictEqual(r.status, 'PAUSED', 'stable partial progress without finalized controls is a genuine resumable interruption');
r = E.classify({ assistantText: '35% complete. Connection interrupted while working.', progressPercent: 35, stableMs: 30000, generationObserved: false, workLike: true });
assert.strictEqual(r.status, 'TIMEOUT', 'explicit connection interruption remains timeout-priority and refresh-eligible');
r = E.classify({ assistantText: 'Finished historical answer.', hasContinueButton: true, stableMs: 30000, generationObserved: false, workLike: true });
assert.strictEqual(r.status, 'IDLE', 'a restored historical Continue control must not create a false Resume alert');

// Stable ended replies complete without requiring semantic phrases or user verification.
r = E.classify({ assistantText: 'Here is the finished answer.', stableMs: 12001, generationObserved: true, workLike: true });
assert.strictEqual(r.status, 'COMPLETE');
assert.strictEqual(r.safeCompletion, true);
r = E.classify({ assistantText: 'Here is the finished answer.', stableMs: 9000, generationObserved: true, workLike: false });
assert.strictEqual(r.status, 'COMPLETE');

r = E.classify({ assistantText: 'Here is the finished answer.', stableMs: 7000, generationObserved: true, workLike: true });
assert.strictEqual(r.status, 'RUNNING');

// Feature documentation mentioning Resume must not create a false PAUSED state.
r = E.classify({ assistantText: '100% complete. Resume prefill support is included and verified.', stableMs: 9000, generationObserved: true, workLike: true });
assert.strictEqual(r.status, 'COMPLETE');

// A finalized answer may discuss unfinished product code without meaning that ChatGPT paused.
const finishedAdvisory = 'The program code still needs to consume that field. The finished validation should explicitly confirm 276/276 topics loaded. That is the key check.';
r = E.classify({ assistantText: finishedAdvisory, hasCompletedResponseControls: true, stableMs: 9000, generationObserved: true, workLike: true });
assert.strictEqual(r.status, 'COMPLETE');
assert.strictEqual(r.resumeEligible, false);
r = E.classify({ assistantText: finishedAdvisory, stableMs: 13000, generationObserved: true, workLike: true });
assert.notStrictEqual(r.status, 'PAUSED', 'advisory statements about product code must not be interpreted as ChatGPT pausing');
r = E.classify({ assistantText: 'This task remains incomplete. I still need to run the final tests.', hasCompletedResponseControls: true, stableMs: 9000, generationObserved: true, workLike: true });
assert.strictEqual(r.status, 'PAUSED', 'explicit assistant work-status language must remain fail-closed');
r = E.classify({ assistantText: '65% complete.', progressPercent: 65, hasCompletedResponseControls: true, stableMs: 9000, generationObserved: true, workLike: true });
assert.strictEqual(r.status, 'PAUSED', 'a finalized action row must not override explicit partial task progress');

// Manual-action startup states must be emitted, not swallowed as baseline.
assert.ok(content.includes('if (result.manualAction || MANUAL_ACTION_STATUSES.has(result.status))'));
assert.ok(content.includes('forceNotification: true'));
assert.ok(content.includes('stop || thinking || extendedThinkingText || awaitingAssistant'));

// Background manual attention must be explicitly cleared only on recovery/action.
assert.ok(sw.includes('async function clearManualAttention'));
assert.ok(sw.includes('MANUAL_ACTION_STATUSES.has(previousStatus)'));
assert.ok(!content.includes('S.externalAttention && !["TIMEOUT","PAUSED","STUCK_THINKING","UNCERTAIN","WAITING_INPUT","FAILED"].includes(result.status)'));
assert.ok(content.includes('new Set(["PAUSED","STUCK_THINKING","WAITING_INPUT","FAILED"])'));
assert.ok(!content.includes('result.status === "UNCERTAIN" &&'));
assert.ok(!content.includes('S.externalAttention = { status: "CONNECTION_LOST"'));
assert.ok(sw.includes('async function recordOperationalFault'));
assert.ok(!sw.includes('async function raiseManualFromBackground'));

// Resume is prefilled only; it is never auto-submitted.
assert.ok(content.includes('safeSetContentEditable(c.editor, "Resume")'));
assert.ok(content.includes('safeSetTextarea(c.fallback, "Resume")'));
assert.ok(!content.includes('requestSubmit('));
assert.ok(!content.includes('new KeyboardEvent'));

// Windows manual-action popup is TopMost, does not close merely on Open, and queues concurrent incidents.
assert.ok(tray.includes('$popup.TopMost = $true'));
assert.ok(tray.includes('ManualPopupQueue'));
assert.ok(tray.includes('Add-ManualPopupQueue'));
assert.ok(tray.includes('$activeEvent = $script:PopupEvent'));
assert.ok(tray.includes('if (-not $activeEvent -or -not (Test-ManualPopupStatus'));
assert.ok(tray.includes('$wasManual = ($script:PopupEvent'));
assert.ok(tray.includes('Automatic managed-window recreation suppressed because a managed tab reports RUNNING.'));

// Automatic refresh remains timeout-only and draft/conversation protected.
assert.ok(sw.includes('automatic-refresh-is-timeout-only-in-v2.4.0'));
assert.ok(sw.includes('state.composerEmpty === false'));
assert.ok(sw.includes('sameConversation'));
assert.ok(sw.includes('MANUAL_ACTION_STATUSES.has(previousStatus) && !MANUAL_ACTION_STATUSES.has(status)'));
assert.ok(sw.includes('(data.tabs[String(tab.id)] || {}).title || tab.title || "ChatGPT"'));
assert.ok(sw.includes('REFRESH_COOLDOWN_MS = 15 * 60 * 1000'));
assert.ok(sw.includes('REFRESH_MAX_PER_WINDOW = 4'));

// Progress-only updates must reach storage/UI and latest activity must drive the popup.
assert.ok(content.includes('const progressChanged = result.progress !== (S.lastPayload?.progress ?? null)'));
assert.ok(content.includes('const partialCurrentTurn = Boolean(turnAfterUser && activeToolText && progress != null && progress < 100 && !completedResponseControls)'));
assert.ok(content.includes('|| partialCurrentTurn)'));
assert.ok(content.includes('const currentAssistant = assistantForTurn(currentTurn);'), 'progress text must bind to the active assistant turn instead of a trailing global assistant node');
const assistantForTurnSource = content.match(/function assistantForTurn\(turn\) \{[\s\S]*?\n  \}/)?.[0];
assert.ok(assistantForTurnSource, 'assistantForTurn helper must exist');
const assistantForTurn = Function('last', `return (${assistantForTurnSource});`)(list => list?.length ? list[list.length - 1] : null);
const activeMessage = { id: 'active-message' };
const activeTurn = { matches: () => false, querySelectorAll: () => [activeMessage] };
assert.strictEqual(assistantForTurn(activeTurn), activeMessage, 'active-turn assistant must be selected even when a later global decoy exists');
assert.ok(content.includes('const assistantText = assistantTextForTurn(currentTurn, currentAssistant);'));
const assistantTextForTurnSource = content.match(/function assistantTextForTurn\(turn, assistant\) \{[\s\S]*?\n  \}/)?.[0];
assert.ok(assistantTextForTurnSource, 'assistantTextForTurn helper must exist');
const assistantTextForTurn = Function('structuredText', `return (${assistantTextForTurnSource});`)(node => node?.innerText || node?.textContent || '');
assert.strictEqual(assistantTextForTurn({ innerText: '30% complete. Inspecting archive readiness.' }, { innerText: '' }), '30% complete. Inspecting archive readiness.', 'turn-level streaming commentary must supply progress when the assistant child is empty');
assert.strictEqual(assistantTextForTurn(null, { innerText: '65% complete.' }), '65% complete.', 'assistant child remains the fallback when a turn container is unavailable');
assert.strictEqual(assistantTextForTurn({ innerText: '30% — archive readiness\nInspecting tests' }, { innerText: '' }), '30% — archive readiness\nInspecting tests', 'turn text must preserve line-leading progress structure');
assert.ok(content.includes('const cont = hasContinueButton(currentTurn);'), 'Continue-generating evidence must be scoped to the current assistant turn');
assert.ok(content.includes('userSignature !== S.baselineUserSignature'), 'historical page hydration must not impersonate a newly submitted user prompt');
assert.ok(content.includes('S.baselineUserSignature = responseSignature(latestUserText());'), 'startup and terminal state must establish the user-message baseline');
assert.ok(content.includes('!S.baselineReady'), 'scans must remain inert until the startup user-message baseline is established');
assert.ok(content.indexOf('S.baselineReady = true;') < content.indexOf('const settings = await safeSendMessage({ type: "GET_SETTINGS" });'), 'startup baseline must be ready before the next asynchronous settings request');
assert.ok(content.includes('function hasCompletedResponseControls'));
assert.ok(content.includes('hasCompletedResponseControls: completedResponseControls'));
const canonicalPathSource = content.match(/function canonicalConversationPath\(value, base\) \{[\s\S]*?\n  \}/)?.[0];
const currentTitleSource = content.match(/function titleFromCurrentConversationLinks\(links, currentHref\) \{[\s\S]*?\n  \}/)?.[0];
assert.ok(canonicalPathSource && currentTitleSource, 'sidebar conversation-title helpers must exist');
const titleFromCurrentConversationLinks = Function(`${canonicalPathSource}\n${currentTitleSource}\nreturn titleFromCurrentConversationLinks;`)();
const link = (href, title, sidebar = true, current = false) => ({
  getAttribute: name => name === 'href' ? href : name === 'aria-current' && current ? 'page' : null,
  closest: () => sidebar ? {} : null,
  querySelector: () => null,
  innerText: title,
  textContent: title
});
assert.strictEqual(titleFromCurrentConversationLinks([
  link('/c/other', 'Canada Goose Size Advice'),
  link('/c/current', 'Combine learner status JSON', true, true),
  link('/c/current', 'Main content decoy', false, false)
], 'https://chatgpt.com/c/current'), 'Combine learner status JSON');
const popup = fs.readFileSync(path.join(root, 'popup.js'), 'utf8');
assert.ok(popup.includes('(b.updatedAt || b.lastStateChange || 0)'));

// v2.4 native current-task and percentage presentation contracts.
assert.ok(tray.includes('function Select-CurrentTask'));
assert.ok(tray.includes("'/dashboard-state' 'POST'"));
assert.ok(tray.includes('CURRENT CHATGPT TASK'));
assert.ok(tray.includes('$currentProgressTrack = New-Object System.Windows.Forms.Panel'));
assert.ok(tray.includes('$currentProgressFill = New-Object System.Windows.Forms.Panel'));
assert.ok(tray.includes('Current: RUNNING | % unavailable'));
assert.ok(tray.includes('function Set-TrayTooltip'));
assert.ok(tray.includes('$Text.Substring(0,63)'));
assert.ok(tray.includes('ALL MANAGED CHATGPT TABS'));
assert.ok(tray.includes('function Update-AllTabProgressPresentation'));
assert.ok(tray.includes('$allTabsHost.AutoScroll = $true'));
assert.ok(tray.includes('$row.Progress.Text = "$displayProgress%$estimateSuffix"'));
assert.ok(content.includes('cwn-progress-track'));
assert.ok(content.includes('cwn-progress-fill'));
assert.ok(content.includes('Working — % unavailable'));
assert.ok(sw.includes('safeCompletion: false'));
assert.ok(!sw.slice(sw.indexOf('async function forwardHeartbeat'), sw.indexOf('async function forwardLifecycle')).includes('addEvent('));

console.log('PASS request-regression-v221.test.js');
