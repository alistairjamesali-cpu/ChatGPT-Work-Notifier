$ErrorActionPreference = 'Stop'
$trayPath = Join-Path (Split-Path -Parent $PSScriptRoot) 'runtime\tray-host.ps1'
$tokens = $null
$errors = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile($trayPath, [ref]$tokens, [ref]$errors)
if ($errors.Count) { throw ($errors | ForEach-Object Message | Out-String) }
$definition = $ast.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Select-CurrentTask' }, $true)
if (-not $definition) { throw 'Select-CurrentTask was not found.' }
Invoke-Expression $definition.Extent.Text

function Assert-Selected([string]$Name, $State, $ExpectedTabId) {
  $selected = Select-CurrentTask $State
  $actual = if ($selected) { [int]$selected.tabId } else { $null }
  if ($actual -ne $ExpectedTabId) { throw "$Name selected tab $actual; expected $ExpectedTabId." }
  Write-Host "PASS: $Name"
}

$state = [pscustomobject]@{ browser = [pscustomobject]@{ tabs = @(
  [pscustomobject]@{ tabId=1; status='IDLE'; updatedAt=500; monitoringState='CONNECTED'; lastLifecycle='' },
  [pscustomobject]@{ tabId=2; status='RUNNING'; updatedAt=400; monitoringState='CONNECTED'; lastLifecycle='' },
  [pscustomobject]@{ tabId=3; status='PAUSED'; updatedAt=100; monitoringState='CONNECTED'; lastLifecycle='' }
) } }
Assert-Selected 'manual attention outranks running and managed states' $state 3

$state.browser.tabs += [pscustomobject]@{ tabId=4; status='WAITING_INPUT'; updatedAt=200; monitoringState='CONNECTED'; lastLifecycle='' }
Assert-Selected 'newest manual attention wins within rank' $state 4

$state.browser.tabs += [pscustomobject]@{ tabId=8; status='STUCK_THINKING'; updatedAt=200; monitoringState='CONNECTED'; lastLifecycle='' }
Assert-Selected 'highest numeric tab id breaks equal-rank time ties' $state 8

$state.browser.tabs += [pscustomobject]@{ tabId=99; status='FAILED'; updatedAt=9999; monitoringState='DETACHED'; lastLifecycle='NAVIGATED_AWAY' }
Assert-Selected 'detached task is ineligible' $state 8

$state.browser.tabs = @(
  [pscustomobject]@{ tabId=5; status='IDLE'; updatedAt=999; monitoringState='CONNECTED'; lastLifecycle='' },
  [pscustomobject]@{ tabId=6; status='RUNNING'; updatedAt=1; monitoringState='CONNECTED'; lastLifecycle='' }
)
Assert-Selected 'running outranks other managed state' $state 6

$empty = [pscustomobject]@{ browser = [pscustomobject]@{ tabs = @() } }
if ($null -ne (Select-CurrentTask $empty)) { throw 'Empty state must select no task.' }
Write-Host 'PASS: empty state selects no task'
Write-Host 'PASS TRAY_SELECTION_TEST.ps1'
