$ErrorActionPreference = 'Stop'
$installPath = Join-Path (Split-Path -Parent $PSScriptRoot) 'runtime\install.ps1'
$tokens = $null
$errors = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile($installPath, [ref]$tokens, [ref]$errors)
if ($errors.Count) { throw ($errors | ForEach-Object Message | Out-String) }
$definition = $ast.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Get-VerifiedNotifierRootFromCommandLine' }, $true)
if (-not $definition) { throw 'Get-VerifiedNotifierRootFromCommandLine was not found.' }
Invoke-Expression $definition.Extent.Text

function Assert-True([string]$Name, [bool]$Condition) {
  if (-not $Condition) { throw $Name }
  Write-Host "PASS: $Name"
}

$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('cwn-install-migration-' + [Guid]::NewGuid().ToString('N'))
$validRoot = Join-Path $tempRoot 'Valid Notifier'
$invalidRoot = Join-Path $tempRoot 'Unrelated'
try {
  New-Item -ItemType Directory -Path (Join-Path $validRoot 'runtime') -Force | Out-Null
  New-Item -ItemType File -Path (Join-Path $validRoot 'runtime\tray-host.ps1') -Force | Out-Null
  New-Item -ItemType File -Path (Join-Path $validRoot 'runtime\browser-bridge.ps1') -Force | Out-Null
  New-Item -ItemType File -Path (Join-Path $validRoot 'START_CHATGPT_WORK_NOTIFIER.bat') -Force | Out-Null
  [System.IO.File]::WriteAllText((Join-Path $validRoot 'manifest.json'), '{"manifest_version":3,"name":"ChatGPT Work Notifier","version":"2.3.0"}')

  $trayCommand = 'powershell.exe -NoProfile -File "' + (Join-Path $validRoot 'runtime\tray-host.ps1') + '"'
  $bridgeCommand = 'powershell.exe -File "' + (Join-Path $validRoot 'runtime\browser-bridge.ps1') + '" -SessionTokenFile "redacted"'
  Assert-True 'verified previous tray root is recognized' ((Get-VerifiedNotifierRootFromCommandLine $trayCommand) -eq [System.IO.Path]::GetFullPath($validRoot))
  Assert-True 'verified previous bridge root is recognized' ((Get-VerifiedNotifierRootFromCommandLine $bridgeCommand) -eq [System.IO.Path]::GetFullPath($validRoot))

  New-Item -ItemType Directory -Path (Join-Path $invalidRoot 'runtime') -Force | Out-Null
  New-Item -ItemType File -Path (Join-Path $invalidRoot 'runtime\tray-host.ps1') -Force | Out-Null
  Assert-True 'same-name unrelated script without product root is rejected' ($null -eq (Get-VerifiedNotifierRootFromCommandLine ('powershell.exe -File "' + (Join-Path $invalidRoot 'runtime\tray-host.ps1') + '"')))

  New-Item -ItemType File -Path (Join-Path $invalidRoot 'runtime\browser-bridge.ps1') -Force | Out-Null
  New-Item -ItemType File -Path (Join-Path $invalidRoot 'START_CHATGPT_WORK_NOTIFIER.bat') -Force | Out-Null
  [System.IO.File]::WriteAllText((Join-Path $invalidRoot 'manifest.json'), '{"manifest_version":3,"name":"Unrelated Program"}')
  Assert-True 'wrong manifest identity is rejected' ($null -eq (Get-VerifiedNotifierRootFromCommandLine ('powershell.exe -File "' + (Join-Path $invalidRoot 'runtime\tray-host.ps1') + '"')))
  Assert-True 'command without File argument is rejected' ($null -eq (Get-VerifiedNotifierRootFromCommandLine 'powershell.exe tray-host.ps1'))
  Write-Host 'PASS INSTALL_MIGRATION_TEST.ps1'
} finally {
  if (Test-Path -LiteralPath $tempRoot) { Remove-Item -LiteralPath $tempRoot -Recurse -Force }
}
