const assert = require('assert');
const E = require('../state-engine.js');

assert.strictEqual(E.parseProgressPercent('25% complete. later 75% complete.'),75,'last textual progress wins');
assert.strictEqual(E.parseProgressPercent('Progress: 80% then correction progress: 65%'),65);
assert.strictEqual(E.parseProgressPercent('75% complete. Tests are now 100% passing.'),75,'explicit progress marker must beat unrelated generic percentages');
assert.strictEqual(E.parseProgressPercent('Progress: 62%. Coverage reached 100%.'),62,'explicit progress field must beat later coverage percentages');
assert.strictEqual(E.parseProgressPercent('Coverage reached 100%. Accuracy is 75%.'),null,'generic percentages are display noise, not task progress');
assert.strictEqual(E.parseProgressPercent('\n76% — integration complete'),76,'line-leading progress headings are accepted');
assert.strictEqual(E.parseWorkedSeconds('Worked for 25m 47s'),1547);

let r=E.classify({errorText:'Message delivery timed out. Please try again.',assistantText:'100% complete',stableMs:20000});
assert.strictEqual(r.status,'TIMEOUT'); assert.strictEqual(r.safeCompletion,false);

r=E.classify({assistantText:'75% complete. More work remains.',workedText:'Worked for 25m 47s',stableMs:12000,generationObserved:true});
assert.strictEqual(r.status,'PAUSED'); assert.strictEqual(r.resumeEligible,true); assert.strictEqual(r.safeCompletion,false);

r=E.classify({hasThinkingIndicator:true,hasStopButton:false,thinkingStableMs:120001,stableMs:120001,generationObserved:true});
assert.strictEqual(r.status,'STUCK_THINKING'); assert.strictEqual(r.resumeEligible,true);

r=E.classify({hasThinkingIndicator:true,hasStopButton:true,thinkingStableMs:999999,generationObserved:true});
assert.strictEqual(r.status,'RUNNING');


r=E.classify({
  hasExtendedThinkingBanner:true,
  hasActiveToolActivity:true,
  activeToolText:'Inspecting Tests and Static Audits',
  hasStopButton:false,
  hasThinkingIndicator:true,
  thinkingStableMs:E.constants.STUCK_THINKING_MS+60000,
  stableMs:E.constants.STUCK_THINKING_MS+60000,
  generationObserved:true
});
assert.strictEqual(r.status,'RUNNING','platform extended-thinking banner plus active tool work is positive RUNNING evidence');
assert.strictEqual(r.safeCompletion,false);
assert.strictEqual(r.resumeEligible,false);

r=E.classify({
  hasExtendedThinkingBanner:true,
  hasActiveToolActivity:false,
  hasStopButton:false,
  hasThinkingIndicator:false,
  stableMs:300000,
  generationObserved:true
});
assert.strictEqual(r.status,'RUNNING','the platform extended-thinking banner alone blocks false pause/stuck/completion');

r=E.classify({
  hasActiveToolActivity:true,
  activeToolText:'Inspecting Tests and Static Audits',
  hasStopButton:true,
  stableMs:300000,
  generationObserved:true
});
assert.strictEqual(r.status,'RUNNING','active tool status plus visible Stop control is definitively running');

r=E.classify({
  errorText:'Message delivery timed out. Please try again.',
  hasExtendedThinkingBanner:true,
  hasActiveToolActivity:true,
  activeToolText:'Inspecting Tests and Static Audits',
  generationObserved:true
});
assert.strictEqual(r.status,'TIMEOUT','explicit timeout remains higher priority than stale running indicators');


r=E.classify({assistantText:'This is not 100% complete. More validation is required.',stableMs:20000,generationObserved:true});
assert.notStrictEqual(r.status,'COMPLETE','negated 100% completion must never pass the completion gate');
assert.strictEqual(r.safeCompletion,false);

r=E.classify({assistantText:'Do not treat this as complete. The package still needs final verification.',stableMs:20000,generationObserved:true});
assert.notStrictEqual(r.status,'COMPLETE','explicit do-not-treat-as-complete wording must block completion');

r=E.classify({assistantText:'100% complete. Final ZIP is ready.',stableMs:8001,generationObserved:true});
assert.strictEqual(r.status,'COMPLETE'); assert.strictEqual(r.safeCompletion,true);

r=E.classify({assistantText:'Here is the finished answer.',stableMs:9000,generationObserved:true,workLike:false});
assert.strictEqual(r.status,'COMPLETE','non-work replies may complete from normal observed generation');

r=E.classify({assistantText:'Here is the finished answer.',stableMs:9000,generationObserved:true,workLike:true});
assert.strictEqual(r.status,'COMPLETE','a stable ended work reply completes without manual semantic verification');
assert.strictEqual(r.safeCompletion,true,'stable ended work reply carries completion proof');
r=E.classify({assistantText:'Here is the finished answer.',stableMs:12001,generationObserved:true,workLike:true});
assert.strictEqual(r.status,'COMPLETE','a stable ended work reply must never degrade into manual verification');

r=E.classify({assistantText:'Here is the finished answer.',stableMs:7999,generationObserved:true,workLike:true});
assert.strictEqual(r.status,'RUNNING','an ended reply must remain settling until the stability window passes');

r=E.classify({assistantText:'Old answer',priorProgressPercent:75,stableMs:9000,generationObserved:false});
assert.strictEqual(r.status,'IDLE','historical response text is display-only and cannot create a fresh completion/manual alert');

r=E.classify({assistantText:'This task remains incomplete. I still need to run tests.',stableMs:20000,generationObserved:false});
assert.strictEqual(r.status,'IDLE','historical incomplete wording must not resurrect a false Resume incident');

r=E.classify({assistantText:'65% complete.',progressPercent:65,hasCompletedResponseControls:true,stableMs:20000,generationObserved:false});
assert.strictEqual(r.status,'IDLE','finalized historical partial progress must not resurrect a false Resume incident');

r=E.classify({assistantText:'35% complete. The response stopped while working.',progressPercent:35,stableMs:20000,generationObserved:false});
assert.strictEqual(r.status,'PAUSED','stable partial progress without finalized controls is a genuine resumable interruption');

r=E.classify({assistantText:'35% complete. Connection interrupted while working.',progressPercent:35,stableMs:20000,generationObserved:false});
assert.strictEqual(r.status,'TIMEOUT','explicit connection interruption remains timeout-priority');

r=E.classify({assistantText:'65% complete.',progressPercent:65,stableMs:7999,generationObserved:true});
assert.strictEqual(r.status,'RUNNING','partial progress must settle before Resume is offered');

r=E.classify({assistantText:'Old answer',hasContinueButton:true,stableMs:20000,generationObserved:false});
assert.strictEqual(r.status,'IDLE','a restored historical Continue control must not resurrect Resume');

r=E.classify({assistantText:'Current answer',hasContinueButton:true,stableMs:7999,generationObserved:true});
assert.strictEqual(r.status,'RUNNING','a current Continue control must settle before Resume is offered');

r=E.classify({assistantText:'Current answer',hasContinueButton:true,stableMs:8001,generationObserved:true});
assert.strictEqual(r.status,'PAUSED','a stable Continue control from an observed current run remains actionable');

r=E.classify({assistantText:'100% complete. Old completed run.',stableMs:20000,generationObserved:false});
assert.strictEqual(r.status,'IDLE','historical 100% text cannot manufacture a fresh completion event after startup');

r=E.classify({assistantText:'100% complete',awaitingAssistant:true,stableMs:20000,generationObserved:true});
assert.strictEqual(r.status,'RUNNING','newer user prompt suppresses old completion evidence');

r=E.classify({assistantText:'Please upload the file so I can continue.',waitingInput:true,stableMs:9000,generationObserved:true});
assert.strictEqual(r.status,'WAITING_INPUT'); assert.strictEqual(r.manualAction,true);

r=E.classify({assistantText:'100% complete. Resume prefill support was implemented and verified.',stableMs:9000,generationObserved:true,workLike:true});
assert.strictEqual(r.status,'COMPLETE','mentioning Resume as a feature must not falsely classify a completed job as paused');

console.log('PASS state-engine-v221.test.js');
