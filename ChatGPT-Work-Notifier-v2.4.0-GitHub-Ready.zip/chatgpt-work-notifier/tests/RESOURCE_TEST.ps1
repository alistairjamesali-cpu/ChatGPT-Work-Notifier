param(
  [ValidateSet(1,5,10,20)][int]$ExpectedTabCount = 1,
  [int]$SampleSeconds = 5
)

$ErrorActionPreference='SilentlyContinue'
$root=Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$rootNeedle=$root.ToLowerInvariant()
$bridge=$null
try { $bridge=Invoke-RestMethod 'http://127.0.0.1:38765/state' -TimeoutSec 2 } catch {}
$actual = if($bridge){[int]$bridge.browser.tabCount}else{0}

function Get-NotifierProcesses {
  return @(Get-CimInstance Win32_Process | Where-Object {
    $_.Name -eq 'powershell.exe' -and $_.CommandLine -and $_.CommandLine.ToLowerInvariant().Contains($rootNeedle) -and ($_.CommandLine -like '*tray-host.ps1*' -or $_.CommandLine -like '*browser-bridge.ps1*')
  })
}

$before=@{}
foreach($p in Get-NotifierProcesses){
  try {
    $proc=Get-Process -Id $p.ProcessId
    $before[$p.ProcessId]=[ordered]@{ cpu=$proc.CPU; ws=$proc.WorkingSet64; name=if($p.CommandLine -like '*tray-host.ps1*'){'tray-host'}else{'browser-bridge'} }
  } catch {}
}
Start-Sleep -Seconds $SampleSeconds

$rows=@()
foreach($id in @($before.Keys)){
  try {
    $proc=Get-Process -Id $id
    $b=$before[$id]
    $cpuDelta=[double]$proc.CPU-[double]$b.cpu
    $cpuPct=[math]::Round(($cpuDelta/[math]::Max(1,$SampleSeconds))*100/[Environment]::ProcessorCount,2)
    $rows += [ordered]@{
      process=$b.name; pid=$id; workingSetMB=[math]::Round($proc.WorkingSet64/1MB,1); averageCpuPercent=$cpuPct
    }
  } catch {}
}

$result=[ordered]@{
  expectedChatGPTTabs=$ExpectedTabCount
  actualTrackedTabs=$actual
  tabCountMatch=($actual -eq $ExpectedTabCount)
  sampleSeconds=$SampleSeconds
  notifierProcesses=$rows
  note='Chrome process memory is intentionally excluded. This measures notifier PowerShell processes only.'
}
$result | ConvertTo-Json -Depth 6
if($actual -ne $ExpectedTabCount){ exit 2 }
