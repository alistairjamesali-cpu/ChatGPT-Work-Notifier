$ErrorActionPreference = 'Stop'
$base='http://127.0.0.1:38765'
$runtimeBase=Join-Path $env:LOCALAPPDATA 'ChatGPT Work Notifier'
$managedStateFile=Join-Path $runtimeBase 'managed-window.json'
$origin='chrome-extension://aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
$rows=New-Object System.Collections.ArrayList
function Add([string]$Name,[bool]$Pass,[string]$Detail){ [void]$rows.Add([ordered]@{name=$Name;pass=$Pass;detail=$Detail}) }
function Expect-Rejected([string]$Path,$Headers,$Body){
  try { Invoke-WebRequest ($base+$Path) -UseBasicParsing -Method Post -Headers $Headers -ContentType 'application/json' -Body $Body -TimeoutSec 2 | Out-Null; return $false }
  catch { return ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -in @(400,401,403)) }
}
$state=Invoke-RestMethod ($base+'/state') -TimeoutSec 2
$stateJson=$state|ConvertTo-Json -Depth 10 -Compress
Add 'Public state omits tab URL' (-not $stateJson.Contains('"url"')) 'Unauthenticated local state must not expose ChatGPT URLs.'
Add 'Public state omits conversationId' (-not $stateJson.Contains('conversationId')) 'Unauthenticated local state must not expose conversation identifiers.'
$event='{"tabId":-77,"windowId":-77,"status":"RUNNING","title":"security-test","url":"","conversationId":null,"progress":1,"runSeconds":1,"showPopup":false,"transient":true,"at":1}'
Add 'No-origin event rejected' (Expect-Rejected '/browser-event' @{} $event) 'Browser event requires extension origin and token.'
Add 'Wrong-token event rejected' (Expect-Rejected '/browser-event' @{Origin=$origin;'X-CWN-Token'=('0'*32)} $event) 'Wrong session token must fail.'
Add 'Unauthenticated repair control rejected' (Expect-Rejected '/request-repair' @{} '{}') 'Local state-changing control requires the session token.'
Add 'Wrong-token diagnostic control rejected' (Expect-Rejected '/diagnostic-ping' @{'X-CWN-Token'=('0'*32)} '{}') 'Diagnostic command injection with a forged token must fail.'
if(-not (Test-Path -LiteralPath $managedStateFile)){ throw 'managed-window.json missing' }
$managed=Get-Content -LiteralPath $managedStateFile -Raw|ConvertFrom-Json
$token=[string]$managed.token
if($token -notmatch '^[a-f0-9]{32}$'){ throw 'managed token invalid' }
$headers=@{Origin=$origin;'X-CWN-Token'=$token}
$validBody=@{token=$token}|ConvertTo-Json -Compress
$valid=Invoke-RestMethod ($base+'/validate-session') -Method Post -Headers $headers -ContentType 'application/json' -Body $validBody -TimeoutSec 2
Add 'Correct token validates' ([bool]$valid.ok) 'The active managed-session token must validate.'
$bad=Expect-Rejected '/validate-session' @{Origin=$origin;'X-CWN-Token'=('f'*32)} '{"token":"ffffffffffffffffffffffffffffffff"}'
Add 'Wrong token validation rejected' $bad 'Forged token must not validate.'
$fails=@($rows|Where-Object{-not $_.pass})
[ordered]@{version='2.4.0';generatedAt=(Get-Date).ToUniversalTime().ToString('o');pass=($fails.Count -eq 0);checks=$rows}|ConvertTo-Json -Depth 8
if($fails.Count){exit 1}
