const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const CWNCore = require('../reliability-core.js');

const listeners = {};
function evt(name) {
  return { addListener(fn) { (listeners[name] ||= []).push(fn); } };
}
const local = { events: [], tabs: {}, managedWindowId: null, managedSessionToken: null };
const sync = {};
const tabMap = new Map();
const notificationCalls = [];
const updateCalls = [];
const windowUpdates = [];
const tabMessages = [];
const tabClosedCalls = [];
const heartbeatCalls = [];
const alarmCalls = [];
const reloadCalls = [];
const probeStates = new Map();
let bridgeCommand = null;
const bridgeTabs = new Set();
let failTabUpdates = false;
let failTabQuery = false;
let failWindowQuery = false;
let commandAck = null;
let storageLatencyMs = 0;
let browserEventFailuresRemaining = 0;
let browserEventAttempts = 0;
const MANAGED_TOKEN = '0123456789abcdef0123456789abcdef';
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

for (let i = 1; i <= 20; i++) {
  const windowId = 100;
  tabMap.set(i, { id:i, windowId, url:`https://chatgpt.com/c/conversation-${i}`, title:`Chat ${i}`, autoDiscardable:true, discarded:false });
}

const chrome = {
  runtime: { onInstalled:evt('runtime.onInstalled'), onStartup:evt('runtime.onStartup'), onMessage:evt('runtime.onMessage'), sendMessage:async()=>({}) },
  storage: {
    local: {
      async get(defaults={}) { if (storageLatencyMs) await sleep(storageLatencyMs); return { ...defaults, ...structuredClone(local) }; },
      async set(values) { if (storageLatencyMs) await sleep(storageLatencyMs); Object.assign(local, structuredClone(values)); }
    },
    sync: {
      async get(defaults={}) { return { ...defaults, ...structuredClone(sync) }; },
      async set(values) { Object.assign(sync, structuredClone(values)); }
    }
  },
  tabs: {
    onUpdated:evt('tabs.onUpdated'), onActivated:evt('tabs.onActivated'), onDetached:evt('tabs.onDetached'), onAttached:evt('tabs.onAttached'), onReplaced:evt('tabs.onReplaced'), onRemoved:evt('tabs.onRemoved'),
    async get(id) { if (!tabMap.has(id)) throw new Error('missing'); return structuredClone(tabMap.get(id)); },
    async query(q) { if (failTabQuery || (failWindowQuery && q.windowId != null)) throw new Error('query unavailable'); return [...tabMap.values()].filter(t => q.windowId == null || t.windowId === q.windowId).map(t => structuredClone(t)); },
    async update(id, patch) { const t=tabMap.get(id); if(!t) throw new Error('missing'); Object.assign(t, patch); updateCalls.push({id,patch}); return structuredClone(t); },
    async sendMessage(id, message) {
      tabMessages.push({id,message:structuredClone(message)});
      if (message?.type === 'CWN_PROBE_STATE') return { ok:true, state:structuredClone(probeStates.get(id) || null) };
      return {};
    },
    async reload(id, options) { reloadCalls.push({id,options:structuredClone(options || {})}); return {}; }
  },
  windows: { onRemoved:evt('windows.onRemoved'), async update(id, patch){ windowUpdates.push({id,patch}); return {}; } },
  notifications: { onClicked:evt('notifications.onClicked'), async create(id, opts){ notificationCalls.push({id,opts}); return id; }, async clear(){ return true; } },
  action: { async setBadgeText(){}, async setBadgeBackgroundColor(){} },
  alarms: { onAlarm:evt('alarms.onAlarm'), async get(){ return null; }, create(name, options){ alarmCalls.push({name,options:structuredClone(options || {})}); }, async clear(){ return true; } }
};

async function fetchMock(url, options={}) {
  const u = new URL(url);
  let body = {};
  try { body = options.body ? JSON.parse(options.body) : {}; } catch {}
  const headers = new Headers(options.headers || {});
  const protectedPaths = new Set(['/validate-session','/command','/command-ack','/browser-event','/browser-heartbeat','/browser-lifecycle','/browser-tab-closed','/browser-tabs-sync','/show-managed-window']);
  if (protectedPaths.has(u.pathname) && headers.get('X-CWN-Token') !== MANAGED_TOKEN) return { ok:false, status:403, async json(){ return {ok:false}; } };
  if (u.pathname === '/validate-session') return response({ok:body.token===MANAGED_TOKEN,version:'2.4.0'});
  if (u.pathname === '/config') return response({ok:true,config:{monitoringEnabled:true,allowControlledStaleRecovery:true,autoRepairConnection:true}});
  if (u.pathname === '/command') return response({ok:true,command:bridgeCommand});
  if (u.pathname === '/command-ack') { commandAck = body; bridgeCommand = null; return response({ok:true}); }
  if (u.pathname === '/state') return response({ok:true,mode:'CHROME_ONLY',version:'2.4.0',browser:{tabCount:Object.keys(local.tabs).length}});
  if (['/browser-event', '/browser-heartbeat', '/browser-lifecycle'].includes(u.pathname) && body.tabId >= 0) bridgeTabs.add(body.tabId);
  if (u.pathname === '/browser-tabs-sync') {
    if (failTabUpdates) throw new Error('bridge unavailable');
    for (const id of bridgeTabs) if (!body.tabIds.includes(id)) bridgeTabs.delete(id);
    return response({ok:true});
  }
  if (u.pathname === '/browser-event') {
    browserEventAttempts++;
    if (browserEventFailuresRemaining > 0) {
      browserEventFailuresRemaining--;
      return { ok:false, status:503, async json(){ return {ok:false}; } };
    }
    return response({ok:true});
  }
  if (u.pathname === '/browser-tab-closed') { if (failTabUpdates) throw new Error('bridge unavailable'); bridgeTabs.delete(body.tabId); tabClosedCalls.push(body); return response({ok:true}); }
  if (u.pathname === '/browser-heartbeat') { heartbeatCalls.push(body); return response({ok:true}); }
  return response({ok:true});
}
function response(obj){ return { ok:true, status:200, async json(){ return structuredClone(obj); } }; }

const context = {
  chrome, CWNCore, console, URL, Headers, AbortController, setTimeout, clearTimeout, structuredClone,
  importScripts(){}, fetch:fetchMock, Map, Set, Date, Number, Boolean, String, Math, Promise
};
vm.createContext(context);
const source = fs.readFileSync(path.join(__dirname,'..','service-worker.js'),'utf8');
vm.runInContext(source, context, { filename:'service-worker.js' });

function invokeMessage(message, sender) {
  const fn = listeners['runtime.onMessage'][0];
  return new Promise((resolve,reject)=>{
    let returned;
    try { returned = fn(message,sender,(value)=>resolve(value)); } catch(e){ reject(e); return; }
    if (returned !== true) resolve(undefined);
    setTimeout(()=>reject(new Error('sendResponse timeout')),1500);
  });
}

(async()=>{
  const first = tabMap.get(1);
  let r = await invokeMessage({type:'REGISTER_MANAGED_WINDOW',token:'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'},{tab:structuredClone(first)});
  assert.strictEqual(r.ok,false,'untrusted but well-formed managed token must be rejected by bridge validation');
  assert.strictEqual(local.managedWindowId,null,'rejected token must not mutate managed window state');
  r = await invokeMessage({type:'REGISTER_MANAGED_WINDOW',token:MANAGED_TOKEN},{tab:structuredClone(first)});
  assert.strictEqual(r.ok,true);
  assert.strictEqual(local.managedWindowId,100);
  r = await invokeMessage({type:'AUTOPILOT_CHECK',url:first.url},{tab:structuredClone(first)});
  assert.strictEqual(r.allowed,true,'autopilot defaults on in the managed window');
  sync.autoResume=false;
  r = await invokeMessage({type:'AUTOPILOT_CHECK',url:first.url},{tab:structuredClone(first)});
  assert.strictEqual(r.allowed,false,'autopilot off switch blocks automatic sending');
  sync.autoResume=true;
  first.windowId=101;
  r = await invokeMessage({type:'AUTOPILOT_CHECK',url:first.url},{tab:{...first,windowId:100}});
  assert.strictEqual(r.allowed,false,'live window ownership wins over stale sender metadata');
  first.windowId=100;
  r = await invokeMessage({type:'AUTOPILOT_CHECK',url:'https://chatgpt.com/c/other'},{tab:structuredClone(first)});
  assert.strictEqual(r.allowed,false,'navigation cancels automatic sending');


  for (let i=1;i<=20;i++) {
    const tab = structuredClone(tabMap.get(i));
    r = await invokeMessage({type:'STATE',status:'RUNNING',chatTitle:tab.title,pageFocused:false,progress:i,runSeconds:30,workLike:true,url:tab.url,forceEvent:true},{tab});
    assert.strictEqual(r.ok,true);
  }
  assert.strictEqual(Object.keys(local.tabs).length,20,'20 independent records expected inside the managed window');
  for (let i=1;i<=20;i++) assert.strictEqual(tabMap.get(i).autoDiscardable,false,`tab ${i} must be protected from discard`);

  // Independent state transition on one tab must not overwrite the others.
  await invokeMessage({type:'STATE',status:'COMPLETE',safeCompletion:true,chatTitle:'Chat 7',pageFocused:false,runSeconds:120,workLike:true,url:tabMap.get(7).url,forceEvent:true},{tab:structuredClone(tabMap.get(7))});
  assert.strictEqual(local.tabs['7'].status,'COMPLETE');
  assert.strictEqual(local.tabs['7'].safeCompletion,true);
  assert.strictEqual(local.tabs['8'].status,'RUNNING');
  await invokeMessage({type:'STATE',status:'RUNNING',safeCompletion:true,chatTitle:'Chat 7',pageFocused:false,progress:null,messageId:'new-task-7',runSeconds:1,workLike:true,url:tabMap.get(7).url,forceEvent:true},{tab:structuredClone(tabMap.get(7))});
  assert.strictEqual(local.tabs['7'].safeCompletion,false,'new task must not inherit safe-completion proof');
  assert.strictEqual(local.tabs['7'].progress,null,'new task must not inherit old task percentage');
  assert.strictEqual(local.tabs['7'].notificationState,null,'new task must not inherit prior COMPLETE notification state');
  assert.ok(Number.isFinite(local.tabs['7'].updatedAt),'multi-tab current-selection input must include updatedAt');
  // Fail-closed gate: a bare COMPLETE without safeCompletion proof is downgraded.
  await invokeMessage({type:'STATE',status:'COMPLETE',chatTitle:'Chat 9',pageFocused:false,runSeconds:30,workLike:true,url:tabMap.get(9).url,forceEvent:true},{tab:structuredClone(tabMap.get(9))});
  assert.strictEqual(local.tabs['9'].status,'UNCERTAIN','unsafe COMPLETE must be rejected');
  const beforeNotifications = notificationCalls.length;
  await invokeMessage({type:'STATE',status:'COMPLETE',safeCompletion:true,chatTitle:'Chat 7',pageFocused:false,runSeconds:121,workLike:true,url:tabMap.get(7).url,forceEvent:true},{tab:structuredClone(tabMap.get(7))});
  assert.strictEqual(notificationCalls.length,beforeNotifications,'duplicate same-state notification must be suppressed');

  // A transient bridge failure must not permanently consume a desktop alert.
  await invokeMessage({type:'STATE',status:'RUNNING',chatTitle:'Chat 12',pageFocused:false,runSeconds:30,workLike:true,url:tabMap.get(12).url,forceEvent:true},{tab:structuredClone(tabMap.get(12))});
  browserEventFailuresRemaining = 1;
  const attemptsBeforeRetry = browserEventAttempts;
  const notificationsBeforeRetry = notificationCalls.length;
  await invokeMessage({type:'STATE',status:'COMPLETE',safeCompletion:true,chatTitle:'Chat 12',pageFocused:false,runSeconds:31,workLike:true,url:tabMap.get(12).url},{tab:structuredClone(tabMap.get(12))});
  assert.notStrictEqual(local.tabs['12'].notificationState,'COMPLETE','failed bridge delivery must remain pending');
  assert.strictEqual(notificationCalls.length,notificationsBeforeRetry,'secondary notification must wait for authoritative tray delivery');
  await invokeMessage({type:'STATE',status:'COMPLETE',safeCompletion:true,chatTitle:'Chat 12',pageFocused:false,runSeconds:32,workLike:true,url:tabMap.get(12).url},{tab:structuredClone(tabMap.get(12))});
  assert.strictEqual(browserEventAttempts,attemptsBeforeRetry+2,'same-state completion must retry bridge delivery');
  assert.strictEqual(local.tabs['12'].notificationState,'COMPLETE','successful retry must commit notification delivery');
  assert.strictEqual(notificationCalls.length,notificationsBeforeRetry+1,'successful retry must emit one secondary notification');

  // Manual page attention must explicitly clear after the user action moves the same tab back to a healthy state.
  await invokeMessage({type:'STATE',status:'PAUSED',manualAction:true,chatTitle:'Chat 10',pageFocused:true,progress:75,workLike:true,url:tabMap.get(10).url,forceEvent:true},{tab:structuredClone(tabMap.get(10))});
  assert.ok(tabMessages.some(x=>x.id===10 && x.message?.type==='MANUAL_ATTENTION' && x.message.attention?.status==='PAUSED'),'PAUSED must push manual attention even while focused');
  const clearCountBefore = tabMessages.filter(x=>x.id===10 && x.message?.type==='MANUAL_ATTENTION' && x.message.attention===null).length;
  await invokeMessage({type:'STATE',status:'RUNNING',chatTitle:'Chat 10',pageFocused:true,progress:76,workLike:true,url:tabMap.get(10).url,forceEvent:true},{tab:structuredClone(tabMap.get(10))});
  const clearCountAfter = tabMessages.filter(x=>x.id===10 && x.message?.type==='MANUAL_ATTENTION' && x.message.attention===null).length;
  assert.ok(clearCountAfter>clearCountBefore,'healthy state after manual action must clear the persistent external attention episode');

  // A stale-heartbeat fault is operational telemetry only: no manual page attention or popup.
  const staleAttentionBefore = tabMessages.filter(x=>x.id===11 && x.message?.type==='MANUAL_ATTENTION').length;
  const staleNotificationsBefore = notificationCalls.length;
  await invokeMessage({type:'STATE',status:'PAGE_STALE',manualAction:true,chatTitle:'Chat 11',pageFocused:false,progress:40,workLike:true,url:tabMap.get(11).url,forceEvent:true},{tab:structuredClone(tabMap.get(11))});
  assert.strictEqual(tabMessages.filter(x=>x.id===11 && x.message?.type==='MANUAL_ATTENTION').length,staleAttentionBefore,'PAGE_STALE must not create manual attention');
  assert.strictEqual(notificationCalls.length,staleNotificationsBefore,'PAGE_STALE must recover quietly without a desktop notification');
  await invokeMessage({type:'HEARTBEAT',status:'RUNNING',chatTitle:'Chat 11',progress:41,url:tabMap.get(11).url},{tab:structuredClone(tabMap.get(11))});
  assert.strictEqual(local.tabs['11'].status,'RUNNING','fresh heartbeat must restore the operational state');

  // Heartbeats update operational state without manufacturing events or notifications.
  const eventsBeforeHeartbeat = local.events.length;
  const notificationsBeforeHeartbeat = notificationCalls.length;
  await invokeMessage({type:'HEARTBEAT',status:'RUNNING',safeCompletion:true,chatTitle:'Heartbeat title',progress:42,messageId:'hb-42',url:tabMap.get(11).url},{tab:structuredClone(tabMap.get(11))});
  assert.strictEqual(local.tabs['11'].progress,42);
  assert.strictEqual(local.tabs['11'].safeCompletion,false,'non-COMPLETE heartbeat must clear stale completion proof');
  assert.strictEqual(local.events.length,eventsBeforeHeartbeat,'progress-only heartbeat must not add an event');
  assert.strictEqual(notificationCalls.length,notificationsBeforeHeartbeat,'progress-only heartbeat must not notify');
  assert.strictEqual(heartbeatCalls.at(-1).title,'Heartbeat title');
  assert.strictEqual(heartbeatCalls.at(-1).progress,42);
  assert.strictEqual(heartbeatCalls.at(-1).safeCompletion,false);

  await invokeMessage({type:'HEARTBEAT',status:'COMPLETE',safeCompletion:false,chatTitle:'Unsafe complete',progress:99,url:tabMap.get(11).url},{tab:structuredClone(tabMap.get(11))});
  assert.strictEqual(local.tabs['11'].status,'UNCERTAIN','unsafe heartbeat completion must downgrade');
  assert.strictEqual(local.tabs['11'].safeCompletion,false);
  assert.strictEqual(local.tabs['11'].progress,null,'unsafe completion must not render a terminal percentage');
  assert.strictEqual(heartbeatCalls.at(-1).status,'UNCERTAIN');

  await invokeMessage({type:'HEARTBEAT',status:'COMPLETE',safeCompletion:true,chatTitle:'Safe complete',progress:null,url:tabMap.get(11).url},{tab:structuredClone(tabMap.get(11))});
  assert.strictEqual(local.tabs['11'].status,'COMPLETE');
  assert.strictEqual(local.tabs['11'].progress,100);
  assert.strictEqual(local.tabs['11'].safeCompletion,true);


  // Concurrent first-seen heartbeats must not lose tab records through read-modify-write races.
  storageLatencyMs = 4;
  for (let i=22;i<=41;i++) tabMap.set(i,{id:i,windowId:100,url:`https://chatgpt.com/c/conversation-${i}`,title:`Chat ${i}`,autoDiscardable:true,discarded:false});
  await Promise.all([...Array(20)].map((_,offset)=>{
    const i=22+offset;
    return invokeMessage({type:'HEARTBEAT',status:'IDLE',chatTitle:`Chat ${i}`,url:tabMap.get(i).url},{tab:structuredClone(tabMap.get(i))});
  }));
  storageLatencyMs = 0;
  for (let i=22;i<=41;i++) assert.ok(local.tabs[String(i)],`concurrent tab ${i} record must survive serialized storage mutation`);
  for (let i=22;i<=41;i++) { tabMap.delete(i); await listeners['tabs.onRemoved'][0](i,{windowId:100,isWindowClosing:false}); }
  assert.strictEqual(Object.keys(local.tabs).length,20,'concurrency stress records must cleanly detach');

  // Moving a tracked tab outside the managed window stops monitoring it;
  // moving it back makes it eligible again.
  const detached = listeners['tabs.onDetached'][0];
  const attached = listeners['tabs.onAttached'][0];
  await detached(7,{oldWindowId:100,oldPosition:0});
  tabMap.get(7).windowId=300;
  await attached(7,{newWindowId:300,newPosition:0});
  r = await invokeMessage({type:'HEARTBEAT',status:'COMPLETE',chatTitle:'Chat 7',url:tabMap.get(7).url},{tab:structuredClone(tabMap.get(7))});
  assert.strictEqual(r.ok,false,'tab moved outside managed window must be ignored');
  assert.ok(!local.tabs['7'],'tab moved outside managed window must be removed');
  tabMap.get(7).windowId=100;
  await attached(7,{newWindowId:100,newPosition:0});
  r = await invokeMessage({type:'HEARTBEAT',status:'COMPLETE',chatTitle:'Chat 7',url:tabMap.get(7).url},{tab:structuredClone(tabMap.get(7))});
  assert.strictEqual(r.ok,true,'tab moved back into managed window must be eligible');
  assert.strictEqual(local.tabs['7'].windowId,100);

  // Correct-tab command routing through the single managed command channel.
  bridgeCommand={requestId:'cmd-1',type:'ACTIVATE_TAB',targetTabId:7,createdAt:Date.now()};
  r = await invokeMessage({type:'COMMAND_POLL'},{tab:structuredClone(tabMap.get(1))});
  assert.strictEqual(r.ok,true);
  assert.strictEqual(tabMap.get(7).active,true);
  assert.strictEqual(windowUpdates.at(-1).id,100);
  assert.strictEqual(commandAck.ok,true);

  // A ChatGPT tab in an ordinary Chrome window in the same real profile must be ignored.
  tabMap.set(21,{id:21,windowId:400,url:'https://chatgpt.com/c/conversation-21',title:'Chat 21',autoDiscardable:true,discarded:false});
  await listeners['tabs.onUpdated'][0](21,{status:'complete'},structuredClone(tabMap.get(21)));
  assert.ok(!local.tabs['21'],'ordinary-window ChatGPT tab must not be enrolled');
  assert.strictEqual(tabMap.get(21).autoDiscardable,true,'ordinary-window tab must not be modified');
  tabMap.delete(21);
  await listeners['tabs.onRemoved'][0](21,{windowId:400,isWindowClosing:false});
  assert.strictEqual(Object.keys(local.tabs).length,20,'temporary secondary-window enrollment test must cleanly detach');

  // Recovery scan must prune a tab that navigated away while the extension was disabled
  // and therefore missed the normal onUpdated lifecycle event.
  const missedAwayUrl = tabMap.get(8).url;
  tabMap.get(8).url='chrome://extensions/';
  await context.scanAndProtectManagedTabs();
  assert.ok(!local.tabs['8'],'recovery scan must prune a missed navigate-away record');
  assert.ok(tabClosedCalls.some(x=>x.tabId===8 && x.reason==='managed-scan-prune'),'bridge must be told to remove the stale counted tab');
  tabMap.get(8).url=missedAwayUrl;
  r = await invokeMessage({type:'HEARTBEAT',status:'RUNNING',chatTitle:'Chat 8',url:missedAwayUrl},{tab:structuredClone(tabMap.get(8))});
  assert.strictEqual(r.ok,true,'restored ChatGPT tab must be eligible after scan pruning');

  // Stale recovery must refuse reload while generation is still running.
  r = await invokeMessage({type:'REQUEST_STALE_RECOVERY',isGenerating:true,domStaleEvidence:true,url:tabMap.get(1).url},{tab:structuredClone(tabMap.get(1))});
  assert.strictEqual(r.safeToReload,false);
  r = await invokeMessage({type:'REQUEST_STALE_RECOVERY',isGenerating:false,domStaleEvidence:true,url:tabMap.get(1).url},{tab:structuredClone(tabMap.get(1))});
  assert.strictEqual(r.safeToReload,false,'generic stale state must never auto-refresh in v2.4');

  // Explicit delivery timeout queues one bounded refresh even when ChatGPT leaves a
  // stale Stop square in the DOM; Continue remains protected as a genuine pause.
  probeStates.set(1,{status:'TIMEOUT',progress:35,composerEmpty:true,hasStopButton:true,hasContinueButton:false});
  const recovery = await invokeMessage({type:'REQUEST_TIMEOUT_RECOVERY',state:{status:'TIMEOUT',progress:35,messageId:'timeout-1',composerEmpty:true}},{tab:structuredClone(tabMap.get(1))});
  assert.strictEqual(recovery.ok,true); assert.strictEqual(recovery.queued,true);
  const refreshAlarm = alarmCalls.find(x => x.name.startsWith('cwn-timeout-refresh-1-'));
  assert.ok(refreshAlarm,'timeout recovery must create a bounded alarm');
  await listeners['alarms.onAlarm'][0]({name:refreshAlarm.name});
  assert.ok(reloadCalls.some(x => x.id===1 && x.options.bypassCache===false),'timeout with stale Stop must reload without bypassing cache');

  // A rate-limited timeout is deferred instead of being dropped.
  probeStates.set(2,{status:'TIMEOUT',progress:40,composerEmpty:true,hasStopButton:false,hasContinueButton:false});
  local.cwnRefreshHistory = [Date.now()];
  const deferred = await invokeMessage({type:'REQUEST_TIMEOUT_RECOVERY',state:{status:'TIMEOUT',progress:40,messageId:'timeout-2',composerEmpty:true}},{tab:structuredClone(tabMap.get(2))});
  assert.strictEqual(deferred.ok,true); assert.strictEqual(deferred.deferred,true);


  // Navigating away from ChatGPT must remove the tab from monitoring rather than leaving a stale counted record.
  const awayTab = structuredClone(tabMap.get(8));
  tabMap.get(8).url='https://example.com/';
  await listeners['tabs.onUpdated'][0](8,{url:'https://example.com/',status:'loading'},structuredClone(tabMap.get(8)));
  assert.ok(!local.tabs['8'],'navigated-away tab must be removed from local managed records');

  await listeners['windows.onRemoved'][0](100);
  assert.strictEqual(local.managedSessionToken,null,'closing the managed window must end its managed session');
  assert.strictEqual(Object.keys(local.tabs).length,0,'closing the managed window must clear tracked tabs');

  // A lost close message must heal even though local storage already forgot the tab.
  await invokeMessage({type:'REGISTER_MANAGED_WINDOW',token:MANAGED_TOKEN},{tab:structuredClone(tabMap.get(1))});
  await invokeMessage({type:'HEARTBEAT',status:'RUNNING',url:tabMap.get(1).url},{tab:structuredClone(tabMap.get(1))});
  bridgeTabs.add(5);
  const closedSender = structuredClone(tabMap.get(5));
  tabMap.delete(5);
  failTabUpdates = true;
  await listeners['tabs.onRemoved'][0](5, {windowId:100,isWindowClosing:false});
  assert.ok(!local.tabs['5']);
  assert.ok(bridgeTabs.has(5), 'outage reproduces bridge-only ghost');
  failTabUpdates = false;
  await context.syncManagedTabInventory(true);
  assert.ok(!bridgeTabs.has(5), 'fresh browser inventory repairs a missed close');
  r = await invokeMessage({type:'HEARTBEAT',status:'RUNNING',url:closedSender.url},{tab:closedSender});
  assert.strictEqual(r.ok,false,'late heartbeat from a closed tab is rejected');
  assert.ok(!local.tabs['5'] && !bridgeTabs.has(5),'late heartbeat cannot recreate the removed row');
  assert.ok(bridgeTabs.has(1), 'live running tasks are retained');

  bridgeTabs.add(9999); // old worker/session metadata absent from local storage
  const beforeQueryFailure = Object.keys(local.tabs).sort();
  failTabQuery = true;
  await context.syncManagedTabInventory(true);
  assert.ok(bridgeTabs.has(9999), 'query failure must not be treated as an empty inventory');
  assert.deepStrictEqual(Object.keys(local.tabs).sort(), beforeQueryFailure);
  failTabQuery = false;
  await context.syncManagedTabInventory(true);
  assert.ok(!bridgeTabs.has(9999), 'reconciliation removes bridge-only orphans');

  bridgeTabs.add(6);
  const replaced = {...tabMap.get(6),id:60};
  tabMap.delete(6); tabMap.set(60,replaced);
  await listeners['tabs.onReplaced'][0](60,6);
  assert.ok(!bridgeTabs.has(6), 'replaced renderer does not leave its old tab row');
  assert.ok(local.tabs['60'], 'replacement retains the task record');

  // Closing the final window while offline must retain a retryable empty inventory.
  const managedId = local.managedWindowId;
  for (const [id, tab] of tabMap) if (tab.windowId === managedId) tabMap.delete(id);
  failWindowQuery = true;
  await context.scanAndProtectManagedTabs();
  assert.strictEqual(bridgeTabs.size, 0, 'missing window query falls back to authoritative all-tabs inventory');
  failWindowQuery = false;
  bridgeTabs.add(9999); // simulate an orphan retained during reconnect

  failTabUpdates = true;
  await listeners['windows.onRemoved'][0](managedId);
  assert.strictEqual(local.managedSessionToken, null);
  assert.strictEqual(local.pendingTabInventoryToken, MANAGED_TOKEN);
  assert.ok(bridgeTabs.size > 0);
  failTabUpdates = false;
  await listeners['alarms.onAlarm'][0]({name:'cwn-health'});
  assert.strictEqual(bridgeTabs.size, 0, 'health alarm repairs final-window closure without a content script');
  assert.strictEqual(local.pendingTabInventoryToken, null);

  console.log('PASS service-worker-multitab.test.js: multi-tab concurrency, ordinary-window isolation, move boundary, navigate-away cleanup, dedupe, routing, stale recovery');
})().catch(err=>{ console.error(err); process.exit(1); });
