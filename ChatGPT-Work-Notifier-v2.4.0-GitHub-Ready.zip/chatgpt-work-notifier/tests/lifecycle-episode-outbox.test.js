const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const listeners = {};
const evt = name => ({ addListener(fn) { (listeners[name] ||= []).push(fn); } });
const local = { events: [], tabs: {}, managedWindowId: null, managedSessionToken: null, completionOutbox: {} };
const sync = {};
const tab = { id: 1, windowId: 9, url: 'https://chatgpt.com/c/episode-test', title: 'Episode test', autoDiscardable: true, discarded: false };
const token = '0123456789abcdef0123456789abcdef';
let failEvents = 100;
let eventAttempts = 0;
let monitoringEnabled = true;
const clone = x => structuredClone(x);
const chrome = {
  runtime: { onInstalled: evt('installed'), onStartup: evt('startup'), onMessage: evt('message') },
  storage: { local: { async get(d = {}) { return { ...d, ...clone(local) }; }, async set(v) { Object.assign(local, clone(v)); } }, sync: { async get(d = {}) { return { ...d, ...clone(sync) }; }, async set(v) { Object.assign(sync, clone(v)); } } },
  tabs: { onUpdated: evt('updated'), onActivated: evt('activated'), onDetached: evt('detached'), onAttached: evt('attached'), onReplaced: evt('replaced'), onRemoved: evt('removed'), async get() { return clone(tab); }, async query() { return [clone(tab)]; }, async update(_, p) { Object.assign(tab, p); return clone(tab); }, async sendMessage() { return {}; }, async reload() {} },
  windows: { onRemoved: evt('windowRemoved'), async update() {} },
  notifications: { onClicked: evt('notificationClicked'), async create() {}, async clear() {} },
  action: { async setBadgeText() {}, async setBadgeBackgroundColor() {} },
  alarms: { onAlarm: evt('alarm'), async get() { return null; }, create() {}, async clear() {} }
};
function response(value) { return { ok: true, status: 200, async json() { return clone(value); } }; }
async function fetchMock(url, options = {}) {
  const u = new URL(url); const body = options.body ? JSON.parse(options.body) : {};
  if (u.pathname === '/validate-session') return response({ ok: body.token === token });
  if (u.pathname === '/config') return response({ config: { monitoringEnabled } });
  if (u.pathname === '/browser-event') eventAttempts++;
  if (u.pathname === '/browser-event' && failEvents-- > 0) return { ok: false, status: 503, async json() { return {}; } };
  return response({ ok: true });
}
const context = { chrome, CWNCore: require('../reliability-core.js'), console, URL, Headers, AbortController, setTimeout, clearTimeout, structuredClone, importScripts() {}, fetch: fetchMock, Map, Set, Date, Number, Boolean, String, Math, Promise };
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'service-worker.js'), 'utf8'), context, { filename: 'service-worker.js' });
const invoke = (message) => new Promise((resolve, reject) => {
  const fn = listeners.message[0];
  let ret;
  try { ret = fn(message, { tab: clone(tab) }, resolve); } catch (e) { reject(e); return; }
  if (ret !== true) resolve(undefined);
  setTimeout(() => reject(new Error('message timeout')), 1500);
});

(async () => {
  let r = await invoke({ type: 'REGISTER_MANAGED_WINDOW', token }); assert.strictEqual(r.ok, true);
  await invoke({ type: 'STATE', status: 'RUNNING', messageId: 'seg-1', progress: 82, pageFocused: false, url: tab.url, workLike: true });
  const runningEpisode = local.tabs['1'].episodeId;
  await invoke({ type: 'STATE', status: 'PAUSED', messageId: 'seg-1', progress: 82, pageFocused: false, url: tab.url, workLike: true });
  await invoke({ type: 'STATE', status: 'RUNNING', isResume: true, resumeContinuation: true, messageId: 'seg-1', progress: 82, pageFocused: false, url: tab.url, workLike: true });
  assert.strictEqual(local.tabs['1'].episodeId, runningEpisode);
  r = await invoke({ type: 'STATE', status: 'COMPLETE', safeCompletion: true, messageId: 'seg-1', pageFocused: false, url: tab.url, workLike: true });
  assert.strictEqual(r.stateCommitted, true);
  const first = clone(local.tabs['1']);
  assert.strictEqual(first.status, 'COMPLETE'); assert.strictEqual(first.progress, 100); assert.ok(first.episodeId); assert.ok(first.terminalEventId);
  assert.strictEqual(local.completionOutbox[first.terminalEventId].deliveryState, 'failed_retryable');
  await invoke({ type: 'HEARTBEAT', status: 'IDLE', progress: 82, episodeId: first.episodeId, episodeRevision: first.episodeRevision, url: tab.url });
  assert.strictEqual(local.tabs['1'].status, 'COMPLETE'); assert.strictEqual(local.tabs['1'].progress, 100);
  assert.strictEqual(local.tabs['1'].terminalEventId, first.terminalEventId);
  const eventCount = local.events.length;
  await invoke({ type: 'STATE', status: 'COMPLETE', safeCompletion: true, messageId: 'seg-1', episodeId: first.episodeId, episodeRevision: first.episodeRevision + 1, pageFocused: false, url: tab.url, workLike: true });
  assert.strictEqual(local.events.length, eventCount);
  await invoke({ type: 'STATE', status: 'IDLE', progress: 1, episodeId: first.episodeId, episodeRevision: 1, pageFocused: false, url: tab.url, workLike: true });
  assert.strictEqual(local.tabs['1'].status, 'COMPLETE');
  await invoke({ type: 'STATE', status: 'RUNNING', messageId: 'new-task', progress: null, pageFocused: false, url: tab.url, workLike: true });
  assert.notStrictEqual(local.tabs['1'].episodeId, first.episodeId); assert.strictEqual(local.tabs['1'].progress, null); assert.strictEqual(local.tabs['1'].lastEpisodeProgress, null);
  const newer = clone(local.tabs['1']);
  await context.markOutboxDelivery(first.terminalEventId, 'delivered');
  assert.deepStrictEqual(local.tabs['1'], newer, 'late delivery must not mutate a newer episode');
  await context.markOutboxDelivery(first.terminalEventId, 'failed_retryable', 'late failed request');
  assert.strictEqual(local.completionOutbox[first.terminalEventId].deliveryState, 'delivered', 'late failures must not undo successful delivery');

  failEvents = 100;
  await invoke({ type: 'STATE', status: 'COMPLETE', safeCompletion: true, messageId: 'new-task', pageFocused: false, url: tab.url, workLike: true });
  const pending = local.tabs['1'].terminalEventId;
  assert.strictEqual(local.tabs['1'].workLike, true, 'retry eligibility survives in persisted task state');
  const beforeRetry = eventAttempts;
  failEvents = 0;
  monitoringEnabled = false;
  await context.getRuntimeConfig(true);
  await context.retryPendingCompletionOutbox();
  assert.strictEqual(eventAttempts, beforeRetry, 'paused monitoring must not emit retry alerts');
  monitoringEnabled = true;
  await context.getRuntimeConfig(true);
  local.tabs['1'].suppressNotification = true;
  await context.retryPendingCompletionOutbox();
  assert.strictEqual(eventAttempts, beforeRetry, 'suppressed completion must stay quiet on retry');
  local.tabs['1'].suppressNotification = false;
  local.tabs['1'].workLike = false;
  local.tabs['1'].runSeconds = 0;
  await context.retryPendingCompletionOutbox();
  assert.strictEqual(eventAttempts, beforeRetry, 'work mode must also filter retry alerts');
  local.tabs['1'].workLike = true;
  local.tabs['1'].pageFocused = true;
  await context.retryPendingCompletionOutbox();
  assert.strictEqual(eventAttempts, beforeRetry, 'focused completion remains deferred');
  local.tabs['1'].pageFocused = false;
  local.tabs['1'].safeCompletion = false;
  await context.retryPendingCompletionOutbox();
  assert.strictEqual(eventAttempts, beforeRetry, 'retry must not manufacture completion proof');
  local.tabs['1'].safeCompletion = true;
  await context.retryPendingCompletionOutbox();
  assert.strictEqual(eventAttempts, beforeRetry + 1, 'eligible completion is retried when monitoring resumes');
  assert.strictEqual(local.completionOutbox[pending].deliveryState, 'delivered');
  await context.retryPendingCompletionOutbox();
  assert.strictEqual(eventAttempts, beforeRetry + 1, 'delivered completion is not retried');
  console.log('PASS lifecycle-episode-outbox.test.js');
})().catch(error => { console.error(error); process.exit(1); });
