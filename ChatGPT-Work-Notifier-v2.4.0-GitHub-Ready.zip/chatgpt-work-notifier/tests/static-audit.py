from pathlib import Path
import json, re, subprocess, sys

ROOT = Path(__file__).resolve().parents[1]
checks = []

def check(name, ok, detail=''):
    checks.append((name, bool(ok), detail))

def text(rel):
    return (ROOT / rel).read_text(encoding='utf-8-sig')

required = [
    'START_CHATGPT_WORK_NOTIFIER.bat','Maintenance/LAUNCH_NOTIFIER_ONLY.bat','Maintenance/INSTALL_OR_UPGRADE.bat','Maintenance/UNINSTALL.bat',
    'Maintenance/CHECK_ADVANCED_LOGGER_STATUS.bat','Maintenance/MAKE_CODEX_DIAGNOSTIC_BUNDLE.bat','Maintenance/RUN_CODEX_FINAL_WINDOWS_VALIDATION.bat','Maintenance/STOP_ADVANCED_LOGGER.bat',
    'runtime/launch-hidden.vbs','runtime/tray-host.ps1','runtime/browser-bridge.ps1',
    'runtime/diagnostics.ps1','runtime/chrome-launch.json','runtime/generate-root-manifest.ps1',
    'runtime/install.ps1','runtime/uninstall.ps1','runtime/notifier.ico',
    'manifest.json','state-engine.js','reliability-core.js','service-worker.js','managed-bootstrap.js','content.js','popup.html','popup.js','popup.css',
    'icons/icon16.png','icons/icon32.png','icons/icon48.png','icons/icon128.png','icons/icon256.png','icons/icon512.png',
    'tests/state-engine-v221.test.js','tests/request-regression-v221.test.js','tests/reliability-core.test.js','tests/service-worker-multitab.test.js','tests/v240-repair-regression.test.js','tests/TRAY_SELECTION_TEST.ps1','tests/TRAY_PROGRESS_PRESENTATION_TEST.ps1','tests/INSTALL_MIGRATION_TEST.ps1','tests/RESOURCE_TEST.ps1',
    'tests/fixtures/TIMEOUT_STALE_STOP.html','tests/fixtures/PAUSED_25M47S_75_PERCENT.html','tests/fixtures/STUCK_THINKING.html',
    'tests/VERIFY_RUNTIME.ps1','tests/MANUAL_VALIDATION.md','Maintenance/RUN_CODEX_FINAL_WINDOWS_VALIDATION.bat',
    'CODEX_EXECUTE_FIRST.md','README.md','CHANGELOG.md','FINAL_WINDOWS_EXECUTION_REPORT.md','FINAL_100_LINE_BY_LINE_AUDIT_REPORT.txt','SECURITY.md','ARCHITECTURE.md',
    'tests/final-100-audit.py','tests/security-hardening-v230.py','tests/SECURITY_WINDOWS_RUNTIME.ps1',
    'CODEX_FINALISE_NO_THINKING.md','AUDIT_100_LAYER_RESULTS.md','DEFECT_REPAIR_LEDGER.json','CRITICAL_INVARIANTS.md','REQUIREMENT_TRACEABILITY.md',
    'TEST_EVIDENCE_INDEX.md','FINAL_ENVIRONMENT_MATRIX.md','SBOM.cdx.json','BUILD_PROVENANCE.json','SECURITY_BASELINE.md',
    'V240_IMPLEMENTATION_EVIDENCE.md','V240_STATIC_AUDIT_REPORT.md','V240_MATERIAL_AUDIT_REPORT.md','V240_RUNTIME_CONTRACT_REPORT.md','FINAL_V240_VERIFICATION.md'
]
for f in required:
    check('required:' + f, (ROOT / f).is_file())

for deleted in [
    'companion/chatgpt-app-watcher.ps1','companion/install-companion.ps1','companion/uninstall-companion.ps1',
    'RUN_GPTCHAT_G20_TEST.bat','tests/gptchat-switch-test.ps1'
]:
    check('deleted:' + deleted, not (ROOT / deleted).exists())

manifest = json.loads(text('manifest.json'))
check('manifest-v3', manifest.get('manifest_version') == 3)
check('version-2.4.0', manifest.get('version') == '2.4.0')
check('minimum-chrome-120', int(manifest.get('minimum_chrome_version','0')) >= 120)
for perm in ['tabs','windows','storage','notifications','alarms']:
    check('permission:' + perm, perm in manifest.get('permissions', []))
check('chatgpt-host-only', set(manifest.get('host_permissions', [])) == {'https://chatgpt.com/*','https://chat.openai.com/*','http://127.0.0.1:38765/*'})
check('chrome-only-description', 'existing Chrome profile' in manifest.get('description',''))

launch = json.loads(text('runtime/chrome-launch.json'))
check('no-process-wide-launch-switches', launch.get('requiredSwitches', []) == [])
check('launch-no-duplicates', len({s.split('=',1)[0].lower() for s in launch.get('requiredSwitches',[])}) == len(launch.get('requiredSwitches',[])))
for bad in ['--no-sandbox','--disable-web-security','--ignore-certificate-errors','--allow-running-insecure-content']:
    check('prohibited-config:' + bad, bad in launch.get('prohibitedSwitches', []))

host = text('runtime/tray-host.ps1')
install = text('runtime/install.ps1')
installer_bat = text('Maintenance/INSTALL_OR_UPGRADE.bat')
root_bats = sorted(p.name for p in ROOT.glob('*.bat'))
check('one-obvious-root-launcher', root_bats == ['START_CHATGPT_WORK_NOTIFIER.bat'])
check('root-launcher-starts-advanced-logger', 'ADVANCED_LOGGER\\start-advanced-logger.ps1' in text('START_CHATGPT_WORK_NOTIFIER.bat'))
check('original-user-data-dir', '--user-data-dir=' not in host and 'usesOriginalChromeProfile = $true' in host)
check('managed-profile', '--profile-directory=' in host and 'Get-ChromeLastProfile' in host)
check('no-obsolete-load-extension-switch', '--load-extension=' not in host)
check('managed-extension-setup', 'existing Chrome profile' in host and 'chrome://extensions/' in host and 'Load unpacked' in host)
check('safe-arg-dedup', 'Add-UniqueArgument' in host and "-split '=',2" in host)
check('paths-quoted', 'Quote-ChromeValue' in host)
check('chrome-detection', all(x in host for x in ['ProgramFiles','ProgramFiles(x86)','LOCALAPPDATA']))
check('awake-winapi', 'SetThreadExecutionState' in host and '0x80000001' in host and '0x80000000' in host)
check('display-awake-optional', 'keepDisplayAwake' in host and '0x00000002' in host)
check('awake-default-on', 'keepComputerAwake = $true' in host)
check('display-default-off', 'keepDisplayAwake = $false' in host)
check('auto-recover-default-on', 'autoRecoverChrome = $true' in host)
check('auto-repair-default-on', 'autoRepairConnection = $true' in host)
check('stale-recovery-default-on', 'allowControlledStaleRecovery = $true' in host)
check('lid-policy-not-changed', 'does not change the lid policy' in host and 'powercfg /set' not in host.lower())
check('hide-all-managed-windows', 'foreach ($h in $handles)' in host and 'ShowWindow([IntPtr][long]$h, 0)' in host)
check('show-all-managed-windows', 'foreach ($h in $handles)' in host and 'ShowWindow([IntPtr][long]$h, 9)' in host and 'SetForegroundWindow($script:ManagedHwnd)' in host)
check('hung-detection', 'IsHungAppWindow' in host and 'HungMisses' in host)
check('active-response-restart-suppression', 'Automatic Chrome restart suppressed because a managed tab reports RUNNING' in host and 'Automatic managed-window recreation suppressed because a managed tab reports RUNNING' in host)
check('staged-recovery', all(x in host for x in ['DEGRADED','REPAIRING','RECOVERED','HEALTHY']))
check('stale-extension-quiet-auto-repair', "Show-SyntheticPopup 'PAGE_STALE'" not in host and 'automatic repair started without interrupting the user' in host and 'ExtensionStaleAlerted' in host)
check('correct-tab-popup-route', '/request-tab-focus' in host and 'Open correct ChatGPT tab' in host and '$activeEvent = $script:PopupEvent' in host)
check('lossless-popup-queue', 'popupEvents = New-Object System.Collections.ArrayList' in text('runtime/browser-bridge.ps1') and 'while ($script:popupEvents.Count -gt 64)' in text('runtime/browser-bridge.ps1') and 'LastPopupSequence' in host)
check('custom-popup', 'function Show-NotifierPopup' in host and 'TopMost = $true' in host)
check('popup-bottom-right-and-content-visible', '$area.Right - $popup.Width - 22' in host and '$surface.BringToFront()' in host)
check('ui-assets-do-not-lock-release-files', 'New-Object System.Drawing.Bitmap($sourceImage)' in host and '$sourceImage.Dispose()' in host and '$sourceLogo.Dispose()' in host and '$sourceIcon.Dispose()' in host)
check('white-blue-dashboard', 'BACKGROUND RELIABILITY' in host and 'FromArgb(37,99,235)' in host and '[System.Drawing.Color]::White' in host)
for label in [
    'Windows awake protection','Original Chrome profile','Managed-window isolation',
    'Background tab monitoring','Memory Saver tab protection','Windows power source','Extension heartbeat',
    'Browser bridge','Managed Chrome','Monitored ChatGPT tabs','Last monitoring event','Recovery status'
]:
    check('dashboard-row:' + label, label in host)
for control in [
    'Open Dashboard','Show Managed Chrome','Hide Managed Chrome','Pause Monitoring','Resume Monitoring',
    'Keep Computer Awake','Restart Managed Chrome','Repair Connection','Exit'
]:
    check('tray-control:' + control, control in host)
check('custom-icon-tray', 'runtime\notifier.ico' not in host or 'notifier.ico' in host)
check('no-powershell-icon-fallback-primary', 'notifier.ico' in host)
check('2s-health-loop-not-busy', '$timer.Interval = 2000' in host)

check('no-profile-copy-helper', not (ROOT / 'runtime/profile-bootstrap.ps1').exists())
check('no-profile-copy-code', 'Copy-ManagedChromeProfile' not in host and '--user-data-dir=' not in host)
check('no-global-chrome-policy-write-profile', 'Software\\Policies\\Google\\Chrome' not in host)

bridge = text('runtime/browser-bridge.ps1')
check('bridge-loopback-only', 'IPAddress]::Loopback' in bridge)
check('bridge-v2.4.0', "version = $Version" in bridge and "$Version = '2.4.0'" in bridge)
check('bridge-chrome-only', "mode = 'CHROME_ONLY'" in bridge)
for endpoint in ['/state','/dashboard-state','/config','/command','/browser-event','/browser-heartbeat','/browser-lifecycle','/browser-tab-closed','/show-managed-window','/request-tab-focus','/request-repair','/diagnostic-ping','/command-ack']:
    check('bridge-endpoint:' + endpoint, endpoint in bridge)
check('bridge-origin-guard', 'chrome-extension://' in bridge and "403 'Forbidden'" in bridge)
check('bridge-body-limit', '16384' in bridge and 'Request body too large' in bridge)
check('bridge-status-allowlist', 'allowedStatuses' in bridge)
check('bridge-status-metadata-only', 'Prompt and response text are never accepted' in bridge)
check('bridge-no-external-network', 'Invoke-WebRequest' not in bridge and 'Invoke-RestMethod' not in bridge)
check('bridge-no-0.0.0.0', '0.0.0.0' not in bridge)
check('bridge-multitab-records', 'browserTabs' in bridge and 'heartbeatAgeSeconds' in bridge and 'conversationId' in bridge)

sw = text('service-worker.js')
check('core-import', 'importScripts("reliability-core.js")' in sw)
check('managed-registration', 'REGISTER_MANAGED_WINDOW' in sw)
check('managed-window-move-boundary', 'MOVED_OUTSIDE_MANAGED_WINDOW' in sw and 'TAB_REATTACHED' in sw and 'attachInfo.newWindowId !== data.managedWindowId' in sw)
check('per-tab-auto-discardable', 'autoDiscardable: false' in sw and 'verified.autoDiscardable === false' in sw)
check('managed-window-query', 'chrome.tabs.query({ windowId: data.managedWindowId })' in sw)
check('ordinary-window-isolation', 'live.windowId === data.managedWindowId' in sw and 'sender.tab.windowId === live.windowId' in sw and 'MOVED_OUTSIDE_MANAGED_WINDOW' in sw)
check('managed-window-close-clears-session', 'managedWindowId: null, managedSessionToken: null, tabs: {}' in sw)
for lifecycle in ['onUpdated','onActivated','onDetached','onAttached','onReplaced','onRemoved']:
    check('tab-lifecycle:' + lifecycle, f'chrome.tabs.{lifecycle}.addListener' in sw)
check('single-leader-command-channel', 'commandLeaderTabId' in sw and 'COMMAND_ROLE' in sw and 'COMMAND_POLL' in sw)
check('leader-role-reasserted-after-early-registration', 'reassert the role on later heartbeats' in sw)
check('alarms-health-1m', 'periodInMinutes: 1' in sw)
check('timeout-only-recovery-request', 'REQUEST_TIMEOUT_RECOVERY' in sw and 'scheduleTimeoutRecovery' in sw and 'timeout-only' in sw)
check('correct-tab-activation', 'ACTIVATE_TAB' in sw and 'chrome.tabs.update(tabId, { active: true, autoDiscardable: false })' in sw)
check('notification-dedupe', 'shouldNotifyTransition' in sw and 'volatileCooldowns' in sw)
check('runtime-config-pause', 'monitoringEnabled === false' in sw)
check('no-chatgpt-network-fetch-sw', not re.search(r'fetch\s*\(\s*[`"\']https://(?:chatgpt\.com|chat\.openai\.com)', sw, re.I))

content = text('content.js')
state_engine = text('state-engine.js')
check('explicit-blockers-precede-seamless-completion', "result('COMPLETE','Complete'" in state_engine and "s,true,false,false,false" in state_engine and "result('TIMEOUT','Recovering'" in state_engine and "result('PAUSED','Resume needed'" in state_engine)
check('stuck-thinking-engine', "result('STUCK_THINKING','Thinking stuck'" in state_engine and 'STUCK_THINKING_MS:120000' in state_engine)
check('extended-thinking-positive-running', "result('RUNNING','Extended thinking'" in state_engine and 'hasExtendedThinkingBanner' in state_engine and 'EXTENDED_THINKING_IS_RUNNING:true' in state_engine and "el.closest('[data-message-author-role=\"assistant\"],[data-message-author-role=\"user\"]')" in content)
check('active-tool-running-evidence', 'activeToolStatusText' in content and 'Inspecting' in content and 'hasActiveToolActivity' in content and 'partialCurrentTurn' in content and 'turnAfterUser' in content)
check('long-pause-engine', 's.workedSeconds>=1470' in state_engine and 'LONG_RUN_PAUSE_SECONDS:1470' in state_engine and "result('PAUSED','Resume needed'" in state_engine)
check('ordered-progress-parser', 'matches.sort((a,b)=>a.index-b.index)' in state_engine and 'matches[matches.length-1].value' in state_engine and 'Bare percentages are deliberately ignored' in state_engine)
check('historical-dom-no-fresh-completion-or-pause', "if(!s.generationObserved)return result('IDLE','Idle'" in state_engine and 'Historical response text is display-only' in state_engine and 's.generationObserved&&s.hasContinueButton' in state_engine and 's.generationObserved&&current!=null&&current<100' in state_engine and 's.generationObserved&&incomplete' in state_engine and 'userSignature !== S.baselineUserSignature' in content and '!S.baselineReady' in content and content.index('S.baselineReady = true;') < content.index('const settings = await safeSendMessage({ type: "GET_SETTINGS" });'))
check('stable-ended-response-completes-seamlessly', 's.generationObserved&&s.assistantText&&stableEnough' in state_engine and "result('COMPLETE','Complete'" in state_engine and "result('UNCERTAIN','Needs verification'" not in state_engine)
check('progress-only-state-propagation', 'const progressChanged = result.progress !== (S.lastPayload?.progress ?? null)' in content and 'forceEvent: shouldForceEvent' in content)
check('active-turn-progress-binding', 'function assistantForTurn' in content and 'function structuredText' in content and 'function assistantTextForTurn' in content and 'const currentAssistant = assistantForTurn(currentTurn);' in content and 'const assistantText = assistantTextForTurn(currentTurn, currentAssistant);' in content and 'const cont = hasContinueButton(currentTurn);' in content)
check('current-sidebar-title-binding', 'function titleFromCurrentConversationLinks' in content and "document.querySelectorAll('a[href]'), location.href" in content)
check('sidebar-title-preserved-during-scan', '(data.tabs[String(tab.id)] || {}).title || tab.title || "ChatGPT"' in sw)
check('finalized-response-controls', 'function hasCompletedResponseControls' in content and 'hasCompletedResponseControls: completedResponseControls' in content and 's.hasCompletedResponseControls' in state_engine)
check('heartbeat-clears-recovered-manual-state', 'MANUAL_ACTION_STATUSES.has(previousStatus) && !MANUAL_ACTION_STATUSES.has(status)' in sw)
check('popup-latest-activity-sort', '(b.updatedAt || b.lastStateChange || 0)' in text('popup.js'))
check('autopilot-exact-resume-no-keyboard-injection', 'safeSetContentEditable(c.editor, "Resume")' in content and 'safeSetTextarea(c.fallback, "Resume")' in content and 'new KeyboardEvent' not in content and 'requestSubmit' not in content)
check('persistent-top-page-alert', 'cwn-manual-action-bar' in content and 'position:fixed;top:12px' in content and 'z-index:2147483647' in content and 'Dismiss' in content)
check('alert-dismissal-episode-stable', 'dismissedAlertKey' in content and 'attentionEpisode' in content)
check('initial-manual-baseline-emits', 'if (result.manualAction || MANUAL_ACTION_STATUSES.has(result.status))' in content and 'forceNotification: true' in content)
check('external-manual-attention-explicit-clear', 'clearManualAttention' in sw and 'MANUAL_ATTENTION' in content and 'S.externalAttention = next' in content and 'S.externalAttention && ![' not in content)
check('manual-popup-topmost-persistence', 'Test-ManualPopupStatus' in host and 'ManualPopupQueue' in host and '$wasManual = ($script:PopupEvent' in host and 'if (-not $activeEvent -or -not (Test-ManualPopupStatus' in host)
check('manual-popup-queue', 'Add-ManualPopupQueue' in host and 'Show-NextManualPopup' in host and 'queueCount=' in host)
check('manual-action-only-when-user-needed', 'new Set(["PAUSED","STUCK_THINKING","WAITING_INPUT","FAILED"])' in sw and 'async function recordOperationalFault' in sw and 'async function raiseManualFromBackground' not in sw)
check('manual-notification-require-interaction', 'requireInteraction: Boolean(manual' in sw and 'priority: manual ? 2 : 1' in sw)
check('timeout-refresh-draft-protection', 'state.composerEmpty === false' in sw)
check('timeout-refresh-conversation-scope', 'sameConversation' in sw and 'conversationId' in sw)
check('stale-heartbeat-fail-closed', 'STALE_HEARTBEAT_MS = 90 * 1000' in sw and 'PAGE_STALE' in sw)
check('mutation-observer', 'MutationObserver' in content)
check('dom-fallback-5s', 'SCAN_FALLBACK_MS = 5000' in content and 'setInterval(() => scan(false), SCAN_FALLBACK_MS)' in content)
check('controlled-heartbeat-20s', 'HEARTBEAT_MS = 20 * 1000' in content)
check('leader-poll-3s-local-only', 'COMMAND_POLL_MS = 3000' in content and 'COMMAND_POLL' in content)
check('no-forged-visibility', 'document.visibilityState' in content and 'dispatchEvent(new Event("visibilitychange"' not in content and 'defineProperty(document' not in content)
check('chatgpt-only-by-manifest', 'content_scripts' in text('manifest.json'))
check('generic-stale-never-autorefresh', 'REQUEST_STALE_RECOVERY' not in content and 'REQUEST_TIMEOUT_RECOVERY' in content)
check('timeout-reload-preserves-true-pause', 'state.hasContinueButton === true' in sw and 'status !== "TIMEOUT"' in sw and 'state.hasStopButton === true' not in sw)
check('controlled-reload-cooldown-15m', 'REFRESH_COOLDOWN_MS = 15 * 60 * 1000' in sw and 'REFRESH_MAX_PER_WINDOW = 4' in sw)
check('reload-after-live-probe', 'probeTabState(tabId)' in sw and 'state.status !== "TIMEOUT"' in sw and 'chrome.tabs.reload(tabId, { bypassCache: false })' in sw)
check('online-offline-events', 'window.addEventListener("offline"' in content and 'window.addEventListener("online"' in content)
check('no-fake-input', all(x not in content for x in ['mousemove','KeyboardEvent','MouseEvent','dispatchEvent(new Mouse']))
check('no-chatgpt-network-fetch-content', not re.search(r'fetch\s*\(\s*[`"\']https://(?:chatgpt\.com|chat\.openai\.com)', content, re.I))

check('serialized-local-state-mutations', 'withLocalMutation' in sw and 'localMutationQueue' in sw)
check('serialized-leader-election', 'leaderElectionQueue' in sw and 'afterLocalMutations' in sw)
check('navigate-away-record-cleanup', 'reason: "navigated-away"' in sw and 'await removeTabRecord(tabId)' in sw)
check('recovery-scan-prunes-missed-navigation', 'eligibleIds' in sw and 'managed-scan-prune' in sw and 'await removeTabRecord(tabId)' in sw)
bootstrap = text('managed-bootstrap.js')
check('document-start-token-bootstrap', 'cwn_managed_token' in bootstrap and 'sessionStorage.setItem' in bootstrap and 'document_start' in text('manifest.json'))
check('content-token-fallback', 'sessionStorage.getItem("cwn_managed_token")' in content)
check('state-send-retry-before-ack', 'await new Promise(r => setTimeout(r, 750))' in content and ('if (response?.ok) S.lastSentSignature = sig' in content or 'const delivered = Boolean(response?.ok)' in content))
check('captured-window-process-id', 'ProcessIdForWindow' in host and 'chromeProcessId' in host)
check('restart-closes-window-only', 'PostMessage($oldHwnd, 0x0010' in host and 'Get-ManagedChromeBrowserProcess' not in host)
check('bridge-client-timeouts', 'ReceiveTimeout = 2000' in bridge and 'SendTimeout = 2000' in bridge)
check('bridge-command-expiry', 'pendingCommand.createdAt -gt 75000' in bridge)
check('bridge-heartbeat-status-validation', 'heartbeatStatuses' in bridge and 'Invalid heartbeat status' in bridge)
check('bridge-single-strict-progress-validator', bridge.count('function Get-ValidatedProgress') == 1 and bridge.count('Get-ValidatedProgress $incoming.progress') == 2 and 'IsNaN' in bridge and 'IsInfinity' in bridge)
check('bridge-public-progress-contract', all(x in bridge for x in ['progress = $t.progress','updatedAt = $t.updatedAt','safeCompletion = [bool]$t.safeCompletion']))
check('bridge-authenticated-dashboard-state', '/dashboard-state' in bridge and 'Assert-LocalAuthenticated' in bridge and 'Get-DashboardState' in bridge)
check('dashboard-current-task-panel', 'CURRENT CHATGPT TASK' in host and '$currentTaskTitle' in host and '$currentTaskProgress' in host and '$currentTaskFreshness' in host)
check('dashboard-custom-progress-track-fill', '$currentProgressTrack = New-Object System.Windows.Forms.Panel' in host and '$currentProgressFill = New-Object System.Windows.Forms.Panel' in host and 'System.Windows.Forms.ProgressBar' not in host)
check('dashboard-all-tab-progress-list', 'ALL MANAGED CHATGPT TABS' in host and 'function Update-AllTabProgressPresentation' in host and '$script:TabProgressRows' in host)
check('dashboard-all-tab-flexible-scroll', '$allTabsHost.AutoScroll = $true' in host and 'AutoScrollMinSize' in host and '$allTabsHost.Controls.Remove($row.Panel)' in host)
check('dashboard-all-tab-safe-progress', '$row.Progress.Text = "$displayProgress%$estimateSuffix"' in host and "$row.Progress.Text = if ($status -eq 'RUNNING') { '% unavailable' }" in host and "$status = if ($claimedStatus -eq 'COMPLETE' -and -not $safeComplete) { 'UNCERTAIN' }" in host)
check('dashboard-tabbed-sections', 'function New-DashboardTabShell' in host and "$tasks.Text = 'Tasks'" in host and "$controls.Text = 'Controls'" in host and "$reliability.Text = 'Reliability'" in host and '$overviewPage.Controls.Add($currentTaskPanel)' in host and '$controlsPage.Controls.Add($settingsPanel)' in host and '$controlsPage.Controls.Add($actionsPanel)' in host and '$reliabilityPage.Controls.Add($reliabilityPanel)' in host)
check('dashboard-compact-fit', 'System.Drawing.Size(860, 700)' in host and 'System.Drawing.Size(824,548)' in host and 'System.Drawing.Size(778,142)' in host and 'System.Drawing.Size(778,190)' in host)
check('dashboard-explicit-hide-to-tray', 'function Hide-DashboardUi' in host and "$btnHideDashboard.Text = 'Hide UI to tray'" in host and 'Hide-DashboardUi $form' in host and "$btnHide = New-ActionButton 'Hide Chrome'" in host)
check('dashboard-task-visibility-controls', 'function Move-ChromeButtonsToTasks' in host and 'Move-ChromeButtonsToTasks $overviewPage $btnShow $btnHide $btnHideDashboard' in host and '$ShowButton.Location = New-Object System.Drawing.Point(13,462)' in host and '$HideButton.Location = New-Object System.Drawing.Point(155,462)' in host and '$HideUiButton.Location = New-Object System.Drawing.Point(297,462)' in host and '$HideUiButton.Size = New-Object System.Drawing.Size(128,42)' in host)
check('tray-current-task-selector', host.count('function Select-CurrentTask') == 1 and '$manualStates' in host and 'updatedAt' in host)
check('tray-current-status-item', '$miCurrent.Enabled = $false' in host and 'Current: RUNNING | % unavailable' in host and 'Current: No active task' in host)
check('tray-bounded-dynamic-tooltip', 'function Set-TrayTooltip' in host and '$Text.Substring(0,63)' in host)
check('dashboard-powershell51-encoding-safe', all(ord(char) < 128 for char in host))
check('content-visual-progress-component', all(x in content for x in ['cwn-progress-head','cwn-progress-state','cwn-progress-value','cwn-progress-track','cwn-progress-fill','cwn-progress-note']))
check('content-heartbeat-progress-proof-identity', all(x in content for x in ['progress: S.lastPayload?.progress','safeCompletion: S.lastPayload?.safeCompletion === true','messageId: S.lastPayload?.messageId']))
check('service-heartbeat-transport', all(x in sw for x in ['title: payload.chatTitle || tab.title','progress,','safeCompletion,']))
check('service-heartbeat-no-event-spam', 'addEvent(' not in sw[sw.find('async function forwardHeartbeat'):sw.find('async function forwardLifecycle')])
check('bridge-owned-process-stop', 'bridge.pid' in host and 'ProcessId=$bridgePid' in host)
check('installer-verified-cross-root-upgrade', 'Get-VerifiedNotifierRootFromCommandLine' in install and "manifest.name -ne 'ChatGPT Work Notifier'" in install and "manifest.manifest_version -ne 3" in install)
check('installer-clean-success-delay', 'Start-Sleep -Seconds 3' in installer_bat and 'timeout /t' not in installer_bat.lower())
check('logon-start-routes-through-logger-bootstrap', "ADVANCED_LOGGER\\start-advanced-logger.ps1" in install and "loggerStartPs1" in install and "Advanced logger startup script not found." in install)

logger = text('ADVANCED_LOGGER/flight-recorder.ps1')
logger_start = text('ADVANCED_LOGGER/start-advanced-logger.ps1')
check('advanced-logger-v1.1.1', "$LoggerVersion = '1.1.1'" in logger)
check('advanced-logger-current-release-integrity', "$manifestPath = Join-Path $root 'FILE_SHA256SUMS.txt'" in logger and 'Verify-ReleaseIntegrity' in logger)
check('advanced-logger-safe-complete-proof', 'safeCompletion=[bool]$e.safeCompletion' in logger and 'UNSAFE_COMPLETE_EVENT_REJECTED_BY_DIAGNOSIS' in logger)
check('advanced-logger-path-fix-preserved', "Join-Path $PSScriptRoot '..'" in logger_start and 'quoted %~dp0 argument' in logger_start and 'Illegal characters in path' in logger_start)
check('advanced-logger-public-state-compatible', 'conversationId=$e.conversationId' not in logger and 'url=$e.url' not in logger and 'conversationId=$tab.conversationId' not in logger and 'url=$tab.url' not in logger and 'conversationId=$t.conversationId' not in logger and 'url=$t.url' not in logger)
check('advanced-logger-self-contained-sha256', '[System.Security.Cryptography.SHA256]::Create()' in logger and 'Get-FileHash -LiteralPath' not in logger)
check('advanced-logger-empty-event-log-is-not-error', "NoMatchingEventsFound" in logger)

popup = text('popup.html') + text('popup.js') + text('popup.css')
check('popup-v2.4.0', 'v2.4.0' in popup)
check('popup-white-blue', '#f8fafc' in popup.lower() and '#2563eb' in popup.lower())
check('popup-reliability', all(x in popup for x in ['Extension heartbeat','Monitored tabs','Memory Saver']))
check('popup-program-alert-primary', 'PRIMARY ALERT: PROGRAM POPUP' in popup)

# Live code must never restore native ChatGPT app monitoring or UI Automation.
live_files = [
    'managed-bootstrap.js','content.js','service-worker.js','popup.html','popup.js','popup.css','manifest.json','reliability-core.js',
    'runtime/tray-host.ps1','runtime/browser-bridge.ps1','runtime/diagnostics.ps1'
]
for rel in live_files:
    low = text(rel).lower()
    forbidden = ['chatgpt-app-watcher','windows app backup','native-app backup','backup sensor','uiautomation','system.windows.automation','dual-source','app_backup_','appbackup']
    check('chrome-only-live:' + rel, not any(term in low for term in forbidden))

# Dangerous browser switches may appear only in the explicit prohibited list/tests/docs, never in launch code as added switches.
check('dangerous-not-added-host', all((f"Add-UniqueArgument $list $seen '{bad}'" not in host) for bad in launch.get('prohibitedSwitches', [])))
check('no-global-policy-registry', 'Software\\Policies\\Google\\Chrome' not in host + sw + content)

install = text('runtime/install.ps1').lower()
uninstall = text('runtime/uninstall.ps1').lower()
check('legacy-install-reference-migration-only', 'chatgpt-app-watcher' not in install or 'migration cleanup' in install)
check('legacy-uninstall-reference-migration-only', 'chatgpt-app-watcher' not in uninstall or 'migration cleanup' in uninstall)

# JS syntax gates.
for js in ['state-engine.js','reliability-core.js','service-worker.js','managed-bootstrap.js','content.js','popup.js','tests/state-engine-v221.test.js','tests/request-regression-v221.test.js','tests/reliability-core.test.js','tests/service-worker-multitab.test.js','tests/diagnostics.js','tests/browser-fixture.js','tests/browser-fixture-clock.js']:
    try:
        cp = subprocess.run(['node','--check',str(ROOT/js)],capture_output=True,text=True)
        check('node-parse:' + js, cp.returncode == 0, (cp.stderr or cp.stdout).strip())
    except FileNotFoundError:
        check('node-parse:' + js, True, 'Node unavailable; Codex must run syntax gate on Windows.')

# Unit tests.
for testjs in ['tests/state-engine-v221.test.js','tests/request-regression-v221.test.js','tests/reliability-core.test.js','tests/service-worker-multitab.test.js','tests/v240-repair-regression.test.js']:
    try:
        cp = subprocess.run(['node',str(ROOT/testjs)],capture_output=True,text=True,timeout=20)
        check('node-test:' + testjs, cp.returncode == 0, (cp.stderr or cp.stdout).strip())
    except Exception as e:
        check('node-test:' + testjs, False, str(e))

failed = [x for x in checks if not x[1]]
for name, ok, detail in checks:
    print(('PASS' if ok else 'FAIL') + ': ' + name + ((' - ' + detail) if detail else ''))
print(f'\nSTATIC RESULT: {len(checks)-len(failed)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)
