(() => {
  const realNow = Date.now.bind(Date);
  window.__cwnAdvanceMs = 0;
  Date.now = () => realNow() + window.__cwnAdvanceMs;
  const loads = Number(sessionStorage.getItem("cwnFixtureLoads") || 0) + 1;
  sessionStorage.setItem("cwnFixtureLoads", String(loads));
  document.documentElement.dataset.fixtureLoads = String(loads);
  document.getElementById("loadCount").textContent = `Loads: ${loads}`;
})();
