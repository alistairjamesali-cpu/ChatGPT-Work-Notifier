const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const E = require('../state-engine.js');

const root = path.resolve(__dirname, '..');
const read = rel => fs.readFileSync(path.join(root, rel), 'utf8');
const checks = [];
function check(name, condition) {
  assert.ok(condition, name);
  checks.push(name);
}

function fixture(name) {
  return read(path.join('tests', 'fixtures', name));
}

async function bridgeRequest(port, route, { method = 'GET', token = '', origin = '', body, raw } = {}) {
  const headers = {};
  if (token) headers['X-CWN-Token'] = token;
  if (origin) headers.Origin = origin;
  let requestBody;
  if (raw != null) {
    headers['Content-Type'] = 'application/json';
    requestBody = raw;
  } else if (body !== undefined) {
    headers['Content-Type'] = 'application/json';
    requestBody = JSON.stringify(body);
  }
  const response = await fetch(`http://127.0.0.1:${port}${route}`, { method, headers, body: requestBody });
  let json = null;
  try { json = await response.json(); } catch (_) {}
  return { status: response.status, json };
}

async function waitForBridge(port, child) {
  for (let i = 0; i < 80; i++) {
    if (child.exitCode != null) throw new Error(`bridge exited early (${child.exitCode})`);
    try {
      const result = await bridgeRequest(port, '/state');
      if (result.status === 200) return result.json;
    } catch (_) {}
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  throw new Error('timed out waiting for bridge');
}

(async () => {
  const content = read('content.js');
  const worker = read('service-worker.js');
  const stateEngine = read('state-engine.js');
  const popup = read('popup.js');
  const tray = read(path.join('runtime', 'tray-host.ps1'));
  const bridge = read(path.join('runtime', 'browser-bridge.ps1'));
  const installer = read(path.join('runtime', 'install.ps1'));
  const manifest = JSON.parse(read('manifest.json'));
  const launch = JSON.parse(read(path.join('runtime', 'chrome-launch.json')));
  const rootBats = fs.readdirSync(root).filter(name => name.toLowerCase().endsWith('.bat')).sort();

  check('root exposes one obvious BAT launcher', JSON.stringify(rootBats) === JSON.stringify(['START_CHATGPT_WORK_NOTIFIER.bat']));
  check('root launcher starts Advanced Logger', read('START_CHATGPT_WORK_NOTIFIER.bat').includes('ADVANCED_LOGGER\\start-advanced-logger.ps1'));
  check('Windows logon startup routes through Advanced Logger', installer.includes("$loggerStartPs1 = Join-Path $root 'ADVANCED_LOGGER\\start-advanced-logger.ps1'") && installer.includes('$value = \'"{0}" "{1}" "{2}"\' -f $wscript,$launchVbs,$loggerStartPs1'));
  check('maintenance BAT files are isolated', ['INSTALL_OR_UPGRADE.bat','UNINSTALL.bat','RUN_CODEX_FINAL_WINDOWS_VALIDATION.bat','CHECK_ADVANCED_LOGGER_STATUS.bat','STOP_ADVANCED_LOGGER.bat','MAKE_CODEX_DIAGNOSTIC_BUNDLE.bat','LAUNCH_NOTIFIER_ONLY.bat'].every(name => fs.existsSync(path.join(root, 'Maintenance', name))));

  check('manifest identifies v2.4.0', manifest.version === '2.4.0');
  check('launch configuration identifies v2.4.0', launch.version === '2.4.0');
  check('service worker identifies v2.4.0', worker.includes('const VERSION = "2.4.0"'));
  check('bridge identifies v2.4.0', bridge.includes("$Version = '2.4.0'"));
  check('tray identifies v2.4.0', tray.includes("$Version = '2.4.0'"));
  check('popup accepts v2.4.0 bridge', popup.includes('state.version !== "2.4.0"'));

  for (const className of ['cwn-progress-head','cwn-progress-state','cwn-progress-value','cwn-progress-track','cwn-progress-fill','cwn-progress-note']) {
    check(`overlay contains ${className}`, content.includes(className));
  }
  check('overlay remains bottom-right', content.includes('right:18px;bottom:92px'));
  check('overlay remains noninteractive', content.includes('pointer-events:none'));
  check('overlay renders explicit unknown progress', content.includes('Working — % unavailable'));
  check('overlay exposes an indeterminate state', content.includes('trackEl.dataset.indeterminate'));
  check('overlay verifies completion proof', content.includes('result.safeCompletion === true'));
  check('content heartbeat forwards proof', content.includes('safeCompletion: S.lastPayload?.safeCompletion === true'));
  check('content heartbeat forwards message identity', content.includes('messageId: S.lastPayload?.messageId || ""'));
  check('content progress binds to active assistant turn', content.includes('const currentAssistant = assistantForTurn(currentTurn);') && content.includes('turn.querySelectorAll(\'[data-message-author-role="assistant"]\')'));
  check('content reads streaming commentary from active turn container', content.includes('function assistantTextForTurn') && content.includes('const assistantText = assistantTextForTurn(currentTurn, currentAssistant);'));
  check('content title follows current sidebar conversation', content.includes('titleFromCurrentConversationLinks(document.querySelectorAll(\'a[href]\'), location.href)'));
  check('content detects finalized response controls', content.includes('function hasCompletedResponseControls') && content.includes('hasCompletedResponseControls: completedResponseControls'));
  check('content gates terminal reset on delivery acknowledgement', content.includes('terminalDeliveryConfirmed') && content.includes('if (!S.terminalDeliveryConfirmed) return;'));
  check('content retries undelivered terminal events', content.includes('terminalRetryTimer') && content.includes('terminalRetry: attempt + 1'));

  check('worker heartbeat forwards title', worker.includes('title: payload.chatTitle || tab.title || "ChatGPT"'));
  check('worker scans preserve sidebar-derived title', worker.includes('(data.tabs[String(tab.id)] || {}).title || tab.title || "ChatGPT"'));
  check('worker heartbeat forwards progress', worker.includes('progress,'));
  check('worker heartbeat forwards safe completion', worker.includes('safeCompletion,'));
  check('worker heartbeat stores message identity', worker.includes('messageId: payload.messageId || ""'));
  check('worker downgrades unsafe heartbeat completion', worker.includes('claimedStatus === "COMPLETE" && !safeCompletion ? "UNCERTAIN"'));
  check('worker clears proof outside completion', worker.includes('claimedStatus === "COMPLETE" && payload.safeCompletion === true'));
  check('worker heartbeat does not add events', !worker.slice(worker.indexOf('async function forwardHeartbeat'), worker.indexOf('async function forwardLifecycle')).includes('addEvent('));
  check('worker heartbeat clears recovered manual attention', worker.includes('MANUAL_ACTION_STATUSES.has(previousStatus) && !MANUAL_ACTION_STATUSES.has(status)'));
  check('worker clears stale completion notification at new run', worker.includes('changed && message.status === "RUNNING" ? null'));
  check('worker clears suppressed completion marker', worker.includes('message.status === "COMPLETE" ? null'));
  check('bridge clears stale completion marker', bridge.includes("$event.status -eq 'COMPLETE' -or ($event.status -eq 'RUNNING' -and $previousStatus -ne 'RUNNING')"));
  check('popup displays exact unknown wording', popup.includes('Working — % unavailable'));
  check('popup requires completion proof', popup.includes('current.safeCompletion === true'));
  check('popup rejects malformed completion rendering', popup.includes('claimedStatus === "COMPLETE" && !safeComplete ? "UNCERTAIN"'));
  check('popup tie-breaks on numeric tab id', popup.includes('Number(b.tabId || 0) - Number(a.tabId || 0)'));

  check('tray prefers authenticated dashboard state', tray.indexOf("'/dashboard-state' 'POST'") < tray.indexOf("'/state' 'GET'"));
  check('tray has one current-task selector', (tray.match(/function Select-CurrentTask/g) || []).length === 1);
  check('tray prioritizes only genuine user-action states', tray.includes("$manualStates = @('PAUSED','STUCK_THINKING','WAITING_INPUT','FAILED')"));
  check('tray keeps recoverable stale health quiet', tray.includes("Log 'Extension heartbeat is stale; automatic repair started without interrupting the user.' 'WARN'") && !tray.includes("Show-SyntheticPopup 'PAGE_STALE'"));
  check('tray ranks running second', tray.includes("elseif ([string]$_.status -eq 'RUNNING') { 1 }"));
  check('tray sorts newest update first', tray.includes('updatedAt) { [long]$_.updatedAt'));
  check('tray tie-breaks on highest tab id', tray.includes('tabId) { [long]$_.tabId'));
  check('tray excludes detached tasks', tray.includes("'DETACHED','CLOSED','PRUNED'"));
  check('tray dashboard has current task section', tray.includes('CURRENT CHATGPT TASK'));
  check('tray dashboard uses custom progress track', tray.includes('$currentProgressTrack = New-Object System.Windows.Forms.Panel'));
  check('tray dashboard uses custom progress fill', tray.includes('$currentProgressFill = New-Object System.Windows.Forms.Panel'));
  check('tray has no OS ProgressBar control', !tray.includes('System.Windows.Forms.ProgressBar'));
  check('tray unknown current item wording is exact', tray.includes('Current: RUNNING | % unavailable'));
  check('tray known current item includes progress', tray.includes('Current: $displayProgress%$estimateSuffix | $status'));
  check('tray no-task item wording is exact', tray.includes('Current: No active task'));
  check('tray current menu item is disabled', tray.includes('$miCurrent.Enabled = $false'));
  check('tray tooltip has dedicated bounded helper', tray.includes('function Set-TrayTooltip') && tray.includes('$Text.Substring(0,63)'));
  check('tray completion requires proof', tray.includes("$safeComplete = ($status -eq 'COMPLETE' -and [bool]$task.safeCompletion)"));
  check('tray malformed completion becomes uncertain', tray.includes("if ($status -eq 'COMPLETE' -and -not $safeComplete) { $status = 'UNCERTAIN' }"));
  check('tray window fits the compact tabbed dashboard', tray.includes('System.Drawing.Size(860, 700)') && tray.includes('New-DashboardTabShell'));
  check('dashboard lists all managed ChatGPT tabs', tray.includes('ALL MANAGED CHATGPT TABS'));
  check('per-tab progress list has one reusable updater', (tray.match(/function Update-AllTabProgressPresentation/g) || []).length === 1);
  check('per-tab progress list is scrollable', tray.includes('$allTabsHost.AutoScroll = $true'));
  check('per-tab rows have independent visual fills', tray.includes('$row.Fill.Width = [int][math]::Round($row.Track.Width * $progress / 100.0)'));
  check('per-tab unknown progress is explicit', tray.includes("$row.Progress.Text = if ($status -eq 'RUNNING') { '% unavailable' }"));
  check('per-tab rows are removed with closed tabs', tray.includes('$allTabsHost.Controls.Remove($row.Panel)'));

  const timeoutHtml = fixture('TIMEOUT_STALE_STOP.html');
  const pauseHtml = fixture('PAUSED_25M47S_75_PERCENT.html');
  const thinkingHtml = fixture('STUCK_THINKING.html');
  check('timeout fixture includes exact delivery timeout', timeoutHtml.includes('Message delivery timed out. Please try again.'));
  check('timeout fixture includes stale stop control', timeoutHtml.includes('data-testid="stop-button"'));
  let result = E.classify({ errorText: 'Message delivery timed out. Please try again.', assistantText: '100% complete.', stableMs: 60000, generationObserved: true });
  check('timeout fixture family classifies TIMEOUT', result.status === 'TIMEOUT');
  check('timeout fixture family cannot complete safely', result.safeCompletion === false);
  check('pause fixture includes exact worked duration', pauseHtml.includes('Worked for 25m 47s'));
  check('pause fixture includes explicit 75 percent', pauseHtml.includes('75% complete.'));
  result = E.classify({ assistantText: '75% complete.', workedText: 'Worked for 25m 47s', stableMs: 12000, generationObserved: true });
  check('pause fixture family classifies PAUSED', result.status === 'PAUSED');
  check('pause fixture family preserves 75 percent', result.progress === 75);
  check('pause fixture family is resumable', result.resumeEligible === true);
  result = E.classify({ assistantText: 'The program code still needs to consume that field. The finished validation should explicitly confirm the count.', hasCompletedResponseControls: true, stableMs: 9000, generationObserved: true, workLike: true });
  check('finalized advisory answer is not a false pause', result.status === 'COMPLETE' && result.resumeEligible === false && worker.includes('new Set(["PAUSED","STUCK_THINKING","WAITING_INPUT","FAILED"])'));
  result = E.classify({ assistantText: 'Here is the finished answer.', stableMs: 9000, generationObserved: true, workLike: true });
  check('stable ended work reply completes seamlessly', result.status === 'COMPLETE' && result.safeCompletion === true && result.manualAction === false && stateEngine.includes('s.generationObserved&&incomplete'));
  result = E.classify({ assistantText: 'This task remains incomplete. I still need to run tests.', hasCompletedResponseControls: true, stableMs: 9000, generationObserved: true, workLike: true });
  check('explicit unfinished work still fails closed', result.status === 'PAUSED' && result.resumeEligible === true);
  const thinkingBody = thinkingHtml.replace(/<!--[\s\S]*?-->/g, '');
  check('thinking fixture includes active Thinking indicator', thinkingBody.includes('>Thinking<'));
  check('thinking fixture has no real stop control', !thinkingBody.includes('data-testid="stop-button"'));
  result = E.classify({ hasThinkingIndicator: true, hasStopButton: false, thinkingStableMs: E.constants.STUCK_THINKING_MS + 1, stableMs: E.constants.STUCK_THINKING_MS + 1, generationObserved: true });
  check('thinking fixture family classifies STUCK_THINKING', result.status === 'STUCK_THINKING');
  check('thinking fixture family is resumable', result.resumeEligible === true);

  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'cwn-v240-'));
  const token = '0123456789abcdef0123456789abcdef';
  const tokenFile = path.join(temp, 'session-token.txt');
  fs.writeFileSync(tokenFile, token, { encoding: 'ascii', mode: 0o600 });
  const port = 41000 + Math.floor(Math.random() * 1500);
  const ps = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  const child = spawn(ps, ['-NoProfile','-ExecutionPolicy','Bypass','-File',path.join(root,'runtime','browser-bridge.ps1'),'-Port',String(port),'-SessionTokenFile',tokenFile,'-RuntimeBase',temp], { windowsHide: true, stdio: ['ignore','pipe','pipe'] });
  try {
    const initial = await waitForBridge(port, child);
    check('actual bridge starts online', initial.online === true);
    check('actual bridge reports Chrome-only mode', initial.mode === 'CHROME_ONLY');
    check('actual bridge reports v2.4.0', initial.version === '2.4.0');

    const origin = 'chrome-extension://aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';
    const baseEvent = { tabId: 7, windowId: 20, status: 'RUNNING', title: 'A'.repeat(250), url: 'https://chatgpt.com/c/secret-conversation', conversationId: 'secret-conversation', progress: null, runSeconds: 5, showPopup: false, safeCompletion: false, at: Date.now() };
    let response = await bridgeRequest(port, '/dashboard-state', { method: 'POST' });
    check('dashboard state rejects missing token', response.status === 403);

    for (const invalid of ['75', true, [], {}, -1, 100.01]) {
      response = await bridgeRequest(port, '/browser-event', { method: 'POST', token, origin, body: { ...baseEvent, progress: invalid } });
      check(`bridge rejects invalid progress ${JSON.stringify(invalid)}`, response.status === 400);
    }
    response = await bridgeRequest(port, '/browser-event', { method: 'POST', token, origin, raw: JSON.stringify(baseEvent).replace('"progress":null', '"progress":NaN') });
    check('bridge rejects NaN JSON progress', response.status === 400);
    response = await bridgeRequest(port, '/browser-event', { method: 'POST', token, origin, raw: JSON.stringify(baseEvent).replace('"progress":null', '"progress":Infinity') });
    check('bridge rejects Infinity JSON progress', response.status === 400);

    for (const valid of [null, 0, 75.5, 100]) {
      response = await bridgeRequest(port, '/browser-event', { method: 'POST', token, origin, body: { ...baseEvent, progress: valid } });
      check(`bridge accepts valid progress ${valid}`, response.status === 200);
    }

    response = await bridgeRequest(port, '/state');
    const publicTab = response.json.browser.tabs[0];
    check('public state exposes progress', publicTab.progress === 100);
    check('public state exposes updatedAt', Number.isFinite(publicTab.updatedAt));
    check('public state exposes safeCompletion', publicTab.safeCompletion === false);
    check('public state omits title', !Object.hasOwn(publicTab, 'title'));
    check('public state omits URL', !Object.hasOwn(publicTab, 'url'));
    check('public state omits conversation id', !Object.hasOwn(publicTab, 'conversationId'));

    response = await bridgeRequest(port, '/dashboard-state', { method: 'POST', token });
    const dashboardTab = response.json.browser.tabs[0];
    check('authenticated dashboard state succeeds', response.status === 200);
    check('dashboard state includes sanitized title', dashboardTab.title.length === 180);
    check('dashboard state omits URL', !Object.hasOwn(dashboardTab, 'url'));
    check('dashboard state omits conversation id', !Object.hasOwn(dashboardTab, 'conversationId'));

    const popupCount = response.json.browser.popupEvents.length;
    const eventAt = response.json.browser.lastEventAt;
    response = await bridgeRequest(port, '/browser-heartbeat', { method: 'POST', token, origin, body: { tabId: 7, windowId: 20, title: 'Heartbeat title', url: baseEvent.url, conversationId: baseEvent.conversationId, status: 'RUNNING', progress: 76, safeCompletion: true } });
    check('valid progress heartbeat succeeds', response.status === 200);
    response = await bridgeRequest(port, '/dashboard-state', { method: 'POST', token });
    check('heartbeat updates progress', response.json.browser.tabs[0].progress === 76);
    check('heartbeat updates title', response.json.browser.tabs[0].title === 'Heartbeat title');
    check('non-complete heartbeat clears proof', response.json.browser.tabs[0].safeCompletion === false);
    check('progress heartbeat does not queue popup', response.json.browser.popupEvents.length === popupCount);
    check('progress heartbeat does not create event', response.json.browser.lastEventAt === eventAt);

    response = await bridgeRequest(port, '/browser-heartbeat', { method: 'POST', token, origin, body: { tabId: 7, windowId: 20, status: 'RUNNING', progress: 100, progressEstimated: true, safeCompletion: false } });
    check('estimated heartbeat is accepted', response.status === 200);
    response = await bridgeRequest(port, '/dashboard-state', { method: 'POST', token });
    check('estimated 100 remains running without completion proof', response.json.browser.tabs[0].status === 'RUNNING' && response.json.browser.tabs[0].safeCompletion === false);
    check('dashboard retains estimate label', response.json.browser.tabs[0].progressEstimated === true);
    response = await bridgeRequest(port, '/browser-event', { method: 'POST', token, origin, body: { ...baseEvent, progress: 50, progressEstimated: true } });
    check('estimated event accepted', response.status === 200);
    response = await bridgeRequest(port, '/state');
    check('event retains estimate metadata', response.json.browser.tabs[0].progressEstimated === true && response.json.browser.tabs[0].progress === 50);

    response = await bridgeRequest(port, '/browser-heartbeat', { method: 'POST', token, origin, body: { tabId: 7, windowId: 20, title: 'Unsafe', status: 'COMPLETE', progress: 99, safeCompletion: false } });
    check('unsafe complete heartbeat is accepted for downgrade', response.status === 200);
    response = await bridgeRequest(port, '/state');
    check('unsafe complete heartbeat becomes uncertain', response.json.browser.tabs[0].status === 'UNCERTAIN');
    check('unsafe complete heartbeat has no proof', response.json.browser.tabs[0].safeCompletion === false);
    check('unsafe complete heartbeat suppresses terminal percentage', response.json.browser.tabs[0].progress === null);

    response = await bridgeRequest(port, '/browser-heartbeat', { method: 'POST', token, origin, body: { tabId: 7, windowId: 20, title: 'Safe', status: 'COMPLETE', progress: null, safeCompletion: true } });
    check('safe complete heartbeat succeeds', response.status === 200);
    response = await bridgeRequest(port, '/state');
    check('safe complete heartbeat remains complete', response.json.browser.tabs[0].status === 'COMPLETE');
    check('safe complete heartbeat exposes proof', response.json.browser.tabs[0].safeCompletion === true);
    check('safe complete heartbeat normalizes to 100', response.json.browser.tabs[0].progress === 100);

    response = await bridgeRequest(port, '/browser-heartbeat', { method: 'POST', token, origin, body: { tabId: 7, windowId: 20, status: 'RUNNING', progress: '76', safeCompletion: false } });
    check('heartbeat uses same strict progress validator', response.status === 400);

    response = await bridgeRequest(port, '/browser-tabs-sync', { method: 'POST', body: {tabIds:[]} });
    check('tab inventory requires authentication', response.status === 403);
    for (const invalid of [{}, {tabIds:null}, {tabIds:'7'}, {tabIds:[7,'8']}, {tabIds:[-1]}, {tabIds:[true]}, {tabIds:[1.5]}]) {
      response = await bridgeRequest(port, '/browser-tabs-sync', { method: 'POST', token, origin, body: invalid });
      check(`tab inventory rejects ${JSON.stringify(invalid)}`, response.status === 400);
    }
    response = await bridgeRequest(port, '/state');
    check('invalid inventory never clears existing tasks', response.json.browser.tabs.some(t => t.tabId === 7));
    response = await bridgeRequest(port, '/browser-event', { method: 'POST', token, origin, body: {...baseEvent,tabId:99} });
    check('orphan fixture created', response.status === 200);
    response = await bridgeRequest(port, '/browser-tabs-sync', { method: 'POST', token, origin, body: {tabIds:[7]} });
    check('inventory removes exactly the closed tab', response.status === 200 && response.json.removed === 1);
    response = await bridgeRequest(port, '/dashboard-state', { method: 'POST', token });
    check('dashboard reflects actual remaining tabs', response.json.browser.tabCount === 1 && response.json.browser.tabs[0].tabId === 7);
    response = await bridgeRequest(port, '/browser-tabs-sync', { method: 'POST', token, origin, body: {tabIds:[]} });
    check('empty inventory is accepted for closed managed window', response.status === 200);
    response = await bridgeRequest(port, '/dashboard-state', { method: 'POST', token });
    check('closed window leaves no dashboard rows', response.json.browser.tabCount === 0 && response.json.browser.tabs.length === 0);

  } finally {
    child.kill();
    await new Promise(resolve => child.once('exit', resolve)).catch(() => {});
    fs.rmSync(temp, { recursive: true, force: true });
  }

  check('combined regression matrix has at least 60 items', checks.length >= 60);
  console.log(`PASS v240-repair-regression.test.js: ${checks.length} checks`);
})().catch(error => { console.error(error); process.exit(1); });
