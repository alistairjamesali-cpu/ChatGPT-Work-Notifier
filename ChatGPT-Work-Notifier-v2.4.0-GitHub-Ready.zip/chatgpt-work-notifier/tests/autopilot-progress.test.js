const assert = require('assert');
const fs = require('fs');
const vm = require('vm');
const E = require('../state-engine.js');
const source = fs.readFileSync(require('path').join(__dirname, '..', 'content.js'), 'utf8');
let draft = '', sent = 0, continued = 0, sendVisible = true, stop = false, allowed = true, attached = false;
let permissionWait = null;
const saved = new Map();
const visibleButton = click => ({ isConnected: true, disabled: false, getAttribute: () => '', getBoundingClientRect: () => ({ width: 20, height: 20 }), click });
const send = visibleButton(() => { sent++; draft = ''; });
send.closest = () => form;
const cont = { ...visibleButton(() => { continued++; }), innerText: 'Continue generating' };
let continuation = false;
const form = { querySelectorAll: () => [], querySelector: () => attached ? {} : null };
class Textarea {
  isConnected = true;
  getBoundingClientRect() { return { width: 200, height: 50 }; }
  get value() { return draft; }
  set value(v) { draft = v; }
  dispatchEvent() {}
  closest() { return form; }
}
const textarea = new Textarea();
const turn = { querySelectorAll: () => continuation ? [cont] : [] };
const document = {
  documentElement: {}, addEventListener() {},
  querySelector(selector) { return selector.startsWith('textarea') ? textarea : null; },
  querySelectorAll(selector) {
    if (selector.includes('data-turn="assistant"')) return [turn];
    if (selector.includes('send-button')) return sendVisible ? [send] : [];
    if (selector.includes('stop-button')) return stop ? [send] : [];
    return [];
  }
};
const context = {
  CWNStateEngine: E, document, location: { href: 'https://chatgpt.com/c/test' },
  chrome: { runtime: { onMessage: { addListener() {} }, async sendMessage() { if (permissionWait) await permissionWait; return { allowed }; } } },
  sessionStorage: { getItem: k => saved.get(k), setItem: (k,v) => saved.set(k,v) },
  window: { addEventListener() {} }, MutationObserver: class { observe() {} },
  getComputedStyle: () => ({ display: 'block', visibility: 'visible' }),
  HTMLTextAreaElement: Textarea, InputEvent: class {}, Event: class {}, URL, console,
  setTimeout() {}, clearTimeout() {}, setInterval() {}
};
vm.createContext(context);
vm.runInContext(source.replace(/\}\)\(\);\s*$/, 'globalThis.testHooks = { S, autoResume, withEstimatedProgress, setSnapshot(fn) { snapshot = fn; } };\n})();'), context);
const { S, autoResume, withEstimatedProgress, setSnapshot } = context.testHooks;
Object.assign(S, { managed: true, monitoringEnabled: true, generationObserved: true, runStartedAt: 1000 });
let snap;
function paused(id) {
  snap = { assistantText: '75% complete. Work remains.', progressPercent: 75, generationObserved: true, stableMs: 9000, messageId: id, composerEmpty: draft === '' };
  setSnapshot(() => ({ ...snap, composerEmpty: draft === '', hasStopButton: stop }));
  return E.classify(snap);
}
(async () => {
  let r = withEstimatedProgress({ status: 'RUNNING', progress: null, safeCompletion: false }, 1000 + 13*60*1000);
  assert.strictEqual(r.progress, 50); assert.strictEqual(r.progressEstimated, true); assert.strictEqual(r.safeCompletion, false);
  r = withEstimatedProgress({ status: 'RUNNING', progress: null, safeCompletion: false }, 1000 + 26*60*1000);
  assert.strictEqual(r.progress, 100); assert.strictEqual(r.status, 'RUNNING'); assert.strictEqual(r.safeCompletion, false);
  assert.strictEqual(withEstimatedProgress({ status: 'RUNNING', progress: null }, 1000 + 60*60*1000).progress, 100);
  assert.strictEqual(withEstimatedProgress({ status: 'RUNNING', progress: 65 }, 1000 + 13*60*1000).progress, 65);
  S.generationObserved = false;
  assert.strictEqual(withEstimatedProgress({ status: 'IDLE', progress: null }, 9999999).progress, null);
  S.generationObserved = true;
  await autoResume(paused('first')); assert.strictEqual(sent, 1, 'Resume is sent automatically');
  await autoResume(paused('first')); assert.strictEqual(sent, 1, 'same incident cannot send twice');
  S.autoResumeAttempts.clear();
  await autoResume(paused('first')); assert.strictEqual(sent, 1, 'session journal prevents duplicate after reload');
  draft = 'My unfinished prompt'; await autoResume(paused('draft')); assert.strictEqual(sent, 1); assert.strictEqual(draft, 'My unfinished prompt');
  draft = 'Resume'; await autoResume(paused('user-resume')); assert.strictEqual(sent, 1, 'user-written Resume is a draft too');
  draft = ''; attached = true; await autoResume(paused('attachment')); assert.strictEqual(sent, 1); attached = false;
  allowed = false; await autoResume(paused('disabled')); assert.strictEqual(sent, 1); allowed = true;
  const candidate = paused('stopped'); stop = true; await autoResume(candidate); assert.strictEqual(sent, 1); stop = false;
  const waiting = paused('waiting'); snap.waitingInput = true; await autoResume(waiting); assert.strictEqual(sent, 1);
  sendVisible = false; await autoResume(paused('late-button')); assert.strictEqual(draft, 'Resume'); assert.strictEqual(sent, 1);
  sendVisible = true; await autoResume(paused('late-button')); assert.strictEqual(sent, 2, 'react-rendered Send is retried without overwriting the prepared draft');
  continuation = true; await autoResume(paused('continue')); assert.strictEqual(continued, 1); assert.strictEqual(sent, 2); assert.strictEqual(draft, ''); continuation = false;
  let release; permissionWait = new Promise(resolve => { release = resolve; });
  const pending = autoResume(paused('racing'));
  await autoResume(paused('racing')); // overlapping mutation scan
  release(); await pending; permissionWait = null; assert.strictEqual(sent, 3);
  permissionWait = new Promise(resolve => { release = resolve; });
  const navigation = autoResume(paused('navigation'));
  context.location.href = 'https://chatgpt.com/c/other'; release(); await navigation; permissionWait = null;
  assert.strictEqual(sent, 3, 'navigation while checking authority cancels submission');
  console.log('PASS autopilot-progress.test.js: automatic Resume, Continue, drafts, attachments, duplicate/race protection and 26-minute estimates');
})().catch(e => { console.error(e); process.exitCode = 1; });
