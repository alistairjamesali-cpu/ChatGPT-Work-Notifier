from pathlib import Path
import json, os, re, subprocess, sys

ROOT = Path(__file__).resolve().parents[1]
checks = []

def add(name, ok, evidence=''):
    checks.append((name, bool(ok), evidence))

def txt(rel):
    return (ROOT / rel).read_text(encoding='utf-8-sig')

def has(rel, *needles):
    s = txt(rel)
    return all(n in s for n in needles)

# Whole-tree line-by-line hygiene. Binary assets are excluded from text decoding.
text_ext = {'.js','.json','.ps1','.bat','.vbs','.py','.md','.txt','.html','.css'}
generated_evidence = {'FINAL_100_LINE_BY_LINE_AUDIT_REPORT.txt','STATIC_AUDIT_REPORT.txt','FILE_SHA256SUMS.txt'}
text_files = [p for p in ROOT.rglob('*') if p.is_file() and p.suffix.lower() in text_ext and '__pycache__' not in p.parts and p.name not in generated_evidence]
all_bytes = b''.join(p.read_bytes() for p in text_files)
all_lines = []
for p in text_files:
    raw = p.read_bytes()
    text = raw.decode('utf-8-sig')
    all_lines.extend((p, i+1, line) for i, line in enumerate(text.splitlines()))

# 1-10 Package/tree hygiene.
add('A01 single release implementation root with one obvious BAT launcher', (ROOT/'manifest.json').is_file() and (ROOT/'runtime').is_dir() and (ROOT/'tests').is_dir() and sorted(p.name for p in ROOT.glob('*.bat')) == ['START_CHATGPT_WORK_NOTIFIER.bat'])
add('A02 no nested duplicate release root', not any(p.is_dir() and p != ROOT and p.name.startswith('ChatGPT_Work_Notifier_v') for p in ROOT.rglob('*')))
add('A03 no Python cache artifacts', not any('__pycache__' in p.parts or p.suffix == '.pyc' for p in ROOT.rglob('*')))
add('A04 all text files UTF-8 decodable', all(p.read_bytes().decode('utf-8-sig') is not None for p in text_files))
add('A05 no UTF-8 BOM in shipped source text', all(not p.read_bytes().startswith(b'\xef\xbb\xbf') for p in text_files))
add('A06 no NUL bytes in shipped text', all(b'\x00' not in p.read_bytes() for p in text_files))
add('A07 no trailing whitespace line-by-line', all(line.rstrip() == line for _,_,line in all_lines))
add('A08 no unresolved TODO/FIXME/HACK markers', not any(re.search(r'\b(?:TODO|FIXME|HACK|XXX|TBD)\b', line, re.I) for path,_,line in all_lines if path.name != 'final-100-audit.py'))
add('A09 manifest JSON parses', isinstance(json.loads(txt('manifest.json')), dict))
add('A10 chrome-launch JSON parses', isinstance(json.loads(txt('runtime/chrome-launch.json')), dict))

manifest = json.loads(txt('manifest.json'))
launch = json.loads(txt('runtime/chrome-launch.json'))
sw = txt('service-worker.js'); content = txt('content.js'); bootstrap = txt('managed-bootstrap.js')
bridge = txt('runtime/browser-bridge.ps1'); host = txt('runtime/tray-host.ps1')
install = txt('runtime/install.ps1'); uninstall = txt('runtime/uninstall.ps1'); popup = txt('popup.js')+txt('popup.html')+txt('popup.css')
verify = txt('tests/VERIFY_RUNTIME.ps1'); static = txt('tests/static-audit.py'); codex = txt('CODEX_FINALISE_NO_THINKING.md')

# 11-20 Manifest/session bootstrap boundaries.
add('A11 Manifest V3 only', manifest.get('manifest_version') == 3)
add('A12 release version is 2.4.0', manifest.get('version') == '2.4.0' and launch.get('version') == '2.4.0')
add('A13 minimum Chrome version declared', int(manifest.get('minimum_chrome_version','0')) >= 120)
add('A14 permissions limited to required notifier APIs', set(manifest.get('permissions',[])) == {'alarms','notifications','storage','tabs','windows'})
add('A15 host permissions limited to ChatGPT and loopback', set(manifest.get('host_permissions',[])) == {'https://chatgpt.com/*','https://chat.openai.com/*','http://127.0.0.1:38765/*'})
add('A16 managed token bootstrap runs at document_start', any(cs.get('run_at')=='document_start' and cs.get('js')==['managed-bootstrap.js'] for cs in manifest.get('content_scripts',[])))
add('A17 hardened state engine and main detector remain document_idle', any(cs.get('run_at')=='document_idle' and cs.get('js')==['state-engine.js','content.js'] for cs in manifest.get('content_scripts',[])))
add('A18 bootstrap validates 32-hex managed token', '^[a-f0-9]{32}$' in bootstrap)
add('A19 bootstrap stores token only in tab sessionStorage', 'sessionStorage.setItem("cwn_managed_token"' in bootstrap and 'localStorage' not in bootstrap)
add('A20 content has query-or-session token fallback', 'sessionStorage.getItem("cwn_managed_token")' in content)

# 21-35 Content detector/recovery behavior.
add('A21 MutationObserver drives DOM detection', 'new MutationObserver' in content)
add('A22 low-frequency DOM fallback is five seconds', 'SCAN_FALLBACK_MS = 5000' in content and 'setInterval(() => scan(false), SCAN_FALLBACK_MS)' in content)
add('A23 extension heartbeat cadence is 20 seconds', 'HEARTBEAT_MS = 20 * 1000' in content)
add('A24 command polling cadence is 3 seconds', 'COMMAND_POLL_MS = 3000' in content)
add('A25 no fake mouse input', not any(x in content for x in ['new MouseEvent','mousemove','dispatchEvent(new Mouse']))
add('A26 no fake keyboard input', 'new KeyboardEvent' not in content)
add('A27 visibility state is observed not forged', 'document.visibilityState' in content and 'document.hasFocus()' in content and 'defineProperty(document' not in content)
add('A28 content never fetches ChatGPT network endpoints', not re.search(r'fetch\s*\(\s*[`\"\']https://(?:chatgpt\.com|chat\.openai\.com)', content, re.I))
add('A29 timeout recovery is globally rate-limited to 15 minutes and four per six hours', all(x in sw for x in ['REFRESH_COOLDOWN_MS = 15 * 60 * 1000','REFRESH_WINDOW_MS = 6 * 60 * 60 * 1000','REFRESH_MAX_PER_WINDOW = 4']))
add('A30 timeout refresh preserves Continue pauses and composer drafts while allowing stale Stop recovery', all(x in sw for x in ['state.hasContinueButton === true','state.composerEmpty === false','preserved the live job','preserved the draft']) and 'state.hasStopButton === true || state.hasContinueButton === true' not in sw)
add('A31 timeout reload rechecks live page state immediately before cached reload', all(x in sw for x in ['probeTabState(tabId)','state.status !== "TIMEOUT"','chrome.tabs.reload(tabId, { bypassCache: false })']))
add('A32 pending timeout recovery is tab/message/conversation scoped', all(x in sw for x in ['messageId: message.messageId || ""','conversationId','sameConversation','CWNCore.conversationIdentity(tab.url || "")']))
add('A33 online/offline browser events are handled', 'addEventListener("offline"' in content and 'addEventListener("online"' in content)
add('A34 state delivery retries before marking sent', 'setTimeout(r => setTimeout(r, 750))' not in content and 'new Promise(r => setTimeout(r, 750))' in content and ('if (response?.ok) S.lastSentSignature = sig' in content or 'const delivered = Boolean(response?.ok)' in content))
add('A35 terminal states, active-turn container progress, finalized-response proof, sidebar title, and extended-thinking/tool RUNNING evidence are classified', all(x in content for x in ['"COMPLETE"','"WAITING_INPUT"','"PAUSED"','"FAILED"','hasExtendedThinkingBanner','hasActiveToolActivity','hasCompletedResponseControls','titleFromCurrentConversationLinks','assistantTextForTurn','Our systems are thinking a bit more about this request before responding','const currentAssistant = assistantForTurn(currentTurn);']))

# 36-55 Service worker concurrency/lifecycle.
add('A36 reliability core imported in service worker', 'importScripts("reliability-core.js")' in sw)
add('A37 shared local state mutations are serialized', 'localMutationQueue' in sw and 'withLocalMutation' in sw)
add('A38 tab record updates use serialized mutation', 'async function updateTabRecord' in sw and 'return await withLocalMutation' in sw)
add('A39 tab record removals use serialized mutation', 'async function removeTabRecord' in sw and 'const existed = Boolean(tabs[key])' in sw)
add('A40 event+tab writes are atomic in one serialized mutation', 'async function addEvent' in sw and 'await chrome.storage.local.set({ events, tabs })' in sw)
add('A41 command leader election is serialized and reasserted after early registration', 'leaderElectionQueue' in sw and 'afterLocalMutations' in sw and 'reassert the role on later heartbeats' in sw)
add('A42 managed registration is session-token based', 'REGISTER_MANAGED_WINDOW' in sw and 'managedSessionToken' in sw)
add('A43 sender validation is restricted to the captured managed window', 'live.windowId === data.managedWindowId' in sw and 'sender.tab.windowId === live.windowId' in sw)
add('A44 ordinary Chrome windows are explicitly ignored', 'if (!tracked && !inManagedWindow) return' in sw and 'MOVED_OUTSIDE_MANAGED_WINDOW' in sw)
add('A45 every managed ChatGPT tab is non-discardable', 'autoDiscardable: false' in sw and 'verified.autoDiscardable === false' in sw)
add('A46 scans are restricted to the captured managed window', 'chrome.tabs.query({ windowId: data.managedWindowId })' in sw)
add('A47 navigate-away lifecycle is recorded', 'NAVIGATED_AWAY' in sw)
add('A48 navigate-away tab record is removed', 'reason: "navigated-away"' in sw and 'await removeTabRecord(tabId)' in sw)
add('A49 tab detach lifecycle is handled', 'chrome.tabs.onDetached.addListener' in sw)
add('A50 tab reattach lifecycle is handled', 'chrome.tabs.onAttached.addListener' in sw)
add('A51 renderer/tab replacement is handled', 'chrome.tabs.onReplaced.addListener' in sw and 'RENDERER_REPLACED' in sw)
add('A52 closed tabs are removed from bridge and local state', 'chrome.tabs.onRemoved.addListener' in sw and '/browser-tab-closed' in sw)
add('A53 captured window closure clears the managed session', 'managedWindowId: null, managedSessionToken: null, tabs: {}' in sw)
add('A54 one-minute health alarm rescans protection', 'periodInMinutes: 1' in sw and 'scanAndProtectManagedTabs' in sw)
add('A55 duplicate notifications have persistent and volatile gates', 'shouldNotifyTransition' in sw and 'volatileCooldowns' in sw)

# 56-70 Loopback bridge/security/reliability.
add('A56 bridge binds IPAddress.Loopback', 'IPAddress]::Loopback' in bridge)
add('A57 bridge origin guard restricts Chrome extension origins', 'chrome-extension://[a-p]{32}' in bridge and "403 'Forbidden'" in bridge)
add('A58 bridge request body capped at 16 KiB', '16384' in bridge and 'Request body too large' in bridge)
add('A59 accepted socket receive timeout is two seconds', 'ReceiveTimeout = 2000' in bridge)
add('A60 accepted socket send timeout is two seconds', 'SendTimeout = 2000' in bridge)
add('A61 bridge status events use allowlist', 'allowedStatuses' in bridge and 'Invalid status.' in bridge)
add('A62 heartbeat states use separate allowlist', 'heartbeatStatuses' in bridge and 'Invalid heartbeat status.' in bridge)
add('A63 bridge accepts status metadata not prompt/response text', 'Prompt and response text are never accepted' in bridge)
add('A64 bridge contains no external HTTP client calls', 'Invoke-WebRequest' not in bridge and 'Invoke-RestMethod' not in bridge)
add('A65 stale pending commands expire after a bounded 75 seconds', 'pendingCommand.createdAt -gt 75000' in bridge)
add('A66 command acknowledgements clear pending command', '$script:pendingCommand = $null' in bridge and '/command-ack' in bridge)
add('A67 bridge tab records expose heartbeat age', 'heartbeatAgeSeconds' in bridge)
add('A68 bridge removes closed/detached/missed-navigate-away tab records', 'browser-tab-closed' in bridge and 'browserTabs.Remove' in bridge and 'managed-scan-prune' in sw)
add('A69 bridge mode is CHROME_ONLY', "mode = 'CHROME_ONLY'" in bridge)
add('A70 bridge version is 2.4.0', "$Version = '2.4.0'" in bridge)

# 71-85 Windows tray/profile/Chrome reliability.
add('A71 Windows awake protection uses SetThreadExecutionState', 'SetThreadExecutionState' in host and '0x80000001' in host)
add('A72 awake protection clears on pause/exit', 'SetThreadExecutionState(0x80000000)' in host)
add('A73 display-awake remains optional and default off', 'keepDisplayAwake = $false' in host and '0x00000002' in host)
add('A74 lid-close policy is explicitly not modified', 'does not change the lid policy' in host and 'powercfg /set' not in host.lower())
add('A75 managed Chrome uses the original Chrome user-data directory', '--user-data-dir=' not in host and 'usesOriginalChromeProfile = $true' in host)
add('A76 managed Chrome retains selected original profile name', '--profile-directory=' in host and 'Get-ChromeLastProfile' in host)
add('A77 no process-wide background switches are configured', launch.get('requiredSwitches',[]) == [])
add('A78 dangerous Chrome switches are prohibited', all(x in launch.get('prohibitedSwitches',[]) for x in ['--no-sandbox','--disable-web-security','--ignore-certificate-errors','--allow-running-insecure-content']))
add('A79 required launch switches are de-duplicated', 'Add-UniqueArgument' in host and "-split '=',2" in host)
add('A80 no profile-copy helper is shipped', not (ROOT/'runtime/profile-bootstrap.ps1').exists())
add('A81 runtime state declares original-profile use', 'usesOriginalChromeProfile = $true' in host)
add('A82 newly opened Chrome window is captured by HWND difference', 'Wait-ForManagedChromeWindow([long[]]$Before)' in host and '$before = @([CwnWin32]::ChromeWindows())' in host)
add('A83 per-tab Memory Saver protection remains enabled', 'autoDiscardable: false' in sw and 'verified.autoDiscardable === false' in sw)
add('A84 restart closes only the captured HWND', 'PostMessage($oldHwnd, 0x0010' in host and 'Get-ManagedChromeBrowserProcess' not in host)
add('A85 extension setup uses the same profile without user-data override', 'existing Chrome profile' in host and '--user-data-dir=' not in host)

# 86-95 UI/recovery/install boundaries.
add('A86 hide-to-tray hides only the captured Chrome window', 'foreach ($h in $handles)' in host and 'ShowWindow([IntPtr][long]$h, 0)' in host)
add('A87 show restores only the captured Chrome window', 'ShowWindow([IntPtr][long]$h, 9)' in host and 'SetForegroundWindow($script:ManagedHwnd)' in host)
add('A88 hung Chrome detection exists', 'IsHungAppWindow' in host and 'HungMisses' in host)
add('A89 automatic restart and window recreation are suppressed during RUNNING work', all(x in host for x in ['Automatic Chrome restart suppressed because a managed tab reports RUNNING','Automatic managed-window recreation suppressed because a managed tab reports RUNNING']))
add('A90 staged recovery exposes health states and repairs a stale extension quietly', all(x in host for x in ['HEALTHY','DEGRADED','REPAIRING','RECOVERED','ExtensionStaleAlerted','automatic repair started without interrupting the user']) and "Show-SyntheticPopup 'PAGE_STALE'" not in host)
add('A91 correct-tab popup routing is lossless and uses the live popup target tab id', all(x in host for x in ['/request-tab-focus','Open correct ChatGPT tab','LastPopupSequence','$activeEvent = $script:PopupEvent']) and all(x in bridge for x in ['popupEvents = New-Object System.Collections.ArrayList','while ($script:popupEvents.Count -gt 64)']))
add('A92 tray/bridge process stop prefers notifier-owned PID/path', 'bridge.pid' in host and 'ProcessId=$bridgePid' in host)
add('A93 UI is compact and professional, tab boundaries and a unified task-level visibility row are present, explicit UI hiding works, and image resources are release-safe', 'FromArgb(37,99,235)' in host and 'notifier.ico' in host and '#2563eb' in popup.lower() and 'System.Drawing.Size(860, 700)' in host and 'ALL MANAGED CHATGPT TABS' in host and '$allTabsHost.AutoScroll = $true' in host and "$tasks.Text = 'Tasks'" in host and "$controls.Text = 'Controls'" in host and "$reliability.Text = 'Reliability'" in host and '$controlsPage.Controls.Add($settingsPanel)' in host and '$reliabilityPage.Controls.Add($reliabilityPanel)' in host and 'Move-ChromeButtonsToTasks $overviewPage $btnShow $btnHide $btnHideDashboard' in host and '$HideUiButton.Location = New-Object System.Drawing.Point(297,462)' in host and "$btnHideDashboard.Text = 'Hide UI to tray'" in host and 'Hide-DashboardUi $form' in host and '$area.Right - $popup.Width - 22' in host and '$surface.BringToFront()' in host and all(x in host for x in ['$sourceImage.Dispose()','$sourceLogo.Dispose()','$sourceIcon.Dispose()']))
add('A94 install preserves existing user settings on upgrade', 'if (-not (Test-Path $settingsFile))' in install)
add('A95 uninstall closes only the captured HWND and preserves ordinary Chrome', 'CwnUninstallWindow' in uninstall and 'PostMessage($hwnd, 0x0010' in uninstall and "$_.'Name' -eq 'chrome.exe'" not in uninstall and "Name -eq 'chrome.exe'" not in uninstall)

# 96-100 Reproducible regression/handoff gates.
try:
    cp1 = subprocess.run(['node', str(ROOT/'tests/state-engine-v221.test.js')], capture_output=True, text=True, timeout=20)
    cp2 = subprocess.run(['node', str(ROOT/'tests/request-regression-v221.test.js')], capture_output=True, text=True, timeout=20)
    cp3 = subprocess.run(['node', str(ROOT/'tests/reliability-core.test.js')], capture_output=True, text=True, timeout=20)
    add('A96 state-engine/request-regression/reliability-core tests pass', cp1.returncode == 0 and cp2.returncode == 0 and cp3.returncode == 0, ((cp1.stdout+cp1.stderr)+(cp2.stdout+cp2.stderr)+(cp3.stdout+cp3.stderr)).strip())
except Exception as e:
    add('A96 state-engine/request-regression/reliability-core tests pass', False, str(e))
try:
    cp = subprocess.run(['node', str(ROOT/'tests/service-worker-multitab.test.js')], capture_output=True, text=True, timeout=30)
    cp_v240 = subprocess.run(['node', str(ROOT/'tests/v240-repair-regression.test.js')], capture_output=True, text=True, timeout=30)
    powershell = Path(os.environ.get('SystemRoot', r'C:\Windows'))/'System32/WindowsPowerShell/v1.0/powershell.exe'
    cp_tabs = subprocess.run([str(powershell),'-NoProfile','-ExecutionPolicy','Bypass','-STA','-File',str(ROOT/'tests/TRAY_PROGRESS_PRESENTATION_TEST.ps1')], capture_output=True, text=True, timeout=30)
    add('A97 concurrent/multi-tab, v2.4.0, and flexible per-tab UI regressions pass', cp.returncode == 0 and cp_v240.returncode == 0 and cp_tabs.returncode == 0, ((cp.stdout+cp.stderr)+(cp_v240.stdout+cp_v240.stderr)+(cp_tabs.stdout+cp_tabs.stderr)).strip())
except Exception as e:
    add('A97 concurrent/multi-tab, v2.4.0, and flexible per-tab UI regressions pass', False, str(e))
try:
    cp = subprocess.run([sys.executable, str(ROOT/'tests/static-audit.py')], capture_output=True, text=True, timeout=60)
    m = re.search(r'STATIC RESULT: (\d+)/(\d+) PASS', cp.stdout)
    add('A98 expanded static audit passes', cp.returncode == 0 and bool(m) and m.group(1) == m.group(2), cp.stdout.strip().splitlines()[-1] if cp.stdout.strip() else cp.stderr.strip())
except Exception as e:
    add('A98 expanded static audit passes', False, str(e))
add('A99 Windows runtime verifier includes parser and original-profile gates', 'System.Management.Automation.Language.Parser' in verify and 'Original profile preserved' in verify)
add('A100 v2.4.0 handoff has a fresh manifest and no replacement ZIP requirement', (ROOT/'V240_IMPLEMENTATION_EVIDENCE.md').is_file() and (ROOT/'FILE_SHA256SUMS.txt').is_file())

assert len(checks) == 100, len(checks)
failed = [c for c in checks if not c[1]]
print(f'FINAL 100 MATERIAL AUDIT — {100-len(failed)}/100 PASS')
print(f'Line-by-line text scope: {len(all_lines)} lines across {len(text_files)} text/code files.')
for name, ok, evidence in checks:
    suffix = f' — {evidence}' if evidence else ''
    print(f'{"PASS" if ok else "FAIL"} {name}{suffix}')
sys.exit(1 if failed else 0)
