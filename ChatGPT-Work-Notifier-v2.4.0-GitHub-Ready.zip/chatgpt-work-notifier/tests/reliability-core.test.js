const assert = require('assert');
const core = require('../reliability-core.js');

assert.strictEqual(core.isChatGptUrl('https://chatgpt.com/c/abc'), true);
assert.strictEqual(core.isChatGptUrl('https://chat.openai.com/'), true);
assert.strictEqual(core.isChatGptUrl('https://example.com/'), false);
assert.strictEqual(core.conversationIdentity('https://chatgpt.com/c/abc_123'), 'abc_123');
assert.strictEqual(core.conversationIdentity('https://chatgpt.com/'), null);

const now = Date.now();
assert.strictEqual(core.shouldNotifyTransition(null, { status: 'COMPLETE' }, now, 8000), true);
assert.strictEqual(core.shouldNotifyTransition({ status: 'RUNNING' }, { status: 'COMPLETE' }, now, 8000), true);
assert.strictEqual(core.shouldNotifyTransition({ status: 'COMPLETE', lastNotifiedAt: now - 1000 }, { status: 'COMPLETE' }, now, 8000), false);
assert.strictEqual(core.shouldNotifyTransition({ status: 'COMPLETE', lastNotifiedAt: now - 9000 }, { status: 'COMPLETE', forceNotification: true }, now, 8000), true);

assert.strictEqual(core.recoveryStage({ chromeAlive:false }), 'WINDOW_RECOVERY');
assert.strictEqual(core.recoveryStage({ chromeAlive:true, bridgeOnline:false }), 'BRIDGE_RECONNECT');
assert.strictEqual(core.recoveryStage({ chromeAlive:true, bridgeOnline:true, extensionFresh:false }), 'EXTENSION_RECONNECT');
assert.strictEqual(core.recoveryStage({ chromeAlive:true, bridgeOnline:true, extensionFresh:true, tabPresent:false }), 'TAB_REATTACH');
assert.strictEqual(core.recoveryStage({ chromeAlive:true, bridgeOnline:true, extensionFresh:true, tabPresent:true, pageStale:true, safeReloadAllowed:true, validResponseRunning:true }), 'HEALTHY');
assert.strictEqual(core.recoveryStage({ chromeAlive:true, bridgeOnline:true, extensionFresh:true, tabPresent:true, pageStale:true, safeReloadAllowed:true, validResponseRunning:false }), 'CONTROLLED_RELOAD');

const args = core.dedupeSwitches([
  '--disable-renderer-backgrounding', '--disable-renderer-backgrounding',
  '--profile-directory=Default', '--profile-directory=Profile 1', '--new-window'
]);
assert.deepStrictEqual(args, ['--disable-renderer-backgrounding','--profile-directory=Default','--new-window']);

console.log('PASS reliability-core.test.js');
