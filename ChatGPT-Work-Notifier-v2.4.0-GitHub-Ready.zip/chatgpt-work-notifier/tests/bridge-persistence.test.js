const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const root = path.resolve(__dirname, '..');
const token = '0123456789abcdef0123456789abcdef';
const ps = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function req(port, route, body) {
  const response = await fetch(`http://127.0.0.1:${port}${route}`, { method: 'POST', headers: { 'X-CWN-Token': token, Origin: 'chrome-extension://aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  return { status: response.status, json: await response.json() };
}
async function start(port, dir) {
  const child = spawn(ps, ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(root, 'runtime', 'browser-bridge.ps1'), '-Port', String(port), '-SessionTokenFile', path.join(dir, 'token.txt'), '-RuntimeBase', dir], { windowsHide: true, stdio: 'ignore' });
  for (let i = 0; i < 80; i++) { try { const r = await fetch(`http://127.0.0.1:${port}/state`); if (r.status === 200) return child; } catch (_) {} await sleep(50); }
  throw new Error('bridge did not start');
}
(async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cwn-bridge-')); fs.writeFileSync(path.join(dir, 'token.txt'), token);
  const port = 43000 + Math.floor(Math.random() * 500); let child = await start(port, dir);
  const eventId = 'completion:episode:persist';
  let r = await req(port, '/browser-event', { tabId: 4, windowId: 8, status: 'COMPLETE', title: 'Persist', url: 'https://chatgpt.com/c/persist', conversationId: 'persist', progress: 82, safeCompletion: true, showPopup: true, eventId, episodeId: 'episode:persist', episodeRevision: 3 });
  assert.strictEqual(r.status, 200); child.kill(); await sleep(250);
  child = await start(port, dir); r = await req(port, '/dashboard-state', {});
  assert.ok(r.json.browser.popupEvents.some(x => x.eventId === eventId));
  r = await req(port, '/browser-event-ack', { eventId }); assert.strictEqual(r.status, 200);
  child.kill(); await sleep(150); fs.rmSync(dir, { recursive: true, force: true }); console.log('PASS bridge-persistence.test.js');
})().catch(e => { console.error(e); process.exit(1); });
