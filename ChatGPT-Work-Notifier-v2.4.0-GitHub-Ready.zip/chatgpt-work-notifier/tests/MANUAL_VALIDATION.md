# v2.4.0 Manual Validation Matrix

Run on the target Windows 11 machine after loading/reloading the unpacked extension from this exact release root in the user's normal Chrome profile. Do not mark a row PASS unless it was exercised.

| Test | Procedure | PASS condition |
|---|---|---|
| Original Chrome identity | Start notifier while normal Chrome is signed in to ChatGPT. | Managed window uses the same profile/session; no copied profile is created. |
| Ordinary-window isolation | Leave an ordinary Chrome window open. | Ordinary window is not hidden, closed, enrolled, or altered. |
| Visible/minimized/hidden | Run a response with managed window visible, minimized, then hidden. | Heartbeats and state updates continue. |
| Exact-tab routing | Trigger an alert in a non-active managed tab and click the notifier alert. | Captured window restores and the exact originating tab activates. |
| Multiple conversations | Use several managed ChatGPT tabs. | State/progress remain independent per tab. |
| Safe completion gate | Inject/test a bare `COMPLETE` without `safeCompletion=true`. | It becomes `UNCERTAIN`; no completed alert is emitted. |
| Startup with existing user-action state | Reload/restart the notifier while a monitored tab is already PAUSED, STUCK_THINKING, WAITING_INPUT, or FAILED. | The initial genuine user-action state is emitted outward immediately; it is not suppressed as baseline history. |
| Progress contamination | Use a response containing `75% complete` followed later by an unrelated `100%` metric such as test pass rate. | Current work progress remains 75%; unrelated percentages cannot create completion. |
| Negated completion | Use text such as `This is not 100% complete` or `Do not treat this as complete`. | Completion remains blocked even if 100% appears in the sentence. |
| Explicit timeout | Reproduce/fixture `Message delivery timed out. Please try again.` | State is `TIMEOUT`; completed notification is impossible; safe automatic recovery is queued without a manual-verification popup. |
| 25–26 minute partial pause | Reproduce/fixture a stopped response with `Worked for 25m 47s` and `75% complete`. | State is `PAUSED`; progress shows 75%; no completed alert; persistent alert appears. |
| Stuck Thinking | Reproduce/fixture a current assistant turn visibly stuck on `Thinking` with no active Stop control until the configured stable threshold. | State becomes `STUCK_THINKING`; no completed alert; persistent alert appears. |
| Resume prefill | Allow a PAUSED/STUCK_THINKING incident with an empty composer. | Exactly `Resume` is pre-filled; nothing is sent automatically. |
| Resume draft protection | Put any other text in the composer before a pause/stuck incident. | Existing draft is untouched; notifier instructs manual recovery. |
| Persistent page alert | Trigger any manual-action state and leave the tab open. | Fixed top alert remains until condition clears or user explicitly dismisses that incident. |
| Persistent desktop alert | Trigger a manual-action state while the managed window is not active. | Tray/desktop alert remains TopMost/interaction-required until user action/dismissal as supported by Windows/Chrome. |
| Open-tab popup persistence | With a manual-action tray popup visible, click `Open correct ChatGPT tab` but do not yet perform the requested action. | The TopMost popup remains; it closes only after the tab leaves the manual-action state or the user clicks Dismiss. |
| Concurrent manual alerts | Trigger manual-action states in two different managed ChatGPT tabs. | The first TopMost alert is not silently replaced; later manual alerts queue and are surfaced after the current incident resolves/dismisses. |
| Recoverable background fault | Trigger `PAGE_STALE`, `RECOVERY_FAILED`, or `CONNECTION_LOST`. | No user-action popup appears; diagnostics record the fault and the automatic recovery controller remains active. |
| Timeout safe refresh recheck | Trigger explicit timeout and allow the ~12-second recovery delay. | Live tab is probed again before reload. |
| Active-control refresh block | During timeout fixture expose Stop or Continue before recovery alarm fires. | No reload occurs; manual recovery alert is raised. |
| Draft refresh block | During timeout fixture type text into composer before recovery alarm fires. | No reload occurs and draft remains intact. |
| Conversation-scope refresh block | Queue timeout recovery, then navigate that tab to another ChatGPT conversation before alarm fires. | Queued recovery does not reload the new conversation. |
| Timeout rate limit | Exercise repeated timeout recovery safely. | No more than one actual reload per 15 minutes and four in six hours. Cancelled probes do not spend quota. |
| Generic stale heartbeat | Prevent heartbeat long enough to exceed 90 seconds. | Reliability shows recovery and Advanced Logger records the fault; connection/managed-Chrome recovery proceeds quietly without a manual popup. |
| Bridge restart | Stop `browser-bridge.ps1`. | Tray repairs bridge and returns through DEGRADED/REPAIRING to RECOVERED. |
| Managed-window loss | Close only notifier-created Chrome window. | Managed session clears/recovery acts only on managed window; ordinary Chrome remains. |
| Running-work protection | Simulate native managed-window loss while a tab is genuinely `RUNNING`. | Automatic managed-window recreation is suppressed while valid work is running. |
| Power behavior | Keep computer-awake ON, display-awake OFF. | System-awake request is active; lid-close policy remains unchanged. |
| Uninstall boundary | Run uninstall with ordinary Chrome open. | Only notifier runtime/captured notifier window are stopped; ordinary Chrome remains. |

## Resource matrix

With exactly 1, 5, 10, and 20 ChatGPT tabs inside the captured managed window, run:

```bat
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tests\RESOURCE_TEST.ps1 -ExpectedTabCount 1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tests\RESOURCE_TEST.ps1 -ExpectedTabCount 5
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tests\RESOURCE_TEST.ps1 -ExpectedTabCount 10
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tests\RESOURCE_TEST.ps1 -ExpectedTabCount 20
```

Record exact live output in `FINAL_WINDOWS_EXECUTION_REPORT.md`.


## Additional false-signal checks

| Case | Setup | Required result |
|---|---|---|
| Historical completed response on extension reload | Leave a previously completed chat open, reload the unpacked extension or reopen the monitored page without starting a new run | No fresh completion/manual-action notification is manufactured from the old response. |
| Historical completed response versus restored interrupted progress | Finish a response containing requirement prose or an earlier partial percentage and verify finalized response controls are present; separately restore a current turn with stable sub-100% progress, active tool/status rows, and no finalized controls. | The finalized response remains COMPLETE/IDLE with no Resume prompt; the restored unfinished turn becomes PAUSED, pre-fills Resume, and never auto-submits it. |
| Current-turn percentage transport | During an observed run, show `30% complete`, `Progress: 30%`, or a line-leading `30% — ...` heading. | Page overlay, extension state, bridge, and Windows dashboard report 30 for the same tab without a notification transition caused solely by the percentage. |
| Historical known fault on extension reload | Reload while the page visibly contains an explicit timeout or partial paused response | Timeout is recorded and recovered quietly; a genuine partial pause is still surfaced and startup suppression does not hide it. |
| Generic percentage noise | A response contains `Coverage 100%`, `accuracy 75%`, or similar figures but no task-progress marker | Those figures do not drive the task progress bar or create `PAUSED`/`COMPLETE`. |
| Resume feature mentioned in a completed report | Complete a job whose final report says the Resume-prefill feature was implemented | The word `Resume` in feature documentation does not create a false `PAUSED` state. |
| Progress-only update across tabs | Keep two monitored ChatGPT tabs active and change explicit progress in one without changing its status | Popup reflects the most recently updated tab and latest explicit task percentage. |

## Positive RUNNING indicators retained from v2.3.0

1. Start a long task until ChatGPT shows **“Our systems are thinking a bit more about this request before responding.”** Verify the notifier remains `RUNNING` even if the normal two-minute stuck-Thinking threshold is exceeded.
2. While an active tool step such as **“Inspecting Tests and Static Audits”** is visible with the blue Stop control, verify the notifier remains `RUNNING` and does not prefill `Resume`.
3. Verify the progress overlay says the task is active and no PAUSED/STUCK/UNCERTAIN/COMPLETE alert is raised from those indicators.
4. Inject or reproduce **“Message delivery timed out. Please try again.”** while stale activity markup remains. Verify `TIMEOUT` wins and completion remains blocked.

## v2.4.0 percentage surfaces

| Case | Procedure | Required result |
|---|---|---|
| Known progress everywhere | Run a managed task with explicit `75% complete`. | Page overlay, Chrome popup, Windows CURRENT CHATGPT TASK panel, first tray item, and tooltip coherently show 75% without a progress-only notification. |
| Unknown running progress | Start a run before any explicit task percentage exists. | Page/popup say `Working — % unavailable`; Windows says `Working — percentage not reported`; no invented zero or 100 appears. |
| Native safe completion | Exercise a safe `COMPLETE` with proof, then a bare COMPLETE without proof. | Proof-backed task shows COMPLETE/100; bare completion renders internal UNCERTAIN without a manual popup and never terminal 100. |
| Deterministic current task | Create manual-action, RUNNING, and IDLE tabs with different update times. | Manual-action wins; otherwise RUNNING wins; within a rank the newest update and then highest tab ID wins. |
| Tray tooltip bound | Use a title longer than 180 characters. | Dashboard title is sanitized; NotifyIcon tooltip remains valid and no longer than 63 characters. |
| Flexible all-tab progress | Open, update, and close several managed ChatGPT tabs, including enough to exceed the visible list height. | Every eligible tab has its own title/state/percentage/bar/freshness row; the list scrolls; rows update independently and disappear when their tabs close or detach. |
| Dashboard compact tab separation | Open the dashboard, select `Controls`, then `Reliability`, and return to `Tasks`. | The 860x700 dashboard fits the working area; `Tasks` is the default progress view, settings/actions appear only on `Controls`, and the health grid appears only on `Reliability` while continuing to update. |
| Hide dashboard to tray | On the bottom Tasks row, click `Hide UI to tray`, then use the tray icon menu's `Open Dashboard`. | Only the dashboard hides and restores; the notifier, managed Chrome, and monitoring continue. It is aligned directly after `Show Chrome` and `Hide Chrome`. |
| Task-level Chrome controls | On `Tasks`, click bottom-edge `Hide Chrome`, then `Show Chrome`. | Only the managed Chrome window hides and restores; both controls remain visible on Tasks and are absent from Controls. |
