(() => {
  const surface = document.getElementById("surface");
  const status = document.getElementById("fixtureStatus");
  const assistant = () => surface.querySelector('[data-message-author-role="assistant"]');

  function clearSignals() {
    surface.querySelectorAll('[role="alert"], button[data-testid="stop-button"]').forEach(el => el.remove());
  }
  function setRunning() {
    clearSignals();
    const stop = document.createElement("button");
    stop.dataset.testid = "stop-button";
    stop.setAttribute("aria-label", "Stop generating");
    stop.textContent = "Stop generating";
    surface.append(stop);
    assistant().textContent = "Working on deterministic verification: 42%";
    status.textContent = "RUNNING";
  }
  function setComplete() {
    clearSignals();
    assistant().textContent = "Deterministic verification completed successfully.";
    status.textContent = "COMPLETE";
  }
  function setWaiting() {
    clearSignals();
    assistant().textContent = "Please upload the required fixture file.";
    status.textContent = "WAITING_INPUT";
  }
  function setAlert(text, value) {
    clearSignals();
    const alert = document.createElement("div");
    alert.setAttribute("role", "alert");
    alert.textContent = text;
    surface.append(alert);
    status.textContent = value;
  }
  function clear() {
    clearSignals();
    assistant().textContent = "Fixture ready.";
    status.textContent = "IDLE";
  }

  document.getElementById("running").onclick = setRunning;
  document.getElementById("complete").onclick = setComplete;
  document.getElementById("waiting").onclick = setWaiting;
  document.getElementById("failed").onclick = () => setAlert("Something went wrong", "FAILED");
  document.getElementById("timeout").onclick = () => setAlert("Response timed out. Refresh the page to update the conversation.", "PAGE_STALE");
  document.getElementById("clear").onclick = clear;
  document.getElementById("advance").onclick = () => {
    window.__cwnAdvanceMs += 5 * 60 * 1000;
    status.textContent = "RUNNING — CLOCK ADVANCED FIVE MINUTES";
    assistant().textContent = "Still working normally after five simulated minutes: 73%";
  };

  const testCase = new URL(location.href).searchParams.get("case");
  if (testCase === "complete") {
    setTimeout(setRunning, 1200);
    setTimeout(setComplete, 3000);
  } else if (testCase === "waiting") {
    setTimeout(setRunning, 1200);
    setTimeout(setWaiting, 3000);
  } else if (testCase === "failed") {
    setTimeout(() => setAlert("Something went wrong", "FAILED"), 1200);
  } else if (testCase === "timeout") {
    setTimeout(setRunning, 1200);
    setTimeout(() => setAlert("Response timed out. Refresh the page to update the conversation.", "PAGE_STALE"), 3000);
  } else if (testCase === "long") {
    setTimeout(setRunning, 1200);
    setTimeout(() => document.getElementById("advance").click(), 2500);
  }
})();
