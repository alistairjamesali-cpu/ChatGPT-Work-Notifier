$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$trayPath = Join-Path (Split-Path -Parent $PSScriptRoot) 'runtime\tray-host.ps1'
$tokens = $null
$errors = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile($trayPath, [ref]$tokens, [ref]$errors)
if ($errors.Count) { throw ($errors | ForEach-Object Message | Out-String) }
foreach ($name in @('Hide-DashboardUi','New-DashboardTabShell','Move-ChromeButtonsToTasks','Get-TaskNumericProgress','New-TabProgressRow','Update-AllTabProgressPresentation')) {
  $definition = $ast.Find({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $name }, $true)
  if (-not $definition) { throw "$name was not found." }
  Invoke-Expression $definition.Extent.Text
}
function Get-NowMs { return [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() }
function Assert-True([string]$Name, [bool]$Condition) {
  if (-not $Condition) { throw $Name }
  Write-Host "PASS: $Name"
}

$allTabsHost = New-Object System.Windows.Forms.Panel
$allTabsHost.Size = New-Object System.Drawing.Size(990,145)
$allTabsHost.AutoScroll = $true
$allTabsEmpty = New-Object System.Windows.Forms.Label
$allTabsHost.Controls.Add($allTabsEmpty)
$script:TabProgressRows = @{}
$layoutForm = New-Object System.Windows.Forms.Form

try {
  $layout = New-DashboardTabShell $layoutForm
  Assert-True 'dashboard separates tasks, controls, and reliability into three tabs' ($layout.Tabs.TabPages.Count -eq 3)
  Assert-True 'tasks tab is the default uncluttered view' ($layout.Tabs.SelectedIndex -eq 0 -and $layout.Tabs.TabPages[0].Text -eq 'Tasks')
  Assert-True 'controls tab is separately accessible' ($layout.Tabs.TabPages[1].Text -eq 'Controls')
  Assert-True 'reliability tab is separately accessible' ($layout.Tabs.TabPages[2].Text -eq 'Reliability')
  $layoutForm.Show()
  [System.Windows.Forms.Application]::DoEvents()
  Hide-DashboardUi $layoutForm
  Assert-True 'explicit dashboard action hides the UI to tray' (-not $layoutForm.Visible)
  $showChrome = New-Object System.Windows.Forms.Button
  $hideChrome = New-Object System.Windows.Forms.Button
  $hideUi = New-Object System.Windows.Forms.Button
  $layout.Controls.Controls.Add($showChrome)
  $layout.Controls.Controls.Add($hideChrome)
  $layout.Controls.Controls.Add($hideUi)
  Move-ChromeButtonsToTasks $layout.Tasks $showChrome $hideChrome $hideUi
  Assert-True 'Chrome and UI visibility controls share the Tasks bottom row' ($showChrome.Parent -eq $layout.Tasks -and $hideChrome.Parent -eq $layout.Tasks -and $hideUi.Parent -eq $layout.Tasks -and $showChrome.Top -eq 462 -and $hideChrome.Top -eq 462 -and $hideUi.Top -eq 462 -and $hideUi.Left -eq 297 -and $hideUi.Size -eq (New-Object System.Drawing.Size(128,42)))

  $now = Get-NowMs
  $state = [pscustomobject]@{ browser = [pscustomobject]@{ tabs = @(
    [pscustomobject]@{ tabId=1; title='First task'; status='RUNNING'; progress=25; safeCompletion=$false; updatedAt=$now; monitoringState='CONNECTED'; lastLifecycle='' },
    [pscustomobject]@{ tabId=2; title='Unknown task'; status='RUNNING'; progress=$null; safeCompletion=$false; updatedAt=$now; monitoringState='CONNECTED'; lastLifecycle='' },
    [pscustomobject]@{ tabId=3; title='Finished task'; status='COMPLETE'; progress=100; safeCompletion=$true; updatedAt=$now; monitoringState='CONNECTED'; lastLifecycle='' },
    [pscustomobject]@{ tabId=4; title='Detached task'; status='RUNNING'; progress=80; safeCompletion=$false; updatedAt=$now; monitoringState='DETACHED'; lastLifecycle='NAVIGATED_AWAY' }
  ) } }
  Update-AllTabProgressPresentation $state
  Assert-True 'every eligible tab gets one progress row' ($script:TabProgressRows.Count -eq 3)
  Assert-True 'detached tab is excluded from progress rows' (-not $script:TabProgressRows.ContainsKey('4'))
  Assert-True 'known tab percentage renders exactly' ($script:TabProgressRows['1'].Progress.Text -eq '25%')
  Assert-True 'known tab visual fill is proportional' ($script:TabProgressRows['1'].Fill.Width -eq [int][math]::Round($script:TabProgressRows['1'].Track.Width * 0.25))
  Assert-True 'unknown running tab is explicit' ($script:TabProgressRows['2'].Progress.Text -eq '% unavailable')
  Assert-True 'safe completed tab renders 100 percent' ($script:TabProgressRows['3'].Progress.Text -eq '100%')
  Assert-True 'tab title is preserved' ($script:TabProgressRows['1'].Title.Text -eq 'First task')

  $state.browser.tabs = @([pscustomobject]@{ tabId=3; title='Unsafe claim'; status='COMPLETE'; progress=100; safeCompletion=$false; updatedAt=$now; monitoringState='CONNECTED'; lastLifecycle='' })
  Update-AllTabProgressPresentation $state
  Assert-True 'closed or removed tabs disappear flexibly' ($script:TabProgressRows.Count -eq 1)
  Assert-True 'unsafe complete renders uncertain' ($script:TabProgressRows['3'].State.Text -eq 'UNCERTAIN')
  Assert-True 'unsafe complete suppresses 100 percent with encoding-safe text' ($script:TabProgressRows['3'].Progress.Text -eq 'N/A' -and $script:TabProgressRows['3'].Fill.Width -eq 0)

  $state.browser.tabs = @(1..10 | ForEach-Object { [pscustomobject]@{ tabId=$_; title="Task $_"; status='RUNNING'; progress=$_*5; safeCompletion=$false; updatedAt=$now; monitoringState='CONNECTED'; lastLifecycle='' } })
  Update-AllTabProgressPresentation $state
  Assert-True 'ten tabs create ten independent rows' ($script:TabProgressRows.Count -eq 10)
  Assert-True 'tab list grows into a scrollable surface' ($allTabsHost.AutoScroll -and $allTabsHost.AutoScrollMinSize.Height -eq 480)
  Assert-True 'rows remain ordered by numeric tab id' ($script:TabProgressRows['1'].Panel.Top -lt $script:TabProgressRows['10'].Panel.Top)

  $state.browser.tabs = @([pscustomobject]@{ tabId=1; title='Estimated'; status='RUNNING'; progress=100; progressEstimated=$true; safeCompletion=$false; updatedAt=$now; monitoringState='CONNECTED'; lastLifecycle='' })
  Update-AllTabProgressPresentation $state
  Assert-True 'time estimate is labelled and stays running at 100 percent' ($script:TabProgressRows['1'].Progress.Text -eq '100% est.' -and $script:TabProgressRows['1'].State.Text -eq 'RUNNING')

  $state.browser.tabs = @()
  Update-AllTabProgressPresentation $state
  Assert-True 'empty state clears rows and shows guidance' ($script:TabProgressRows.Count -eq 0 -and $allTabsEmpty.Visible)
  Write-Host 'PASS TRAY_PROGRESS_PRESENTATION_TEST.ps1'
} finally {
  $allTabsHost.Dispose()
  $layoutForm.Dispose()
}
