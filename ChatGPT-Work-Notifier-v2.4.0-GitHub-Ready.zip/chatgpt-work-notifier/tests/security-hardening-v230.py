from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]

def text(rel): return (ROOT/rel).read_text(encoding='utf-8')
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))

boot=text('managed-bootstrap.js'); sw=text('service-worker.js'); bridge=text('runtime/browser-bridge.ps1')
tray=text('runtime/tray-host.ps1'); install=text('runtime/install.ps1'); uninstall=text('runtime/uninstall.ps1')
diag=text('runtime/diagnostics.ps1'); verify=text('tests/VERIFY_RUNTIME.ps1')

ck('bootstrap validates 32-hex token', "^[a-f0-9]{32}$" in boot)
ck('bootstrap removes token from URL', 'searchParams.delete("cwn_managed")' in boot and 'history.replaceState' in boot)
ck('service worker emits auth header', 'X-CWN-Token' in sw)
ck('managed registration validates with bridge before storage mutation', '/validate-session' in sw and sw.find('/validate-session') < sw.find('managedSessionToken: token'))
ck('bridge token is read from file, not process command line', 'SessionTokenFile' in bridge and 'param([int]$Port = 38765, [string]$SessionToken =' not in bridge)
ck('bridge uses constant-work token compare loop', 'Test-FixedTimeToken' in bridge and '-bxor' in bridge and '-bor' in bridge)
for ep in ['/command','/browser-event','/browser-heartbeat','/browser-lifecycle','/browser-tab-closed','/browser-tabs-sync','/show-managed-window','/command-ack','/validate-session']:
    pos=bridge.find(ep)
    window=bridge[pos:pos+900] if pos>=0 else ''
    ck(f'protected endpoint {ep}', pos>=0 and ('Assert-BrowserAuthenticated' in window or ep=='/validate-session' and 'Test-FixedTimeToken' in window))
ck('public bridge state omits URL metadata', 'url = $t.url' not in bridge)
ck('public bridge state omits conversation identifier', 'conversationId = $t.conversationId' not in bridge and 'conversationId = $Event.conversationId' not in bridge)
ck('public lastEvent omits title/url/conversation metadata', 'function Get-PublicEvent' in bridge and 'title = $Event.title' not in bridge and 'url = $Event.url' not in bridge and 'conversationId = $Event.conversationId' not in bridge)
ck('local control plane requires token authentication', 'function Assert-LocalAuthenticated' in bridge and all(bridge.find(ep)>=0 and 'Assert-LocalAuthenticated' in bridge[bridge.find(ep):bridge.find(ep)+500] for ep in ['/dashboard-state','/request-tab-focus','/request-repair','/diagnostic-ping']))
ck('progress uses one strict bridge validator', bridge.count('function Get-ValidatedProgress') == 1 and bridge.count('Get-ValidatedProgress $incoming.progress') == 2 and 'IsNaN' in bridge and 'IsInfinity' in bridge)
ck('dashboard state alone exposes sanitized title', 'function Get-DashboardState' in bridge and 'Add-Member -NotePropertyName title' in bridge and '/dashboard-state' in bridge)
ck('tray signs local control POSTs with managed token', "$headers['X-CWN-Token'] = $script:ManagedToken" in tray)
ck('request body has 16KiB cap', '$contentLength -gt 16384' in bridge)
ck('malformed tab-close returns HTTP 400', "400 'Bad Request'" in bridge and '/browser-tab-closed' in bridge)
ck('tray validates restored HWND is Chrome-owned', 'IsChromeTopLevelWindow' in tray and 'Rejected stale managed-window handle' in tray)
ck('uninstall validates HWND is Chrome-owned', 'CwnUninstallWindow]::IsChromeTopLevelWindow' in uninstall)
ck('Chrome discovery has no PATH fallback', 'Get-Command chrome.exe' not in tray and 'Get-Command chrome.exe' not in diag and 'Get-Command chrome.exe' not in verify)
ck('settings only accept real booleans', '$loaded.$name -is [bool]' in tray and '$loaded.$name -is [bool]' in bridge)
ck('critical JSON writes are atomic', 'function Write-JsonAtomic' in tray and 'Write-JsonAtomic $stateFile' in tray and 'Write-JsonAtomic $runtimeStateFile' in tray and 'Write-JsonAtomic $settingsFile' in tray)
ck('bridge secret not placed on process command line', '-SessionTokenFile' in tray and '-SessionToken $($script:ManagedToken)' not in tray)
ck('bridge launch does not log secret', 'with authenticated session channel' in tray and 'token=' not in '\n'.join(l for l in tray.splitlines() if 'Log ' in l))
ck('managed window capture fails closed on concurrent candidates', 'multiple new Chrome windows appeared concurrently' in tray)
ck('installer process termination scoped to release root', 'Contains($rootNeedle)' in install)
ck('cross-root upgrade requires verified notifier identity', 'Get-VerifiedNotifierRootFromCommandLine' in install and "manifest.name -ne 'ChatGPT Work Notifier'" in install and "manifest.manifest_version -ne 3" in install)
ck('cross-root stop is conditioned on verified root', 'if ($candidateRoot -and -not $candidateRoot.Equals' in install and 'Stop-Process -Id $_.ProcessId' in install)
ck('uninstaller process termination scoped to release root', 'Contains($rootNeedle)' in uninstall)
ck('installer initializes root before rootNeedle', install.find('$root =') < install.find('$rootNeedle ='))
ck('Windows launchers use explicit system binaries', all('powershell.exe' not in text(f).lower().replace('%systemroot%\\system32\\windowspowershell\\v1.0\\powershell.exe','') for f in ['Maintenance/INSTALL_OR_UPGRADE.bat','Maintenance/UNINSTALL.bat','Maintenance/RUN_CODEX_FINAL_WINDOWS_VALIDATION.bat','Maintenance/MAKE_CODEX_DIAGNOSTIC_BUNDLE.bat','START_CHATGPT_WORK_NOTIFIER.bat']))
ck('runtime tray diagnostics use explicit PowerShell path', '& powershell.exe' not in tray)
ck('runtime diagnostic auth test includes token header', 'X-CWN-Token' in diag)
ck('runtime verifier auth test includes token header', 'X-CWN-Token' in verify)
ck('service worker security test rejects untrusted registration', 'untrusted but well-formed managed token' in text('tests/service-worker-multitab.test.js').lower())

failed=[n for n,ok in checks if not ok]
for n,ok in checks: print(('PASS' if ok else 'FAIL')+': '+n)
print(f'\nSECURITY HARDENING RESULT: {len(checks)-len(failed)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)
