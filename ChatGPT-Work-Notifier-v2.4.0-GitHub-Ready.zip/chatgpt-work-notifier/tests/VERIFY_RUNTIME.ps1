$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$runtimeBase = Join-Path $env:LOCALAPPDATA 'ChatGPT Work Notifier'
$runtimeStateFile = Join-Path $runtimeBase 'runtime-state.json'
$managedStateFile = Join-Path $runtimeBase 'managed-window.json'
$launchConfig = Get-Content -LiteralPath (Join-Path $root 'runtime\chrome-launch.json') -Raw | ConvertFrom-Json
$checks = New-Object System.Collections.ArrayList

function Add-Check([string]$Name,[string]$Status,[string]$Detail,[bool]$Required=$true) {
  [void]$checks.Add([ordered]@{ name=$Name; status=$Status; required=$Required; detail=$Detail })
}

function Read-JsonSnapshot([string]$Path) {
  for($attempt=0;$attempt -lt 10;$attempt++){
    try {
      if(Test-Path -LiteralPath $Path){ return (Get-Content -LiteralPath $Path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop) }
    } catch {}
    Start-Sleep -Milliseconds 100
  }
  return $null
}
function Find-Chrome {
  $candidates = @(
    (Join-Path ${env:ProgramFiles} 'Google\Chrome\Application\chrome.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
    (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
  )
  foreach($c in $candidates){ if($c -and (Test-Path $c)){ return $c } }
  return $null
}

# G01/G02 support: real Windows PowerShell 5.1 parser gate.
$parseErrors = @()
Get-ChildItem -Path $root -Filter '*.ps1' -Recurse | ForEach-Object {
  $tokens=$null; $errors=$null
  [void][System.Management.Automation.Language.Parser]::ParseFile($_.FullName,[ref]$tokens,[ref]$errors)
  foreach($e in @($errors)){ $parseErrors += ("{0}: {1}" -f $_.FullName,$e.Message) }
}
Add-Check 'Windows PowerShell 5.1 parsing' $(if($parseErrors.Count -eq 0){'PASS'}else{'FAIL'}) $(if($parseErrors.Count -eq 0){'Zero parser errors.'}else{$parseErrors -join ' | '})

$chrome = Find-Chrome
Add-Check 'Chrome detected' $(if($chrome){'PASS'}else{'FAIL'}) $(if($chrome){$chrome}else{'Google Chrome executable not found.'})

$trayProc = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'powershell.exe' -and $_.CommandLine -like '*tray-host.ps1*' })
$bridgeProc = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'powershell.exe' -and $_.CommandLine -like '*browser-bridge.ps1*' })
Add-Check 'Single tray host' $(if($trayProc.Count -eq 1){'PASS'}else{'FAIL'}) "Detected $($trayProc.Count) tray-host process(es)."
Add-Check 'Single browser bridge' $(if($bridgeProc.Count -eq 1){'PASS'}else{'FAIL'}) "Detected $($bridgeProc.Count) browser-bridge process(es)."
Add-Check 'Managed state file' $(if(Test-Path $managedStateFile){'PASS'}else{'FAIL'}) $managedStateFile
Add-Check 'Runtime state file' $(if(Test-Path $runtimeStateFile){'PASS'}else{'FAIL'}) $runtimeStateFile

$runtimeState=Read-JsonSnapshot $runtimeStateFile
$managedProc=$null
try {
  if($runtimeState.chromeProcessId){ $managedProc=Get-CimInstance Win32_Process -Filter "ProcessId=$([int]$runtimeState.chromeProcessId)" }
} catch {}
Add-Check 'Managed Chrome window process' $(if($managedProc -and $managedProc.Name -eq 'chrome.exe'){'PASS'}else{'FAIL'}) $(if($managedProc){"PID $($managedProc.ProcessId); captured managed window is owned by Chrome."}else{'No managed Chrome window process found.'})

if($managedProc){
  $bad=@(); foreach($sw in @($launchConfig.prohibitedSwitches)){ if([string]$managedProc.CommandLine -like "*$sw*"){ $bad += [string]$sw } }
  $sameProfile=([bool]$runtimeState.usesOriginalChromeProfile -and [string]$managedProc.CommandLine -notlike '*ChatGPT Work Notifier*ManagedChrome*')
  Add-Check 'Original Chrome profile' $(if($sameProfile){'PASS'}else{'FAIL'}) $(if($sameProfile){"Using existing Chrome profile $($runtimeState.chromeProfile)."}else{'Managed window is not using the original Chrome profile.'})
  Add-Check 'Dangerous switches absent' $(if($bad.Count -eq 0){'PASS'}else{'FAIL'}) $(if($bad.Count -eq 0){'No prohibited security-bypass switches detected.'}else{"Present: $($bad -join ', ')"})
  Add-Check 'No obsolete command-line extension loader' $(if([string]$managedProc.CommandLine -notlike '*--load-extension=*'){'PASS'}else{'FAIL'}) 'Chrome 137+ no longer supports --load-extension in branded Chrome.'
} else {
  Add-Check 'Original Chrome profile' 'FAIL' 'Managed Chrome is not running.'
  Add-Check 'Dangerous switches absent' 'FAIL' 'Cannot verify without Managed Chrome.'
  Add-Check 'No obsolete command-line extension loader' 'FAIL' 'Cannot verify without Managed Chrome.'
}

$bridge=$null
try { $bridge=Invoke-RestMethod 'http://127.0.0.1:38765/state' -TimeoutSec 2 } catch {}
Add-Check 'Browser bridge online' $(if($bridge -and [string]$bridge.version -eq '2.4.0' -and [string]$bridge.mode -eq 'CHROME_ONLY'){'PASS'}else{'FAIL'}) $(if($bridge){"Version $($bridge.version), mode $($bridge.mode)."}else{'No response from 127.0.0.1:38765.'})

$loopbackOnly=$false
try {
  $listeners=@([System.Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners() | Where-Object { $_.Port -eq 38765 })
  $badListeners=@($listeners | Where-Object { -not [System.Net.IPAddress]::IsLoopback($_.Address) })
  $loopbackOnly=($listeners.Count -gt 0 -and $badListeners.Count -eq 0)
} catch {}
Add-Check 'Bridge localhost-only' $(if($loopbackOnly){'PASS'}else{'FAIL'}) 'Port 38765 must have no non-loopback listener.'

if($bridge){
  $tabCount=[int]$bridge.browser.tabCount
  Add-Check 'Managed ChatGPT tab detection' $(if($tabCount -gt 0){'PASS'}else{'FAIL'}) "$tabCount tracked ChatGPT tab(s)."

  $hbAge=$null; $hbFresh=$false
  if($bridge.browser.lastExtensionHeartbeatAt){
    $hbAge=[math]::Round(([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()-[long]$bridge.browser.lastExtensionHeartbeatAt)/1000.0,1)
    $hbFresh=($hbAge -le 60)
  }
  Add-Check 'Extension heartbeat' $(if($hbFresh){'PASS'}else{'FAIL'}) $(if($hbAge -ne $null){"Last heartbeat ${hbAge}s ago."}else{'No extension heartbeat recorded. Complete one-time Managed Chrome extension setup.'})

  $allProtected=($tabCount -gt 0)
  foreach($tab in @($bridge.browser.tabs)){ if(-not [bool]$tab.autoDiscardableProtected){ $allProtected=$false } }
  Add-Check 'Memory Saver per-tab protection' $(if($allProtected){'PASS'}else{'FAIL'}) 'Every tracked ChatGPT tab must report autoDiscardable=false.'

  # Event round trip is metadata-only and verifies dashboard/popup delivery path.
  $eventOk=$false
  try {
    $payload=@{tabId=-1;windowId=$bridge.browser.managedWindowId;status='TEST';title='Runtime verification';url='';conversationId=$null;progress=$null;runSeconds=$null;showPopup=$true;transient=$true;at=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()} | ConvertTo-Json -Compress
    $managedState=Get-Content -LiteralPath $managedStateFile -Raw | ConvertFrom-Json
    $token=[string]$managedState.token
    if($token -notmatch '^[a-f0-9]{32}$'){ throw 'Managed session token unavailable.' }
    $headers=@{ Origin='chrome-extension://aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'; 'X-CWN-Token'=$token }
    $r=Invoke-RestMethod 'http://127.0.0.1:38765/browser-event' -Method Post -Headers $headers -ContentType 'application/json' -Body $payload -TimeoutSec 2
    Start-Sleep -Milliseconds 300
    $s2=Invoke-RestMethod 'http://127.0.0.1:38765/state' -TimeoutSec 2
    $eventOk=([bool]$r.ok -and [string]$s2.browser.lastEvent.status -eq 'TEST')
  } catch {}
  Add-Check 'Background event round trip' $(if($eventOk){'PASS'}else{'FAIL'}) 'Local status metadata reached the bridge.'

  # Command-channel acknowledgement proves extension -> bridge command polling and routing channel.
  $commandOk=$false
  try {
    $request=Invoke-RestMethod 'http://127.0.0.1:38765/diagnostic-ping' -Method Post -Headers $headers -ContentType 'application/json' -Body '{}' -TimeoutSec 2
    # Background Chrome can throttle the content-script poller to one minute;
    # allow one bounded cycle while remaining below the 75-second expiry.
    for($i=0;$i -lt 140;$i++){
      Start-Sleep -Milliseconds 500
      $s3=Invoke-RestMethod 'http://127.0.0.1:38765/state' -TimeoutSec 2
      if($s3.browser.commandAckAt -and [bool]$s3.browser.commandAckOk -and -not $s3.browser.pendingCommand){ $commandOk=$true; break }
    }
  } catch {}
  Add-Check 'Extension command/routing channel' $(if($commandOk){'PASS'}else{'FAIL'}) 'DIAGNOSTIC_PING must be acknowledged through the elected extension leader.'
} else {
  foreach($n in @('Managed ChatGPT tab detection','Extension heartbeat','Memory Saver per-tab protection','Background event round trip','Extension command/routing channel')){ Add-Check $n 'FAIL' 'Bridge unavailable.' }
}

if($runtimeState){
  Add-Check 'Original profile preserved' $(if([bool]$runtimeState.usesOriginalChromeProfile){'PASS'}else{'FAIL'}) $(if([bool]$runtimeState.usesOriginalChromeProfile){'No copied or isolated Chrome user-data directory is used.'}else{'Runtime does not report the original Chrome profile.'})
  $awakeOk=([bool]$runtimeState.monitoringEnabled -and [bool]$runtimeState.settings.keepComputerAwake -and [bool]$runtimeState.awakeProtection)
  Add-Check 'Windows awake protection' $(if($awakeOk){'PASS'}else{'FAIL'}) $(if($awakeOk){'SetThreadExecutionState system-required protection is active.'}else{'Expected default awake protection is not active.'})
  Add-Check 'Display awake default' $(if(-not [bool]$runtimeState.settings.keepDisplayAwake){'PASS'}else{'WARN'}) 'Default is OFF; display may turn off while the system remains awake.' $false
  Add-Check 'Automatic recovery configured' $(if([bool]$runtimeState.settings.autoRecoverChrome -and [bool]$runtimeState.settings.autoRepairConnection -and [bool]$runtimeState.settings.allowControlledStaleRecovery){'PASS'}else{'FAIL'}) "Recovery state: $($runtimeState.recoveryStatus)"
  Add-Check 'Managed window state available' $(if([bool]$runtimeState.chromeAlive){'PASS'}else{'FAIL'}) $(if([bool]$runtimeState.managedHidden){'Managed Chrome is hidden to tray and alive.'}else{'Managed Chrome is visible and alive.'})
} else {
  Add-Check 'Original profile preserved' 'FAIL' 'runtime-state.json missing.'
  Add-Check 'Windows awake protection' 'FAIL' 'runtime-state.json missing.'
  Add-Check 'Display awake default' 'WARN' 'runtime-state.json missing.' $false
  Add-Check 'Automatic recovery configured' 'FAIL' 'runtime-state.json missing.'
  Add-Check 'Managed window state available' 'FAIL' 'runtime-state.json missing.'
}

# Legacy process name is checked only as migration-negative evidence; it is not part of live monitoring.
$legacy=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'powershell.exe' -and $_.CommandLine -like '*chatgpt-app-watcher.ps1*' })
Add-Check 'Removed legacy watcher absent' $(if($legacy.Count -eq 0){'PASS'}else{'FAIL'}) 'No obsolete native-app watcher process may be running.'

$requiredFails=@($checks | Where-Object { $_.required -and $_.status -eq 'FAIL' })
$result=[ordered]@{
  version='2.4.0'
  generatedAt=(Get-Date).ToUniversalTime().ToString('o')
  pass=($requiredFails.Count -eq 0)
  checks=$checks
}
$result | ConvertTo-Json -Depth 10
if($requiredFails.Count -gt 0){ exit 1 }
