[CmdletBinding()]
param(
  [string]$InstallDir = (Join-Path $env:LOCALAPPDATA 'Programs\ChatGPT Work Notifier'),
  [switch]$NoLaunch,
  [switch]$DesktopShortcut
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

if ($env:OS -ne 'Windows_NT') { throw 'This installer requires Windows.' }

$sourceRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$installDir = [System.IO.Path]::GetFullPath($InstallDir)
$runtimeBase = Join-Path $env:LOCALAPPDATA 'ChatGPT Work Notifier'

function Test-NotifierRoot([string]$Path) {
  return (
    (Test-Path -LiteralPath (Join-Path $Path 'manifest.json') -PathType Leaf) -and
    (Test-Path -LiteralPath (Join-Path $Path 'runtime\tray-host.ps1') -PathType Leaf) -and
    (Test-Path -LiteralPath (Join-Path $Path 'START_CHATGPT_WORK_NOTIFIER.bat') -PathType Leaf)
  )
}

if (-not (Test-NotifierRoot $sourceRoot)) { throw "Invalid notifier source root: $sourceRoot" }

Write-Host 'ChatGPT Work Notifier v2.4.0 installer'
Write-Host "Source:  $sourceRoot"
Write-Host "Install: $installDir"

# Stop an already-installed runtime before replacing its files. User settings and
# diagnostics live in a separate LocalAppData directory and are preserved.
$oldUninstaller = Join-Path $installDir 'runtime\uninstall.ps1'
if (Test-Path -LiteralPath $oldUninstaller -PathType Leaf) {
  try {
    & "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File $oldUninstaller | Write-Host
  } catch {
    Write-Warning "Existing runtime cleanup reported: $($_.Exception.Message)"
  }
}

if (-not $sourceRoot.Equals($installDir, [System.StringComparison]::OrdinalIgnoreCase)) {
  New-Item -ItemType Directory -Path $installDir -Force | Out-Null
  $excludeDirs = @('.git', 'dist')
  $args = @($sourceRoot, $installDir, '/MIR', '/R:2', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP')
  foreach ($dir in $excludeDirs) { $args += @('/XD', (Join-Path $sourceRoot $dir)) }
  & robocopy.exe @args | Out-Null
  $rc = $LASTEXITCODE
  if ($rc -gt 7) { throw "File installation failed. Robocopy exit code: $rc" }
}

$nativeInstall = Join-Path $installDir 'runtime\install.ps1'
& "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File $nativeInstall | Write-Host
if ($LASTEXITCODE -ne 0) { throw "Runtime registration failed with exit code $LASTEXITCODE." }

# Register in Apps & Features for the current user.
$uninstallKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ChatGPTWorkNotifier'
New-Item -Path $uninstallKey -Force | Out-Null
$uninstallCmd = '"{0}" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "{1}"' -f (
  "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"),
  (Join-Path $installDir 'installer\uninstall-installed.ps1')
New-ItemProperty -Path $uninstallKey -Name DisplayName -Value 'ChatGPT Work Notifier' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name DisplayVersion -Value '2.4.0' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name Publisher -Value 'ChatGPT Work Notifier' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name InstallLocation -Value $installDir -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name DisplayIcon -Value (Join-Path $installDir 'runtime\notifier.ico') -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name UninstallString -Value $uninstallCmd -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name NoModify -Value 1 -PropertyType DWord -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name NoRepair -Value 1 -PropertyType DWord -Force | Out-Null

# Start-menu shortcuts. Desktop shortcut is opt-in for the source installer.
$ws = New-Object -ComObject WScript.Shell
$programs = [Environment]::GetFolderPath('Programs')
$group = Join-Path $programs 'ChatGPT Work Notifier'
New-Item -ItemType Directory -Path $group -Force | Out-Null

$startLnk = $ws.CreateShortcut((Join-Path $group 'ChatGPT Work Notifier.lnk'))
$startLnk.TargetPath = Join-Path $installDir 'START_CHATGPT_WORK_NOTIFIER.bat'
$startLnk.WorkingDirectory = $installDir
$startLnk.IconLocation = (Join-Path $installDir 'runtime\notifier.ico') + ',0'
$startLnk.Save()

$uninstallLnk = $ws.CreateShortcut((Join-Path $group 'Uninstall ChatGPT Work Notifier.lnk'))
$uninstallLnk.TargetPath = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$uninstallLnk.Arguments = '-NoLogo -NoProfile -ExecutionPolicy Bypass -File "{0}"' -f (Join-Path $installDir 'installer\uninstall-installed.ps1')
$uninstallLnk.WorkingDirectory = $installDir
$uninstallLnk.IconLocation = (Join-Path $installDir 'runtime\notifier.ico') + ',0'
$uninstallLnk.Save()

if ($DesktopShortcut) {
  $desktop = [Environment]::GetFolderPath('Desktop')
  $desktopLnk = $ws.CreateShortcut((Join-Path $desktop 'ChatGPT Work Notifier.lnk'))
  $desktopLnk.TargetPath = Join-Path $installDir 'START_CHATGPT_WORK_NOTIFIER.bat'
  $desktopLnk.WorkingDirectory = $installDir
  $desktopLnk.IconLocation = (Join-Path $installDir 'runtime\notifier.ico') + ',0'
  $desktopLnk.Save()
}

if (-not $NoLaunch) {
  Start-Process -FilePath (Join-Path $installDir 'START_CHATGPT_WORK_NOTIFIER.bat') -WorkingDirectory $installDir
}

Write-Host ''
Write-Host 'Installation complete.'
Write-Host "Program files: $installDir"
Write-Host "Runtime data:  $runtimeBase"
Write-Host 'If Chrome does not connect automatically, open chrome://extensions and load the installed folder as an unpacked extension.'
