[CmdletBinding()]
param(
  [switch]$RemoveRuntimeData
)

$ErrorActionPreference = 'Continue'
Set-StrictMode -Version 2.0

$installDir = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$nativeUninstall = Join-Path $installDir 'runtime\uninstall.ps1'
$runtimeBase = Join-Path $env:LOCALAPPDATA 'ChatGPT Work Notifier'

if (Test-Path -LiteralPath $nativeUninstall -PathType Leaf) {
  & "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File $nativeUninstall | Write-Host
}

Remove-Item -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ChatGPTWorkNotifier' -Recurse -Force -ErrorAction SilentlyContinue

$programs = [Environment]::GetFolderPath('Programs')
Remove-Item -LiteralPath (Join-Path $programs 'ChatGPT Work Notifier') -Recurse -Force -ErrorAction SilentlyContinue
$desktop = [Environment]::GetFolderPath('Desktop')
Remove-Item -LiteralPath (Join-Path $desktop 'ChatGPT Work Notifier.lnk') -Force -ErrorAction SilentlyContinue

if ($RemoveRuntimeData) {
  Remove-Item -LiteralPath $runtimeBase -Recurse -Force -ErrorAction SilentlyContinue
}

# Delete the installed program directory only after this script has exited.
$escaped = $installDir.Replace("'", "''")
$cleanup = "Start-Sleep -Seconds 2; Remove-Item -LiteralPath '$escaped' -Recurse -Force -ErrorAction SilentlyContinue"
Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList @('-NoLogo','-NoProfile','-WindowStyle','Hidden','-Command',$cleanup) -WindowStyle Hidden

Write-Host 'ChatGPT Work Notifier has been uninstalled.'
if (-not $RemoveRuntimeData) { Write-Host "Runtime data was preserved at: $runtimeBase" }
