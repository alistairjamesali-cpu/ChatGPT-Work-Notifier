#define MyAppName "ChatGPT Work Notifier"
#define MyAppVersion "2.4.0"
#define MyAppPublisher "ChatGPT Work Notifier"
#define MyAppExeName "START_CHATGPT_WORK_NOTIFIER.bat"

[Setup]
AppId={{75C9F8C9-BE29-49A9-92F8-5C6D3D9A44F2}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\ChatGPT Work Notifier
DefaultGroupName=ChatGPT Work Notifier
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=..\dist
OutputBaseFilename=ChatGPT-Work-Notifier-Setup-{#MyAppVersion}
SetupIconFile=..\runtime\notifier.ico
UninstallDisplayIcon={app}\runtime\notifier.ico
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
ChangesEnvironment=no
CloseApplications=no
RestartApplications=no
VersionInfoVersion=2.4.0.0
VersionInfoProductName={#MyAppName}
VersionInfoProductVersion={#MyAppVersion}
VersionInfoDescription=Windows installer for ChatGPT Work Notifier

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
Source: "..\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs; Excludes: ".git\*,dist\*"

[Icons]
Name: "{group}\ChatGPT Work Notifier"; Filename: "{app}\START_CHATGPT_WORK_NOTIFIER.bat"; WorkingDir: "{app}"; IconFilename: "{app}\runtime\notifier.ico"
Name: "{group}\Uninstall ChatGPT Work Notifier"; Filename: "{uninstallexe}"
Name: "{autodesktop}\ChatGPT Work Notifier"; Filename: "{app}\START_CHATGPT_WORK_NOTIFIER.bat"; WorkingDir: "{app}"; IconFilename: "{app}\runtime\notifier.ico"; Tasks: desktopicon

[Run]
Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoLogo -NoProfile -ExecutionPolicy Bypass -File ""{app}\runtime\install.ps1"""; WorkingDir: "{app}"; Flags: runhidden waituntilterminated; StatusMsg: "Registering ChatGPT Work Notifier..."
Filename: "{app}\START_CHATGPT_WORK_NOTIFIER.bat"; WorkingDir: "{app}"; Description: "Launch ChatGPT Work Notifier"; Flags: postinstall skipifsilent nowait unchecked

[UninstallRun]
Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoLogo -NoProfile -ExecutionPolicy Bypass -File ""{app}\runtime\uninstall.ps1"""; WorkingDir: "{app}"; Flags: runhidden waituntilterminated; RunOnceId: "NotifierRuntimeCleanup"
