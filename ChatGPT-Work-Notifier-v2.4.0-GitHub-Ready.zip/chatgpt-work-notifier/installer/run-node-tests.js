const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const testsDir = path.resolve(__dirname, '..', 'tests');
const tests = fs.readdirSync(testsDir)
  .filter(name => name.endsWith('.test.js'))
  .sort();

if (!tests.length) {
  console.error('No JavaScript tests found.');
  process.exit(2);
}

for (const test of tests) {
  console.log(`\n> ${test}`);
  const result = spawnSync(process.execPath, [path.join(testsDir, test)], {
    stdio: 'inherit',
    windowsHide: false
  });
  if (result.error) {
    console.error(result.error.message);
    process.exit(1);
  }
  if (result.status !== 0) process.exit(result.status ?? 1);
}

console.log(`\nAll ${tests.length} JavaScript regression files passed.`);
