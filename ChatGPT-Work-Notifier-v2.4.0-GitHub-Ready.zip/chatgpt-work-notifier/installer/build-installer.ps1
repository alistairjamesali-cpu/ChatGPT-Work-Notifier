[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$root = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$iss = Join-Path $PSScriptRoot 'ChatGPTWorkNotifier.iss'
$candidates = @(
  (Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6\ISCC.exe'),
  (Join-Path $env:ProgramFiles 'Inno Setup 6\ISCC.exe')
) | Where-Object { $_ }
$iscc = $candidates | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
if (-not $iscc) { throw 'Inno Setup 6 was not found. Install Inno Setup 6, then rerun this script.' }

Push-Location $root
try {
  & $iscc $iss
  if ($LASTEXITCODE -ne 0) { throw "Inno Setup failed with exit code $LASTEXITCODE." }

  $exe = Join-Path $root 'dist\ChatGPT-Work-Notifier-Setup-2.4.0.exe'
  if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'Expected installer EXE was not produced.' }
  $hash = (Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant()
  $sha = Join-Path $root 'dist\ChatGPT-Work-Notifier-Setup-2.4.0.sha256'
  [System.IO.File]::WriteAllText($sha, "$hash  ChatGPT-Work-Notifier-Setup-2.4.0.exe`r`n", [System.Text.Encoding]::ASCII)
  Write-Host "Built: $exe"
  Write-Host "SHA256: $hash"
} finally {
  Pop-Location
}
