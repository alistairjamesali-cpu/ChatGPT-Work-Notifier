# Windows installer

There are two installation paths.

**Immediate source install:** run `installer\Install.cmd` on Windows 11. It installs the application for the current user under `%LOCALAPPDATA%\Programs\ChatGPT Work Notifier`, registers startup, creates Start-menu shortcuts, and launches the notifier. Administrator rights are not required.

**Release EXE:** compile `installer\ChatGPTWorkNotifier.iss` with Inno Setup 6. The repository's GitHub Actions workflow builds `dist\ChatGPT-Work-Notifier-Setup-2.4.0.exe` automatically.

The EXE installer is per-user and does not require elevation. It invokes the application's existing runtime installer after copying files, so the app keeps its existing startup and safety behavior.

To build locally after installing Inno Setup 6, run `installer\build-installer.ps1`.
