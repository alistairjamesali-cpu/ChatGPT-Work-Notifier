param(
  [string]$Root = (Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path))
)

$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path -LiteralPath $Root).Path
$outFile = Join-Path $Root 'FILE_SHA256SUMS.txt'

$rows = New-Object System.Collections.Generic.List[string]
$repoOnlyDirectories = @('.git', '.github', 'installer', 'dist', 'node_modules')
$repoOnlyRootFiles = @('.gitignore', '.gitattributes', 'package.json', 'CONTRIBUTING.md', 'PUBLISHING.md', 'INSTALL.cmd')
Get-ChildItem -LiteralPath $Root -File -Recurse | Where-Object {
  $relative = $_.FullName.Substring($Root.Length).TrimStart([char[]]@('\','/')) -replace '\\','/'
  $firstSegment = ($relative -split '/')[0]
  $_.FullName -ne $outFile -and
  $_.Extension -ne '.zip' -and
  $_.Extension -ne '.sha256' -and
  $repoOnlyDirectories -notcontains $firstSegment -and
  $repoOnlyRootFiles -notcontains $relative
} | Sort-Object FullName | ForEach-Object {
  $relative = $_.FullName.Substring($Root.Length).TrimStart([char[]]@('\','/')) -replace '\\','/'
  $hash = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
  [void]$rows.Add("$hash  $relative")
}

[System.IO.File]::WriteAllLines($outFile, $rows, [System.Text.Encoding]::ASCII)
Write-Output "Wrote $($rows.Count) file hashes to $outFile"
