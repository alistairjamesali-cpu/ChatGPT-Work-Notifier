param(
  [string]$OutputDirectory = (Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path))),
  [string]$BaseName = 'ChatGPT_Work_Notifier_v2.4.0_PERCENTAGE_UI_CODEX_READY'
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$hashScript = Join-Path $root 'runtime\regenerate-hashes.ps1'
& $hashScript -Root $root | Write-Output

if (-not (Test-Path -LiteralPath $OutputDirectory)) {
  New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
}
$OutputDirectory = (Resolve-Path -LiteralPath $OutputDirectory).Path
$zipPath = Join-Path $OutputDirectory ($BaseName + '.zip')
$shaPath = Join-Path $OutputDirectory ($BaseName + '.sha256')
if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }
if (Test-Path -LiteralPath $shaPath) { Remove-Item -LiteralPath $shaPath -Force }

# Package the release directory itself so the ZIP always has exactly one release root.
Compress-Archive -Path $root -DestinationPath $zipPath -CompressionLevel Optimal -Force
$hash = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
[System.IO.File]::WriteAllText($shaPath, "$hash  $([System.IO.Path]::GetFileName($zipPath))`r`n", [System.Text.Encoding]::ASCII)

Write-Output "ZIP: $zipPath"
Write-Output "SHA256: $hash"
Write-Output "SHA file: $shaPath"
