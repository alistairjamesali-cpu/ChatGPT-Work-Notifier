param([int]$Port = 38765, [string]$SessionTokenFile = '', [string]$RuntimeBase = '')

$ErrorActionPreference = 'SilentlyContinue'
$Version = '2.4.0'
$mutexName = if ($Port -eq 38765) { 'Local\ChatGPTWorkNotifierBrowserBridgeV21' } else { "Local\ChatGPTWorkNotifierBrowserBridgeV21_$Port" }
$mutex = New-Object System.Threading.Mutex($false, $mutexName)
$SessionToken = ''
try {
  if (-not $SessionTokenFile -or -not (Test-Path -LiteralPath $SessionTokenFile -PathType Leaf)) { exit 2 }
  $SessionToken = ([System.IO.File]::ReadAllText($SessionTokenFile)).Trim().ToLowerInvariant()
} catch { exit 2 }
if ($SessionToken -notmatch '^[a-f0-9]{32}$') { exit 2 }

function Test-FixedTimeToken([string]$Candidate) {
  if ($Candidate -notmatch '^[a-f0-9]{32}$') { return $false }
  $a = [System.Text.Encoding]::ASCII.GetBytes($SessionToken.ToLowerInvariant())
  $b = [System.Text.Encoding]::ASCII.GetBytes($Candidate.ToLowerInvariant())
  if ($a.Length -ne $b.Length) { return $false }
  [int]$diff = 0
  for ($i = 0; $i -lt $a.Length; $i++) { $diff = $diff -bor ($a[$i] -bxor $b[$i]) }
  return ($diff -eq 0)
}

if (-not $mutex.WaitOne(0, $false)) { exit 0 }

if (-not $RuntimeBase) { $RuntimeBase = Join-Path $env:LOCALAPPDATA 'ChatGPT Work Notifier' }
$runtimeBase = [System.IO.Path]::GetFullPath($RuntimeBase)
$runtimeStateDir = Join-Path $runtimeBase 'Bridge'
$popupQueueFile = Join-Path $runtimeStateDir 'popup-events.json'
$popupAckFile = Join-Path $runtimeStateDir 'popup-acks.json'
$settingsFile = Join-Path $runtimeBase 'settings.json'
New-Item -ItemType Directory -Path $runtimeStateDir -Force | Out-Null
$pidFile = Join-Path $runtimeStateDir 'bridge.pid'
[System.IO.File]::WriteAllText($pidFile, [string]$PID)

function Get-NowMs { return [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() }

function Get-DefaultConfig {
  return [ordered]@{
    monitoringEnabled = $true
    keepComputerAwake = $true
    keepDisplayAwake = $false
    autoRecoverChrome = $true
    autoRepairConnection = $true
    allowControlledStaleRecovery = $true
    backgroundReliabilityDiagnostics = $true
  }
}

function Get-RuntimeConfig {
  $defaults = Get-DefaultConfig
  if (-not (Test-Path $settingsFile)) { return $defaults }
  try {
    $loaded = Get-Content -LiteralPath $settingsFile -Raw | ConvertFrom-Json
    foreach ($name in @($defaults.Keys)) {
      if ($null -ne $loaded.$name -and $loaded.$name -is [bool]) { $defaults[$name] = [bool]$loaded.$name }
    }
  } catch {}
  return $defaults
}

$now = Get-NowMs
$script:state = [ordered]@{
  online = $true
  mode = 'CHROME_ONLY'
  version = $Version
  startedAt = $now
  lastRequestAt = $now
  browser = [ordered]@{
    managedWindowId = $null
    tabCount = 0
    lastEvent = $null
    lastEventAt = $null
    lastExtensionHeartbeatAt = $null
    lastLifecycleAt = $null
    focusRequestedAt = $null
    focusRequestedTabId = $null
    commandAckAt = $null
    commandAckOk = $null
    commandAckDetail = $null
  }
}
$script:browserTabs = @{}
$script:pendingCommand = $null
$script:popupEvents = New-Object System.Collections.ArrayList
$script:popupSequence = 0
$script:ackedEventIds = @{}

function Save-PopupDurableState {
  try {
    $payload = [ordered]@{ sequence = $script:popupSequence; events = @($script:popupEvents); acks = $script:ackedEventIds }
    $tmp = "$popupQueueFile.$PID.tmp"
    $payload | ConvertTo-Json -Compress -Depth 12 | Set-Content -LiteralPath $tmp -Encoding UTF8
    Move-Item -LiteralPath $tmp -Destination $popupQueueFile -Force
  } catch {}
}
function Load-PopupDurableState {
  try {
    if (-not (Test-Path -LiteralPath $popupQueueFile -PathType Leaf)) { return }
    $loaded = Get-Content -LiteralPath $popupQueueFile -Raw | ConvertFrom-Json
    $script:popupSequence = [long]($loaded.sequence | ForEach-Object { $_ })
    foreach ($item in @($loaded.events)) { if ($item) { [void]$script:popupEvents.Add($item) } }
    foreach ($property in @($loaded.acks.PSObject.Properties)) { $script:ackedEventIds[[string]$property.Name] = [long]$property.Value }
  } catch { $script:popupSequence = 0; $script:ackedEventIds = @{} }
}
Load-PopupDurableState

$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $Port)
try { $listener.Start() } catch {
  try { Remove-Item -LiteralPath $pidFile -Force } catch {}
  try { $mutex.ReleaseMutex(); $mutex.Dispose() } catch {}
  exit 1
}

function Send-JsonResponse($Client, [int]$Code, [string]$Status, $Object, [string]$AllowedOrigin) {
  try {
    $json = $Object | ConvertTo-Json -Compress -Depth 10
    $body = [System.Text.Encoding]::UTF8.GetBytes($json)
    $cors = ''
    if ($AllowedOrigin) { $cors = "Access-Control-Allow-Origin: $AllowedOrigin`r`nVary: Origin`r`n" }
    $headerText = "HTTP/1.1 $Code $Status`r`nContent-Type: application/json; charset=utf-8`r`n${cors}Access-Control-Allow-Headers: Content-Type, X-CWN-Token`r`nAccess-Control-Allow-Methods: GET,POST,OPTIONS`r`nCache-Control: no-store`r`nX-Content-Type-Options: nosniff`r`nContent-Length: $($body.Length)`r`nConnection: close`r`n`r`n"
    $header = [System.Text.Encoding]::ASCII.GetBytes($headerText)
    $stream = $Client.GetStream()
    $stream.Write($header, 0, $header.Length)
    if ($body.Length -gt 0) { $stream.Write($body, 0, $body.Length) }
    $stream.Flush()
  } catch {} finally { try { $Client.Close() } catch {} }
}

function Read-HttpRequest($Client) {
  $stream = $Client.GetStream()
  $headerBytes = New-Object System.Collections.Generic.List[byte]
  $window = New-Object System.Collections.Generic.Queue[byte]
  while ($headerBytes.Count -lt 32768) {
    $b = $stream.ReadByte()
    if ($b -lt 0) { break }
    $headerBytes.Add([byte]$b)
    $window.Enqueue([byte]$b)
    if ($window.Count -gt 4) { [void]$window.Dequeue() }
    if ($window.Count -eq 4) {
      $a = $window.ToArray()
      if ($a[0] -eq 13 -and $a[1] -eq 10 -and $a[2] -eq 13 -and $a[3] -eq 10) { break }
    }
  }
  $headerText = [System.Text.Encoding]::ASCII.GetString($headerBytes.ToArray())
  $lines = $headerText -split "`r`n"
  if ($lines.Count -lt 1) { throw 'Invalid request.' }
  $requestLine = $lines[0]
  $contentLength = 0
  $origin = ''
  $authToken = ''
  foreach ($line in $lines) {
    if ($line -match '^(?i)Content-Length:\s*(\d+)') { $contentLength = [int]$matches[1] }
    if ($line -match '^(?i)Origin:\s*(.+)$') { $origin = $matches[1].Trim() }
    if ($line -match '^(?i)X-CWN-Token:\s*([a-f0-9]{32})\s*$') { $authToken = $matches[1].Trim() }
  }
  if ($contentLength -gt 16384) { throw 'Request body too large.' }
  $bodyText = ''
  if ($contentLength -gt 0) {
    $body = New-Object byte[] $contentLength
    $offset = 0
    while ($offset -lt $contentLength) {
      $read = $stream.Read($body, $offset, $contentLength - $offset)
      if ($read -le 0) { break }
      $offset += $read
    }
    if ($offset -ne $contentLength) { throw 'Incomplete request body.' }
    $bodyText = [System.Text.Encoding]::UTF8.GetString($body)
  }
  return [ordered]@{ RequestLine = $requestLine; Origin = $origin; AuthToken = $authToken; Body = $bodyText }
}

function Assert-AllowedOrigin([string]$Origin) {
  if (-not $Origin) { return '' }
  if ($Origin -notmatch '^chrome-extension://[a-p]{32}$') { throw 'Forbidden origin.' }
  return $Origin
}

function Assert-BrowserAuthenticated([string]$Origin, [string]$AuthToken) {
  $allowed = Assert-AllowedOrigin $Origin
  if (-not $allowed) { throw 'Browser origin required.' }
  if (-not (Test-FixedTimeToken $AuthToken)) { throw 'Invalid session token.' }
  return $allowed
}

function Assert-LocalAuthenticated([string]$AuthToken) {
  if (-not (Test-FixedTimeToken $AuthToken)) { throw 'Invalid session token.' }
}

function Get-SafeString($Value, [int]$Maximum) {
  $s = [string]$Value
  if ($s.Length -gt $Maximum) { return $s.Substring(0, $Maximum) }
  return $s
}

function Get-SafeTitle($Value) {
  $title = Get-SafeString $Value 180
  return ([regex]::Replace($title, '[\x00-\x1F\x7F]', ' ')).Trim()
}

function Get-ValidatedProgress($Value) {
  if ($null -eq $Value) { return $null }
  $numericTypes = @(
    [System.TypeCode]::Byte, [System.TypeCode]::SByte,
    [System.TypeCode]::Int16, [System.TypeCode]::UInt16,
    [System.TypeCode]::Int32, [System.TypeCode]::UInt32,
    [System.TypeCode]::Int64, [System.TypeCode]::UInt64,
    [System.TypeCode]::Single, [System.TypeCode]::Double,
    [System.TypeCode]::Decimal
  )
  if ($numericTypes -notcontains [System.Type]::GetTypeCode($Value.GetType())) { throw 'Progress must be a JSON number or null.' }
  [double]$number = $Value
  if ([double]::IsNaN($number) -or [double]::IsInfinity($number) -or $number -lt 0 -or $number -gt 100) {
    throw 'Progress must be finite and between 0 and 100.'
  }
  return $number
}

function Get-SafeCompletion($Value) {
  return ($Value -is [bool] -and [bool]$Value)
}

function Get-NormalizedStatus([string]$Status, [bool]$SafeCompletion) {
  if ($Status -eq 'COMPLETE' -and -not $SafeCompletion) { return 'UNCERTAIN' }
  return $Status
}

function Get-TabRecord([int]$TabId) {
  $key = [string]$TabId
  if (-not $script:browserTabs.ContainsKey($key)) {
    $script:browserTabs[$key] = [ordered]@{
      tabId = $TabId
      windowId = $null
      url = ''
      conversationId = $null
      monitoringState = 'CONNECTED'
      generationState = 'IDLE'
      status = 'IDLE'
      title = ''
      progress = $null
      updatedAt = $null
      safeCompletion = $false
      lastStateChange = $null
      lastHeartbeat = $null
      lastLifecycle = $null
      lastLifecycleAt = $null
      notificationState = $null
      episodeId = $null
      episodeState = 'IDLE'
      executionState = 'IDLE'
      episodeRevision = 0
      terminalEventId = $null
      autoDiscardableProtected = $false
      discarded = $false
    }
  }
  return $script:browserTabs[$key]
}

function Get-PublicState {
  $nowMs = Get-NowMs
  $tabs = @()
  foreach ($entry in $script:browserTabs.GetEnumerator() | Sort-Object Name) {
    $t = $entry.Value
    $age = $null
    if ($t.lastHeartbeat) { $age = [math]::Round(($nowMs - [long]$t.lastHeartbeat) / 1000.0, 1) }
    $monitoring = [string]$t.monitoringState
    if ($null -ne $age -and $age -gt 60) { $monitoring = 'DEGRADED' }
    $tabs += [ordered]@{
      tabId = $t.tabId
      windowId = $t.windowId
      monitoringState = $monitoring
      generationState = $t.generationState
      status = $t.status
      progress = $t.progress
      progressEstimated = ($t.progressEstimated -eq $true -and $t.status -ne 'COMPLETE')
      updatedAt = $t.updatedAt
      safeCompletion = [bool]$t.safeCompletion
      lastStateChange = $t.lastStateChange
      lastHeartbeat = $t.lastHeartbeat
      heartbeatAgeSeconds = $age
      lastLifecycle = $t.lastLifecycle
      lastLifecycleAt = $t.lastLifecycleAt
      notificationState = $t.notificationState
      episodeId = $t.episodeId
      episodeState = $t.episodeState
      executionState = $t.executionState
      episodeRevision = $t.episodeRevision
      terminalEventId = $t.terminalEventId
      autoDiscardableProtected = [bool]$t.autoDiscardableProtected
      discarded = [bool]$t.discarded
    }
  }
  return [ordered]@{
    online = $script:state.online
    mode = $script:state.mode
    version = $script:state.version
    startedAt = $script:state.startedAt
    lastRequestAt = $script:state.lastRequestAt
    config = Get-RuntimeConfig
    browser = [ordered]@{
      managedWindowId = $script:state.browser.managedWindowId
      tabCount = $script:browserTabs.Count
      lastEvent = Get-PublicEvent $script:state.browser.lastEvent
      lastEventAt = $script:state.browser.lastEventAt
      lastExtensionHeartbeatAt = $script:state.browser.lastExtensionHeartbeatAt
      lastLifecycleAt = $script:state.browser.lastLifecycleAt
      focusRequestedAt = $script:state.browser.focusRequestedAt
      focusRequestedTabId = $script:state.browser.focusRequestedTabId
      commandAckAt = $script:state.browser.commandAckAt
      commandAckOk = $script:state.browser.commandAckOk
      commandAckDetail = $script:state.browser.commandAckDetail
      pendingCommand = $script:pendingCommand
      popupEvents = @($script:popupEvents)
      tabs = $tabs
    }
  }
}

function Get-DashboardState {
  $dashboard = Get-PublicState
  $dashboardTabs = @()
  foreach ($entry in $script:browserTabs.GetEnumerator() | Sort-Object Name) {
    $row = $dashboard.browser.tabs | Where-Object { [int]$_.tabId -eq [int]$entry.Value.tabId } | Select-Object -First 1
    if ($row) {
      $row | Add-Member -NotePropertyName title -NotePropertyValue (Get-SafeTitle $entry.Value.title)
      $dashboardTabs += $row
    }
  }
  $dashboard.browser.tabs = $dashboardTabs
  return $dashboard
}

function Get-PublicEvent($Event) {
  if (-not $Event) { return $null }
  return [ordered]@{
    tabId = $Event.tabId
    windowId = $Event.windowId
    status = $Event.status
    progress = $Event.progress
    progressEstimated = ($Event.progressEstimated -eq $true -and $Event.status -ne 'COMPLETE')
    runSeconds = $Event.runSeconds
    showPopup = [bool]$Event.showPopup
    transient = [bool]$Event.transient
    at = $Event.at
    safeCompletion = [bool]$Event.safeCompletion
    manualAction = [bool]$Event.manualAction
    discarded = [bool]$Event.discarded
    autoDiscardableProtected = [bool]$Event.autoDiscardableProtected
    eventId = $Event.eventId
    episodeId = $Event.episodeId
    episodeRevision = $Event.episodeRevision
  }
}

function New-Command([string]$Type, $TargetTabId) {
  $script:pendingCommand = [ordered]@{
    requestId = [Guid]::NewGuid().ToString('N')
    type = $Type
    targetTabId = $TargetTabId
    createdAt = Get-NowMs
  }
  return $script:pendingCommand
}

function Service-HttpRequest {
  $client = $listener.AcceptTcpClient()
  $client.ReceiveTimeout = 2000
  $client.SendTimeout = 2000
  try {
    $request = Read-HttpRequest $client
    $requestLine = [string]$request.RequestLine
    try { $allowedOrigin = Assert-AllowedOrigin ([string]$request.Origin) } catch {
      Send-JsonResponse $client 403 'Forbidden' ([ordered]@{ ok = $false }) ''
      return
    }
    $script:state.lastRequestAt = Get-NowMs

    if ($requestLine -match '^OPTIONS\s+') {
      Send-JsonResponse $client 204 'No Content' ([ordered]@{ ok = $true }) $allowedOrigin
      return
    }
    if ($requestLine -match '^GET\s+/state(?:\?|\s)') {
      Send-JsonResponse $client 200 'OK' (Get-PublicState) $allowedOrigin
      return
    }
    if ($requestLine -match '^POST\s+/dashboard-state(?:\?|\s)') {
      try { Assert-LocalAuthenticated ([string]$request.AuthToken) } catch { Send-JsonResponse $client 403 'Forbidden' ([ordered]@{ ok = $false }) ''; return }
      Send-JsonResponse $client 200 'OK' (Get-DashboardState) ''
      return
    }
    if ($requestLine -match '^GET\s+/config(?:\?|\s)') {
      Send-JsonResponse $client 200 'OK' ([ordered]@{ ok = $true; config = Get-RuntimeConfig }) $allowedOrigin
      return
    }
    if ($requestLine -match '^(?:GET|POST)\s+/command(?:\?|\s)') {
      try { $allowedOrigin = Assert-BrowserAuthenticated ([string]$request.Origin) ([string]$request.AuthToken) } catch { Send-JsonResponse $client 403 'Forbidden' ([ordered]@{ ok = $false }) ''; return }
      if ($script:pendingCommand -and ((Get-NowMs) - [long]$script:pendingCommand.createdAt -gt 75000)) { $script:pendingCommand = $null }
      Send-JsonResponse $client 200 'OK' ([ordered]@{ ok = $true; command = $script:pendingCommand }) $allowedOrigin
      return
    }

    if ($requestLine -match '^POST\s+/validate-session(?:\?|\s)') {
      try {
        $browserOrigin = Assert-BrowserAuthenticated ([string]$request.Origin) ([string]$request.AuthToken)
        $incoming = $request.Body | ConvertFrom-Json
        if (-not (Test-FixedTimeToken ([string]$incoming.token))) { throw 'Token mismatch.' }
        Send-JsonResponse $client 200 'OK' ([ordered]@{ ok = $true; version = $Version }) $browserOrigin
      } catch { Send-JsonResponse $client 403 'Forbidden' ([ordered]@{ ok = $false }) '' }
      return
    }

    if ($requestLine -match '^POST\s+/browser-event(?:\?|\s)') {
      try { $allowedOrigin = Assert-BrowserAuthenticated ([string]$request.Origin) ([string]$request.AuthToken) } catch { Send-JsonResponse $client 403 'Forbidden' ([ordered]@{ ok = $false }) ''; return }
      try {
        $incoming = $request.Body | ConvertFrom-Json
        if ($null -eq $incoming.tabId) { throw 'Missing tabId.' }
        $tabId = [int]$incoming.tabId
        $allowedStatuses = @('RUNNING','COMPLETE','WAITING_INPUT','PAUSED','STUCK_THINKING','TIMEOUT','UNCERTAIN','PAGE_STALE','RECOVERY_FAILED','RECOVERED','MONITORING_RECOVERED','CONNECTION_LOST','FAILED','IDLE','TEST')
        $status = Get-SafeString $incoming.status 40
        if ($allowedStatuses -notcontains $status) { throw 'Invalid status.' }
        $claimedStatus = $status
        $progress = Get-ValidatedProgress $incoming.progress
        $safeCompletion = Get-SafeCompletion $incoming.safeCompletion
        $status = Get-NormalizedStatus $status $safeCompletion
        if ($claimedStatus -eq 'COMPLETE' -and -not $safeCompletion) { $progress = $null }
        if ($status -ne 'COMPLETE') { $safeCompletion = $false }
        if ($status -eq 'COMPLETE' -and $null -eq $progress) { $progress = 100.0 }
        $updatedAt = Get-NowMs
        $event = [ordered]@{
          tabId = $tabId
          windowId = $incoming.windowId
          status = $status
          title = Get-SafeTitle $incoming.title
          url = Get-SafeString $incoming.url 2048
          conversationId = Get-SafeString $incoming.conversationId 96
          progress = $progress
          progressEstimated = ($incoming.progressEstimated -eq $true -and $status -ne 'COMPLETE')
          runSeconds = $incoming.runSeconds
          showPopup = [bool]$incoming.showPopup
          autoDiscardableProtected = [bool]$incoming.autoDiscardableProtected
          discarded = [bool]$incoming.discarded
          transient = [bool]$incoming.transient
          safeCompletion = $safeCompletion
          manualAction = [bool]$incoming.manualAction
          eventId = Get-SafeString $incoming.eventId 160
          episodeId = Get-SafeString $incoming.episodeId 160
          episodeRevision = [long]$incoming.episodeRevision
          at = $incoming.at
        }
        # Status metadata only. Prompt and response text are never accepted by this bridge.
        if (-not $event.transient -and $tabId -ge 0) {
          $tab = Get-TabRecord $tabId
          $previousStatus = [string]$tab.status
          $sameEpisode = $event.episodeId -and $tab.episodeId -and ([string]$event.episodeId -eq [string]$tab.episodeId)
          $terminalLocked = $sameEpisode -and ([string]$tab.episodeState -eq 'COMPLETE')
          if ($terminalLocked -and $event.status -ne 'COMPLETE') {
            $event.executionState = $event.status
            $event.status = 'COMPLETE'
            $event.progress = 100
            $event.safeCompletion = $true
          }
          if ($event.status -eq 'COMPLETE' -and $event.safeCompletion) { $event.progress = 100 }
          $tab.windowId = $event.windowId
          $tab.title = $event.title
          $tab.url = $event.url
          $tab.conversationId = $event.conversationId
          $tab.monitoringState = 'CONNECTED'
          $tab.generationState = $event.status
          $tab.status = $event.status
          $tab.progress = $event.progress
          $tab.progressEstimated = ($event.progressEstimated -eq $true -and $event.status -ne 'COMPLETE')
          $tab.updatedAt = $updatedAt
          $tab.safeCompletion = $event.safeCompletion
          $tab.episodeId = if ($event.episodeId) { $event.episodeId } else { $tab.episodeId }
          $tab.episodeState = if ($event.status -eq 'COMPLETE' -and $event.safeCompletion) { 'COMPLETE' } else { $event.status }
          $tab.executionState = if ($event.executionState) { $event.executionState } else { $event.status }
          $tab.episodeRevision = [long]$event.episodeRevision
          $tab.terminalEventId = if ($event.eventId) { $event.eventId } else { $tab.terminalEventId }
          $tab.lastStateChange = $updatedAt
          $tab.lastHeartbeat = $updatedAt
          $script:state.browser.lastExtensionHeartbeatAt = $updatedAt
          if ($event.showPopup) { $tab.notificationState = $event.status }
          elseif ($event.status -eq 'COMPLETE' -or ($event.status -eq 'RUNNING' -and $previousStatus -ne 'RUNNING')) { $tab.notificationState = $null }
          $tab.autoDiscardableProtected = $event.autoDiscardableProtected
          $tab.discarded = $event.discarded
        }
        if ($null -ne $event.windowId) { $script:state.browser.managedWindowId = $event.windowId }
        $script:state.browser.lastEvent = $event
        $script:state.browser.lastEventAt = Get-NowMs
        if ($event.showPopup -and ((-not $event.eventId) -or (-not $script:ackedEventIds.ContainsKey([string]$event.eventId) -and -not (@($script:popupEvents | Where-Object { [string]$_.eventId -eq [string]$event.eventId }).Count -gt 0)))) {
          $script:popupSequence++
          $queuedPopup = Get-PublicEvent $event
          $queuedPopup['popupSequence'] = $script:popupSequence
          [void]$script:popupEvents.Add($queuedPopup)
          while ($script:popupEvents.Count -gt 64) { $script:popupEvents.RemoveAt(0) }
          Save-PopupDurableState
        }
        Send-JsonResponse $client 200 'OK' ([ordered]@{ ok = $true; queued = [bool]$event.showPopup; eventId = $event.eventId }) $allowedOrigin
      } catch { Send-JsonResponse $client 400 'Bad Request' ([ordered]@{ ok = $false }) $allowedOrigin }
      return
    }

    if ($requestLine -match '^POST\s+/browser-heartbeat(?:\?|\s)') {
      try { $allowedOrigin = Assert-BrowserAuthenticated ([string]$request.Origin) ([string]$request.AuthToken) } catch { Send-JsonResponse $client 403 'Forbidden' ([ordered]@{ ok = $false }) ''; return }
      try {
        $incoming = $request.Body | ConvertFrom-Json
        $tabId = [int]$incoming.tabId
        if ($tabId -lt 0) { throw 'Invalid tabId.' }
        $tab = Get-TabRecord $tabId
        $progress = Get-ValidatedProgress $incoming.progress
        $safeCompletion = Get-SafeCompletion $incoming.safeCompletion
        $tab.windowId = $incoming.windowId
        $tab.title = Get-SafeTitle $incoming.title
        $tab.url = Get-SafeString $incoming.url 2048
        $tab.conversationId = Get-SafeString $incoming.conversationId 96
        $tab.monitoringState = 'CONNECTED'
        $heartbeatStatuses = @('RUNNING','COMPLETE','WAITING_INPUT','PAUSED','STUCK_THINKING','TIMEOUT','UNCERTAIN','PAGE_STALE','RECOVERY_FAILED','RECOVERED','MONITORING_RECOVERED','CONNECTION_LOST','FAILED','IDLE')
        $heartbeatStatus = Get-SafeString $incoming.status 40
        if ($heartbeatStatuses -notcontains $heartbeatStatus) { throw 'Invalid heartbeat status.' }
        $claimedHeartbeatStatus = $heartbeatStatus
        $heartbeatStatus = Get-NormalizedStatus $heartbeatStatus $safeCompletion
        if ($claimedHeartbeatStatus -eq 'COMPLETE' -and -not $safeCompletion) { $progress = $null }
        if ($heartbeatStatus -ne 'COMPLETE') { $safeCompletion = $false }
        if ($heartbeatStatus -eq 'COMPLETE' -and $null -eq $progress) { $progress = 100.0 }
        $sameEpisode = $incoming.episodeId -and $tab.episodeId -and ([string]$incoming.episodeId -eq [string]$tab.episodeId)
        $terminalLocked = $sameEpisode -and ([string]$tab.episodeState -eq 'COMPLETE')
        if ($terminalLocked -and $heartbeatStatus -ne 'COMPLETE') {
          $tab.executionState = $heartbeatStatus
          $heartbeatStatus = 'COMPLETE'
          $progress = 100
          $safeCompletion = $true
        }
        if ($heartbeatStatus -eq 'COMPLETE' -and $safeCompletion) { $progress = 100 }
        $tab.generationState = if ($terminalLocked) { [string]$incoming.status } else { $heartbeatStatus }
        $tab.status = $heartbeatStatus
        $tab.episodeState = if ($heartbeatStatus -eq 'COMPLETE' -and $safeCompletion) { 'COMPLETE' } else { $heartbeatStatus }
        $tab.executionState = if ($terminalLocked) { [string]$incoming.status } else { $heartbeatStatus }
        if ($incoming.episodeId) { $tab.episodeId = Get-SafeString $incoming.episodeId 160 }
        if ($incoming.episodeRevision -ne $null) { $tab.episodeRevision = [long]$incoming.episodeRevision }
        if ($incoming.eventId) { $tab.terminalEventId = Get-SafeString $incoming.eventId 160 }
        $tab.progress = $progress
        $tab.progressEstimated = ($incoming.progressEstimated -eq $true -and $heartbeatStatus -ne 'COMPLETE')
        $tab.updatedAt = Get-NowMs
        $tab.safeCompletion = $safeCompletion
        $tab.lastHeartbeat = $tab.updatedAt
        $tab.autoDiscardableProtected = [bool]$incoming.autoDiscardableProtected
        $tab.discarded = [bool]$incoming.discarded
        if ($null -ne $incoming.windowId) { $script:state.browser.managedWindowId = $incoming.windowId }
        $script:state.browser.lastExtensionHeartbeatAt = $tab.updatedAt
        Send-JsonResponse $client 200 'OK' ([ordered]@{ ok = $true }) $allowedOrigin
      } catch { Send-JsonResponse $client 400 'Bad Request' ([ordered]@{ ok = $false }) $allowedOrigin }
      return
    }

    if ($requestLine -match '^POST\s+/browser-lifecycle(?:\?|\s)') {
      try { $allowedOrigin = Assert-BrowserAuthenticated ([string]$request.Origin) ([string]$request.AuthToken) } catch { Send-JsonResponse $client 403 'Forbidden' ([ordered]@{ ok = $false }) ''; return }
      try {
        $incoming = $request.Body | ConvertFrom-Json
        $tabId = [int]$incoming.tabId
        if ($tabId -lt 0) { throw 'Invalid tabId.' }
        $tab = Get-TabRecord $tabId
        $tab.windowId = $incoming.windowId
        $tab.url = Get-SafeString $incoming.url 2048
        $tab.conversationId = Get-SafeString $incoming.conversationId 96
        $tab.lastLifecycle = Get-SafeString $incoming.event 60
        $tab.lastLifecycleAt = Get-NowMs
        $tab.monitoringState = if ($tab.lastLifecycle -eq 'NAVIGATED_AWAY') { 'DETACHED' } else { 'CONNECTED' }
        $script:state.browser.lastLifecycleAt = Get-NowMs
        Send-JsonResponse $client 200 'OK' ([ordered]@{ ok = $true }) $allowedOrigin
      } catch { Send-JsonResponse $client 400 'Bad Request' ([ordered]@{ ok = $false }) $allowedOrigin }
      return
    }

    if ($requestLine -match '^POST\s+/browser-tabs-sync(?:\?|\s)') {
      try { $allowedOrigin = Assert-BrowserAuthenticated ([string]$request.Origin) ([string]$request.AuthToken) } catch { Send-JsonResponse $client 403 'Forbidden' ([ordered]@{ ok = $false }) ''; return }
      try {
        $incoming = $request.Body | ConvertFrom-Json
        if ($incoming.tabIds -isnot [System.Array] -or $incoming.tabIds.Count -gt 2000) { throw 'Expected a bounded tab ID array.' }
        $liveIds = @{}
        foreach ($id in $incoming.tabIds) {
          if (($id -isnot [int] -and $id -isnot [long]) -or $id -lt 0 -or $id -gt [int]::MaxValue) { throw 'Invalid tab ID.' }
          $liveIds[[string]$id] = $true
        }
        # Validate the entire snapshot before removing anything. Missing live
        # heartbeats alone are not evidence that a tab has been closed.
        $removed = 0
        foreach ($key in @($script:browserTabs.Keys)) {
          if (-not $liveIds.ContainsKey($key)) { [void]$script:browserTabs.Remove($key); $removed++ }
        }
        Send-JsonResponse $client 200 'OK' ([ordered]@{ ok = $true; removed = $removed }) $allowedOrigin
      } catch { Send-JsonResponse $client 400 'Bad Request' ([ordered]@{ ok = $false }) $allowedOrigin }
      return
    }

    if ($requestLine -match '^POST\s+/browser-tab-closed(?:\?|\s)') {
      try { $allowedOrigin = Assert-BrowserAuthenticated ([string]$request.Origin) ([string]$request.AuthToken) } catch { Send-JsonResponse $client 403 'Forbidden' ([ordered]@{ ok = $false }) ''; return }
      try {
        $incoming = $request.Body | ConvertFrom-Json
        if ($null -eq $incoming.tabId) { throw 'Missing tabId.' }
        $tabId = [int]$incoming.tabId
        if ($tabId -lt 0) { throw 'Invalid tabId.' }
        [void]$script:browserTabs.Remove([string]$tabId)
        Send-JsonResponse $client 200 'OK' ([ordered]@{ ok = $true }) $allowedOrigin
      } catch { Send-JsonResponse $client 400 'Bad Request' ([ordered]@{ ok = $false }) $allowedOrigin }
      return
    }

    if ($requestLine -match '^POST\s+/show-managed-window(?:\?|\s)') {
      try { $allowedOrigin = Assert-BrowserAuthenticated ([string]$request.Origin) ([string]$request.AuthToken) } catch { Send-JsonResponse $client 403 'Forbidden' ([ordered]@{ ok = $false }) ''; return }
      $target = $null
      try { if ($request.Body) { $incoming = $request.Body | ConvertFrom-Json; if ($null -ne $incoming.targetTabId) { $target = [int]$incoming.targetTabId } } } catch {}
      $script:state.browser.focusRequestedAt = Get-NowMs
      $script:state.browser.focusRequestedTabId = $target
      Send-JsonResponse $client 200 'OK' ([ordered]@{ ok = $true }) $allowedOrigin
      return
    }

    if ($requestLine -match '^POST\s+/request-tab-focus(?:\?|\s)') {
      try { Assert-LocalAuthenticated ([string]$request.AuthToken) } catch { Send-JsonResponse $client 403 'Forbidden' ([ordered]@{ ok = $false }) ''; return }
      try {
        $incoming = $request.Body | ConvertFrom-Json
        $target = [int]$incoming.targetTabId
        if ($target -lt 0 -or -not $script:browserTabs.ContainsKey([string]$target)) { throw 'Target tab is not managed.' }
        $script:state.browser.focusRequestedAt = Get-NowMs
        $script:state.browser.focusRequestedTabId = $target
        $command = New-Command 'ACTIVATE_TAB' $target
        Send-JsonResponse $client 200 'OK' ([ordered]@{ ok = $true; requestId = $command.requestId }) $allowedOrigin
      } catch { Send-JsonResponse $client 400 'Bad Request' ([ordered]@{ ok = $false }) $allowedOrigin }
      return
    }

    if ($requestLine -match '^POST\s+/request-repair(?:\?|\s)') {
      try { Assert-LocalAuthenticated ([string]$request.AuthToken) } catch { Send-JsonResponse $client 403 'Forbidden' ([ordered]@{ ok = $false }) ''; return }
      $command = New-Command 'REPAIR_CONNECTION' $null
      Send-JsonResponse $client 200 'OK' ([ordered]@{ ok = $true; requestId = $command.requestId }) $allowedOrigin
      return
    }

    if ($requestLine -match '^POST\s+/diagnostic-ping(?:\?|\s)') {
      try { Assert-LocalAuthenticated ([string]$request.AuthToken) } catch { Send-JsonResponse $client 403 'Forbidden' ([ordered]@{ ok = $false }) ''; return }
      $command = New-Command 'DIAGNOSTIC_PING' $null
      Send-JsonResponse $client 200 'OK' ([ordered]@{ ok = $true; requestId = $command.requestId }) $allowedOrigin
      return
    }

    if ($requestLine -match '^POST\s+/command-ack(?:\?|\s)') {
      try { $allowedOrigin = Assert-BrowserAuthenticated ([string]$request.Origin) ([string]$request.AuthToken) } catch { Send-JsonResponse $client 403 'Forbidden' ([ordered]@{ ok = $false }) ''; return }
      try {
        $incoming = $request.Body | ConvertFrom-Json
        if ($null -eq $script:pendingCommand -or [string]$incoming.requestId -ne [string]$script:pendingCommand.requestId) { throw 'Unknown command.' }
        $script:state.browser.commandAckAt = Get-NowMs
        $script:state.browser.commandAckOk = [bool]$incoming.ok
        $script:state.browser.commandAckDetail = Get-SafeString $incoming.detail 200
        $script:pendingCommand = $null
        Send-JsonResponse $client 200 'OK' ([ordered]@{ ok = $true }) $allowedOrigin
      } catch { Send-JsonResponse $client 400 'Bad Request' ([ordered]@{ ok = $false }) $allowedOrigin }
      return
    }

    if ($requestLine -match '^POST\s+/browser-event-ack(?:\?|\s)') {
      try { $allowedOrigin = Assert-BrowserAuthenticated ([string]$request.Origin) ([string]$request.AuthToken) } catch { Send-JsonResponse $client 403 'Forbidden' ([ordered]@{ ok = $false }) ''; return }
      try {
        $incoming = $request.Body | ConvertFrom-Json
        $eventId = Get-SafeString $incoming.eventId 160
        if (-not $eventId) { throw 'Missing eventId.' }
        $script:ackedEventIds[$eventId] = Get-NowMs
        $remaining = New-Object System.Collections.ArrayList
        foreach ($popup in @($script:popupEvents | Where-Object { [string]$_.eventId -ne $eventId })) { [void]$remaining.Add($popup) }
        $script:popupEvents = $remaining
        foreach ($entry in $script:browserTabs.GetEnumerator()) { if ([string]$entry.Value.terminalEventId -eq $eventId) { $entry.Value.notificationState = 'COMPLETE' } }
        Save-PopupDurableState
        Send-JsonResponse $client 200 'OK' ([ordered]@{ ok = $true; eventId = $eventId; acknowledged = $true }) $allowedOrigin
      } catch { Send-JsonResponse $client 400 'Bad Request' ([ordered]@{ ok = $false }) $allowedOrigin }
      return
    }

    Send-JsonResponse $client 404 'Not Found' ([ordered]@{ ok = $false }) $allowedOrigin
  } catch {
    Send-JsonResponse $client 400 'Bad Request' ([ordered]@{ ok = $false }) ''
  }
}

try {
  while ($true) {
    if ($listener.Pending()) { Service-HttpRequest } else { Start-Sleep -Milliseconds 50 }
  }
} finally {
  try { $listener.Stop() } catch {}
  try { Remove-Item -LiteralPath $pidFile -Force } catch {}
  try { $mutex.ReleaseMutex(); $mutex.Dispose() } catch {}
}
