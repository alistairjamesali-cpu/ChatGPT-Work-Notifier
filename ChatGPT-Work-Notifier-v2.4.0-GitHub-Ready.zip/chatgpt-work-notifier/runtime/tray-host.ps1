param([switch]$NoAutoLaunch)

$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type @'
using System;
using System.Text;
using System.Runtime.InteropServices;
using System.Collections.Generic;
public static class CwnWin32 {
  public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool IsHungAppWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);
  public static uint ProcessIdForWindow(IntPtr hWnd) {
    uint pid; GetWindowThreadProcessId(hWnd, out pid); return pid;
  }
  public static bool IsChromeTopLevelWindow(IntPtr hWnd) {
    if (!IsWindow(hWnd)) return false;
    var cls = new StringBuilder(128);
    GetClassName(hWnd, cls, cls.Capacity);
    if (!cls.ToString().StartsWith("Chrome_WidgetWin_", StringComparison.Ordinal)) return false;
    uint pid; GetWindowThreadProcessId(hWnd, out pid);
    try {
      var p = System.Diagnostics.Process.GetProcessById((int)pid);
      return p.ProcessName.Equals("chrome", StringComparison.OrdinalIgnoreCase);
    } catch { return false; }
  }

  public static List<long> ChromeWindows() {
    var list = new List<long>();
    EnumWindows((h,l) => {
      uint pid; GetWindowThreadProcessId(h, out pid);
      try {
        var p = System.Diagnostics.Process.GetProcessById((int)pid);
        if (!p.ProcessName.Equals("chrome", StringComparison.OrdinalIgnoreCase) || !IsWindowVisible(h)) return true;
        var cls = new StringBuilder(128);
        GetClassName(h, cls, cls.Capacity);
        if (!cls.ToString().StartsWith("Chrome_WidgetWin_", StringComparison.Ordinal)) return true;
        var title = new StringBuilder(512);
        GetWindowText(h, title, title.Capacity);
        if (title.Length > 0) list.Add(h.ToInt64());
      } catch {}
      return true;
    }, IntPtr.Zero);
    return list;
  }

  public static List<long> ChromeTopLevelWindowsForProcess(uint targetPid) {
    var list = new List<long>();
    EnumWindows((h,l) => {
      uint pid; GetWindowThreadProcessId(h, out pid);
      if (pid != targetPid) return true;
      var cls = new StringBuilder(128);
      GetClassName(h, cls, cls.Capacity);
      if (!cls.ToString().StartsWith("Chrome_WidgetWin_", StringComparison.Ordinal)) return true;
      var title = new StringBuilder(512);
      GetWindowText(h, title, title.Capacity);
      if (title.Length > 0) list.Add(h.ToInt64());
      return true;
    }, IntPtr.Zero);
    return list;
  }
}

public static class CwnPower {
  [DllImport("kernel32.dll", SetLastError=true)]
  public static extern uint SetThreadExecutionState(uint esFlags);

  [StructLayout(LayoutKind.Sequential)]
  public struct SYSTEM_POWER_STATUS {
    public byte ACLineStatus;
    public byte BatteryFlag;
    public byte BatteryLifePercent;
    public byte SystemStatusFlag;
    public uint BatteryLifeTime;
    public uint BatteryFullLifeTime;
  }

  [DllImport("kernel32.dll", SetLastError=true)]
  public static extern bool GetSystemPowerStatus(out SYSTEM_POWER_STATUS status);
}
'@

$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$runtimeDir = Join-Path $root 'runtime'

$Version = '2.4.0'
$mutex = New-Object System.Threading.Mutex($false, 'Local\ChatGPTWorkNotifierTrayHostV21')
if (-not $mutex.WaitOne(0, $false)) { exit 0 }

$runtimeBase = Join-Path $env:LOCALAPPDATA 'ChatGPT Work Notifier'
$logDir = Join-Path $runtimeBase 'Logs'
$stateFile = Join-Path $runtimeBase 'managed-window.json'
$settingsFile = Join-Path $runtimeBase 'settings.json'
$runtimeStateFile = Join-Path $runtimeBase 'runtime-state.json'
$bridgeUrl = 'http://127.0.0.1:38765'
$bridgeScript = Join-Path $runtimeDir 'browser-bridge.ps1'
$launchConfigPath = Join-Path $runtimeDir 'chrome-launch.json'
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
$logFile = Join-Path $logDir 'tray-host.log'

function Log([string]$Message) { Add-Content -LiteralPath $logFile -Value ("{0:u} {1}" -f (Get-Date), $Message) }
function Get-NowMs { return [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() }

function Write-JsonAtomic([string]$Path, $Object, [int]$Depth = 8) {
  $dir = Split-Path -Parent $Path
  New-Item -ItemType Directory -Path $dir -Force | Out-Null
  $tmp = Join-Path $dir ((Split-Path -Leaf $Path) + '.' + [Guid]::NewGuid().ToString('N') + '.tmp')
  $backup = Join-Path $dir ((Split-Path -Leaf $Path) + '.' + [Guid]::NewGuid().ToString('N') + '.bak')
  try {
    $json = $Object | ConvertTo-Json -Depth $Depth
    [System.IO.File]::WriteAllText($tmp, $json, [System.Text.UTF8Encoding]::new($false))
    if (Test-Path -LiteralPath $Path) { [System.IO.File]::Replace($tmp, $Path, $backup, $true) } else { [System.IO.File]::Move($tmp, $Path) }
  } finally {
    if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
    if (Test-Path -LiteralPath $backup) { Remove-Item -LiteralPath $backup -Force -ErrorAction SilentlyContinue }
  }
}

function Test-SafeChromeProfile([string]$Profile) {
  if ([string]::IsNullOrWhiteSpace($Profile) -or $Profile.Length -gt 128) { return $false }
  if ($Profile -match '[\\/:*?"<>|]' -or $Profile -eq '.' -or $Profile -eq '..' -or $Profile.Contains('..')) { return $false }
  $userData = Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data'
  return (Test-Path -LiteralPath (Join-Path $userData $Profile) -PathType Container)
}

function Get-WindowsPowerShellPath {
  $candidate = Join-Path $PSHOME 'powershell.exe'
  if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
  $candidate = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
  if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
  return $null
}

function Get-DefaultSettings {
  return [ordered]@{
    monitoringEnabled = $true
    keepComputerAwake = $true
    keepDisplayAwake = $false
    autoRecoverChrome = $true
    autoRepairConnection = $true
    allowControlledStaleRecovery = $true
    backgroundReliabilityDiagnostics = $true
  }
}

function Load-Settings {
  $defaults = Get-DefaultSettings
  if (Test-Path $settingsFile) {
    try {
      $loaded = Get-Content -LiteralPath $settingsFile -Raw | ConvertFrom-Json
      foreach ($name in @($defaults.Keys)) { if ($null -ne $loaded.$name) { if ($loaded.$name -is [bool]) { $defaults[$name] = [bool]$loaded.$name } else { Log "Ignoring malformed non-boolean setting: $name" } } }
    } catch { Log ("Settings load failed; safe defaults retained: " + $_.Exception.Message) }
  }
  return $defaults
}

function Save-Settings {
  try {
    Write-JsonAtomic $settingsFile $script:Settings 4
  } catch { Log ("Settings save failed: " + $_.Exception.Message) }
}

function Find-Chrome {
  $candidates = @(
    (Join-Path ${env:ProgramFiles} 'Google\Chrome\Application\chrome.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
    (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
  )
  foreach ($c in $candidates) { if ($c -and (Test-Path $c)) { return $c } }
  return $null
}

function Get-ChromeLastProfile {
  $localState = Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data\Local State'
  if (Test-Path -LiteralPath $localState) {
    try {
      $state = Get-Content -LiteralPath $localState -Raw | ConvertFrom-Json
      if ($state.profile.last_used) { $candidate = [string]$state.profile.last_used; if (Test-SafeChromeProfile $candidate) { return $candidate }; Log 'Chrome Local State contained an unsafe or missing profile directory; falling back to Default.' }
    } catch {}
  }
  return 'Default'
}

function Get-LaunchConfig {
  try { return Get-Content -LiteralPath $launchConfigPath -Raw | ConvertFrom-Json } catch {
    return [pscustomobject]@{
      requiredSwitches = @()
      prohibitedSwitches = @('--no-sandbox','--disable-web-security','--ignore-certificate-errors')
    }
  }
}

function Add-UniqueArgument($List, $Seen, [string]$Argument) {
  if (-not $Argument) { return }
  $key = $Argument.ToLowerInvariant()
  if ($Argument.StartsWith('--')) { $key = ($Argument -split '=',2)[0].ToLowerInvariant() }
  if (-not $Seen.ContainsKey($key)) {
    $Seen[$key] = $true
    [void]$List.Add($Argument)
  }
}

function Quote-ChromeValue([string]$Value) {
  return '"' + ($Value -replace '"','\"') + '"'
}

function Build-ManagedChromeArguments([string]$Token) {
  $list = New-Object System.Collections.Generic.List[string]
  $seen = @{}
  $config = Get-LaunchConfig
  Add-UniqueArgument $list $seen ('--profile-directory=' + (Quote-ChromeValue $script:Profile))
  Add-UniqueArgument $list $seen '--new-window'
  Add-UniqueArgument $list $seen ("https://chatgpt.com/?cwn_managed=$Token")

  foreach ($bad in @($config.prohibitedSwitches)) {
    if ($list -contains [string]$bad) { throw "Prohibited Chrome switch requested: $bad" }
  }
  return @($list)
}

$script:Settings = Load-Settings
$script:ChromePath = Find-Chrome
$script:Profile = Get-ChromeLastProfile
$script:ManagedHwnd = [IntPtr]::Zero
$script:ManagedToken = $null
$script:IsHidden = $false
$script:HadManagedWindow = $false
$script:BridgeMisses = 0
$script:BridgeWasDown = $false
$script:ChromeMisses = 0
$script:HungMisses = 0
$script:ExtensionStaleSince = 0
$script:ExtensionStaleAlerted = $false
$script:LastExtensionRepairAt = 0
$script:LastFocusRequestAt = 0
$script:LastPopupEventAt = 0
$script:LastPopupSequence = 0
$script:PopupInitialized = $false
$script:PopupForm = $null
$script:PopupEvent = $null
$script:ManualPopupQueue = @()
$script:AwakeActive = $false
$script:RecoveryStatus = 'HEALTHY'
$script:DiagnosticTick = 0
$script:LastBridgeState = $null

function Update-AwakeProtection {
  $shouldKeepAwake = [bool]$script:Settings.monitoringEnabled -and [bool]$script:Settings.keepComputerAwake
  if ($shouldKeepAwake) {
    [uint32]$flags = 0x80000001
    if ([bool]$script:Settings.keepDisplayAwake) { $flags = $flags -bor 0x00000002 }
    $r = [CwnPower]::SetThreadExecutionState($flags)
    $script:AwakeActive = ($r -ne 0)
  } else {
    [void][CwnPower]::SetThreadExecutionState(0x80000000)
    $script:AwakeActive = $false
  }
}

function Get-PowerSourceState {
  try {
    $status = New-Object CwnPower+SYSTEM_POWER_STATUS
    if ([CwnPower]::GetSystemPowerStatus([ref]$status)) {
      if ($status.ACLineStatus -eq 1) { return 'AC' }
      if ($status.ACLineStatus -eq 0) { return 'BATTERY' }
    }
  } catch {}
  return 'UNKNOWN'
}

function Get-PowerSourceText {
  switch (Get-PowerSourceState) {
    'AC' { return 'AC power' }
    'BATTERY' { return 'Battery power' }
    default { return 'Power source unknown' }
  }
}

function Save-ManagedState {
  try {
    $obj = [ordered]@{
      version = $Version
      hwnd = $script:ManagedHwnd.ToInt64()
      token = $script:ManagedToken
      profile = $script:Profile
      usesOriginalChromeProfile = $true
      hidden = $script:IsHidden
      updatedAt = (Get-Date).ToUniversalTime().ToString('o')
    }
    Write-JsonAtomic $stateFile $obj 4
  } catch { Log ("Managed state save failed: " + $_.Exception.Message) }
}

function Load-ManagedState {
  if (-not (Test-Path $stateFile)) { return }
  try {
    $s = Get-Content -LiteralPath $stateFile -Raw | ConvertFrom-Json
    if ($s.profile -and (Test-SafeChromeProfile ([string]$s.profile))) { $script:Profile = [string]$s.profile }
    if ($s.hwnd -and ([string]$s.token -match '^[a-f0-9]{32}$')) {
      $h = [IntPtr][long]$s.hwnd
      if ([CwnWin32]::IsChromeTopLevelWindow($h)) {
        $script:ManagedHwnd = $h
        $script:ManagedToken = [string]$s.token
        $script:IsHidden = [bool]$s.hidden
        $script:HadManagedWindow = $true
      } else { Log 'Rejected stale managed-window handle because it is not a Chrome top-level window.' }
    }
  } catch { Log ("Managed state load failed; ignoring invalid persisted state: " + $_.Exception.Message) }
  if ($script:ManagedHwnd -eq [IntPtr]::Zero) { [void](Refresh-ManagedWindowHandle) }
}

function Invoke-Bridge([string]$Path, [string]$Method = 'GET', $Body = $null, [int]$TimeoutSec = 1) {
  try {
    $headers = @{}
    if ($Method -ne 'GET' -and $script:ManagedToken -match '^[a-f0-9]{32}$') { $headers['X-CWN-Token'] = $script:ManagedToken }
    if ($Body -ne $null) {
      $json = $Body | ConvertTo-Json -Compress -Depth 8
      return Invoke-RestMethod -Uri ($bridgeUrl + $Path) -Method $Method -Headers $headers -ContentType 'application/json' -Body $json -TimeoutSec $TimeoutSec
    }
    return Invoke-RestMethod -Uri ($bridgeUrl + $Path) -Method $Method -Headers $headers -TimeoutSec $TimeoutSec
  } catch { return $null }
}

function Get-BridgeState {
  $s = $null
  if ($script:ManagedToken -match '^[a-f0-9]{32}$') { $s = Invoke-Bridge '/dashboard-state' 'POST' @{} 1 }
  if (-not $s) { $s = Invoke-Bridge '/state' 'GET' $null 1 }
  if ($s -and [string]$s.version -eq $Version -and [string]$s.mode -eq 'CHROME_ONLY') { return $s }
  return $null
}

function Select-CurrentTask($BridgeState) {
  if (-not $BridgeState -or -not $BridgeState.browser) { return $null }
  $manualStates = @('PAUSED','STUCK_THINKING','WAITING_INPUT','FAILED')
  $eligible = @($BridgeState.browser.tabs | Where-Object {
    $_ -and ([string]$_.monitoringState -notin @('DETACHED','CLOSED','PRUNED')) -and ([string]$_.lastLifecycle -notin @('NAVIGATED_AWAY','CLOSED','PRUNED'))
  })
  if ($eligible.Count -eq 0) { return $null }
  return $eligible | Sort-Object `
    @{ Expression = { if ($manualStates -contains [string]$_.status) { 0 } elseif ([string]$_.status -eq 'RUNNING') { 1 } else { 2 } } }, `
    @{ Expression = { if ($_.updatedAt) { [long]$_.updatedAt } else { 0 } }; Descending = $true }, `
    @{ Expression = { if ($null -ne $_.tabId) { [long]$_.tabId } else { -1 } }; Descending = $true } | Select-Object -First 1
}

function Stop-BrowserBridge {
  $stopped = $false
  $pidFile = Join-Path (Join-Path $runtimeBase 'Bridge') 'bridge.pid'
  if (Test-Path $pidFile) {
    try {
      $bridgePid = [int](Get-Content -LiteralPath $pidFile -Raw)
      $candidate = Get-CimInstance Win32_Process -Filter "ProcessId=$bridgePid"
      if ($candidate -and $candidate.Name -eq 'powershell.exe' -and $candidate.CommandLine -like '*browser-bridge.ps1*') {
        Stop-Process -Id $bridgePid -Force -ErrorAction SilentlyContinue
        $stopped = $true
      }
    } catch {}
  }
  if (-not $stopped) {
    try {
      $needle = $bridgeScript.ToLowerInvariant()
      Get-CimInstance Win32_Process | Where-Object {
        $_.Name -eq 'powershell.exe' -and $_.CommandLine -and $_.CommandLine.ToLowerInvariant().Contains($needle)
      } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    } catch {}
  }
  Start-Sleep -Milliseconds 250
}

function Start-BrowserBridge([switch]$Force) {
  if (-not (Test-Path $bridgeScript)) { Log 'Browser bridge script missing.'; return }
  if ($script:ManagedToken -notmatch '^[a-f0-9]{32}$') { Log 'Browser bridge start blocked: managed session token is unavailable.'; return }
  if (-not $Force) { if (Get-BridgeState) { return } }
  if ($Force) { Stop-BrowserBridge }
  try {
    $psExe = Get-WindowsPowerShellPath
    if (-not $psExe) { throw 'Windows PowerShell executable not found.' }
    $bridgeTokenFile = Join-Path $script:RuntimeBase 'Bridge\session-token.txt'
    $bridgeTokenDir = Split-Path -Parent $bridgeTokenFile
    New-Item -ItemType Directory -Path $bridgeTokenDir -Force | Out-Null
    [System.IO.File]::WriteAllText($bridgeTokenFile, $script:ManagedToken, [System.Text.UTF8Encoding]::new($false))
    $args = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$bridgeScript`" -SessionTokenFile `"$bridgeTokenFile`""
    $p = Start-Process -FilePath $psExe -WindowStyle Hidden -ArgumentList $args -PassThru
    Log "Browser bridge started pid=$($p.Id) with authenticated session channel."
  } catch { Log "Browser bridge start failed: $($_.Exception.Message)" }
}

function Get-ManagedWindowHandles {
  if ($script:ManagedHwnd -ne [IntPtr]::Zero -and [CwnWin32]::IsChromeTopLevelWindow($script:ManagedHwnd)) {
    return @($script:ManagedHwnd.ToInt64())
  }
  return @()
}

function Refresh-ManagedWindowHandle {
  if ($script:ManagedHwnd -ne [IntPtr]::Zero -and [CwnWin32]::IsChromeTopLevelWindow($script:ManagedHwnd)) { return $true }
  $handles = @(Get-ManagedWindowHandles)
  if ($handles.Count -gt 0) {
    $script:ManagedHwnd = [IntPtr][long]$handles[0]
    $script:HadManagedWindow = $true
    return $true
  }
  $script:ManagedHwnd = [IntPtr]::Zero
  return $false
}

function Wait-ForManagedChromeWindow([long[]]$Before) {
  [long]$stableHandle = 0
  [int]$stableSamples = 0
  [int]$ambiguousSamples = 0
  for ($i = 0; $i -lt 100; $i++) {
    Start-Sleep -Milliseconds 125
    $candidates = @([CwnWin32]::ChromeWindows() | Where-Object { $Before -notcontains [long]$_ })
    if ($candidates.Count -gt 1) {
      $ambiguousSamples++
      $stableHandle = 0
      $stableSamples = 0
      if ($ambiguousSamples -ge 8) {
        Log 'Managed Chrome capture refused because multiple new Chrome windows appeared concurrently and remained visible.'
        return [IntPtr]::Zero
      }
      continue
    }
    $ambiguousSamples = 0
    if ($candidates.Count -eq 1) {
      $candidate = [long]$candidates[0]
      if ($candidate -eq $stableHandle) { $stableSamples++ } else { $stableHandle = $candidate; $stableSamples = 1 }
      if ($stableSamples -ge 8) { return [IntPtr]$stableHandle }
    } else {
      $stableHandle = 0
      $stableSamples = 0
    }
  }
  return [IntPtr]::Zero
}

function Launch-ManagedChrome {
  if (-not $script:ChromePath -or -not (Test-Path $script:ChromePath)) {
    [System.Windows.Forms.MessageBox]::Show('Google Chrome was not found.', 'ChatGPT Work Notifier') | Out-Null
    return
  }
  if ($script:ManagedHwnd -ne [IntPtr]::Zero -and [CwnWin32]::IsChromeTopLevelWindow($script:ManagedHwnd)) { Show-ManagedChrome; return }

  $before = @([CwnWin32]::ChromeWindows())
  if ($script:ManagedToken -notmatch '^[a-f0-9]{32}$') { $script:ManagedToken = [Guid]::NewGuid().ToString('N'); Start-BrowserBridge -Force }
  try { $args = Build-ManagedChromeArguments $script:ManagedToken } catch {
    Log "Managed Chrome launch blocked: $($_.Exception.Message)"
    return
  }
  Log "Launching managed window in original Chrome profile=$($script:Profile); private session token redacted."
  Start-Process -FilePath $script:ChromePath -ArgumentList ($args -join ' ') | Out-Null
  $h = Wait-ForManagedChromeWindow $before
  if ($h -eq [IntPtr]::Zero) {
    Log 'Managed Chrome window capture failed.'
    [System.Windows.Forms.MessageBox]::Show('Managed Chrome started, but its window could not be identified. Use Restart Managed Chrome.', 'ChatGPT Work Notifier') | Out-Null
    return
  }
  $script:ManagedHwnd = $h
  $script:IsHidden = $false
  $script:HadManagedWindow = $true
  $script:ChromeMisses = 0
  $script:HungMisses = 0
  $script:RecoveryStatus = 'HEALTHY'
  Save-ManagedState
  Log "Managed Chrome hwnd=$($h.ToInt64()); private session token not logged."
}

function Hide-ManagedChrome {
  $handles = @(Get-ManagedWindowHandles)
  if ($handles.Count -eq 0) { return }
  foreach ($h in $handles) { [CwnWin32]::ShowWindow([IntPtr][long]$h, 0) | Out-Null }
  $script:ManagedHwnd = [IntPtr][long]$handles[0]
  $script:IsHidden = $true
  Save-ManagedState
  Log "Managed Chrome hidden to tray; $($handles.Count) managed window(s) remain running."
}

function Show-ManagedChrome {
  $handles = @(Get-ManagedWindowHandles)
  if ($handles.Count -eq 0) { Launch-ManagedChrome; return }
  foreach ($h in $handles) {
    [CwnWin32]::ShowWindow([IntPtr][long]$h, 9) | Out-Null
    [CwnWin32]::ShowWindow([IntPtr][long]$h, 5) | Out-Null
  }
  $script:ManagedHwnd = [IntPtr][long]$handles[0]
  [CwnWin32]::SetForegroundWindow($script:ManagedHwnd) | Out-Null
  $script:IsHidden = $false
  Save-ManagedState
}

function Has-RunningManagedWork($BridgeState) {
  if (-not $BridgeState -or -not $BridgeState.browser -or -not $BridgeState.browser.tabs) { return $false }
  foreach ($tab in @($BridgeState.browser.tabs)) {
    if ([string]$tab.generationState -eq 'RUNNING' -or [string]$tab.status -eq 'RUNNING') { return $true }
  }
  return $false
}

function Restart-ManagedChrome([switch]$Automatic) {
  if ($Automatic -and (Has-RunningManagedWork $script:LastBridgeState)) {
    $script:RecoveryStatus = 'DEGRADED'
    Log 'Automatic Chrome restart suppressed because a managed tab reports RUNNING.'
    return $false
  }
  $script:RecoveryStatus = 'REPAIRING'
  if ($script:ManagedHwnd -ne [IntPtr]::Zero -and [CwnWin32]::IsChromeTopLevelWindow($script:ManagedHwnd)) {
    $oldHwnd = $script:ManagedHwnd
    [CwnWin32]::PostMessage($oldHwnd, 0x0010, [IntPtr]::Zero, [IntPtr]::Zero) | Out-Null
    for ($i = 0; $i -lt 40 -and [CwnWin32]::IsChromeTopLevelWindow($oldHwnd); $i++) { Start-Sleep -Milliseconds 125 }
  }
  $script:ManagedHwnd = [IntPtr]::Zero
  $script:ManagedToken = $null
  $script:IsHidden = $false
  Start-Sleep -Milliseconds 300
  Launch-ManagedChrome
  return $true
}

function Repair-Connection {
  $script:RecoveryStatus = 'REPAIRING'
  Start-BrowserBridge -Force
  Start-Sleep -Milliseconds 350
  [void](Invoke-Bridge '/request-repair' 'POST' @{})
  Log 'Connection repair requested.'
}

function Request-TargetTabFocus([int]$TabId) {
  if ($TabId -ge 0) { [void](Invoke-Bridge '/request-tab-focus' 'POST' @{ targetTabId = $TabId }) }
  Show-ManagedChrome
}

function Open-ExtensionSetup {
  Show-ManagedChrome
  try { [System.Windows.Forms.Clipboard]::SetText($root) } catch {}
  if ($script:ChromePath -and (Test-Path $script:ChromePath)) {
    $args = @(
      '--profile-directory=' + (Quote-ChromeValue $script:Profile),
      'chrome://extensions/'
    )
    Start-Process -FilePath $script:ChromePath -ArgumentList ($args -join ' ') | Out-Null
  }
  [System.Windows.Forms.MessageBox]::Show(
    "In your normal Chrome profile, enable Developer mode, choose Load unpacked, then select this folder:`r`n`r`n$root`r`n`r`nThis is required only once for your existing Chrome profile.",
    'Managed Chrome extension setup'
  ) | Out-Null
}

function Test-ManualPopupStatus([string]$Status) {
  return @('WAITING_INPUT','PAUSED','STUCK_THINKING','FAILED') -contains $Status
}

function Get-PopupEventKey($Event) {
  $tabId = -1
  try { if ($null -ne $Event.tabId) { $tabId = [int]$Event.tabId } } catch {}
  $conversation = ''
  try { if ($Event.PSObject.Properties['conversationId'] -and $Event.conversationId) { $conversation = [string]$Event.conversationId } } catch {}
  return "{0}|{1}|{2}" -f ([string]$Event.status), $tabId, $conversation
}

function Add-ManualPopupQueue($Event) {
  if (-not $Event -or -not (Test-ManualPopupStatus ([string]$Event.status))) { return }
  $key = Get-PopupEventKey $Event
  if ($script:PopupEvent -and (Get-PopupEventKey $script:PopupEvent) -eq $key) { return }
  foreach ($queued in @($script:ManualPopupQueue)) { if ((Get-PopupEventKey $queued) -eq $key) { return } }
  $script:ManualPopupQueue += $Event
  Log "Manual popup queued key=$key queueCount=$($script:ManualPopupQueue.Count)."
}

function Test-QueuedManualEventStillActive($Event) {
  if (-not $Event) { return $false }
  $tabId = -1
  try { if ($null -ne $Event.tabId) { $tabId = [int]$Event.tabId } } catch {}
  if ($tabId -lt 0) { return $true }
  $state = Get-BridgeState
  if (-not $state -or -not $state.browser -or -not $state.browser.tabs) { return $true }
  $tab = @($state.browser.tabs) | Where-Object { [int]$_.tabId -eq $tabId } | Select-Object -First 1
  if (-not $tab) { return $false }
  return (Test-ManualPopupStatus ([string]$tab.status))
}

function Show-NextManualPopup {
  if ($script:PopupForm -and -not $script:PopupForm.IsDisposed) { return }
  while ($script:ManualPopupQueue.Count -gt 0) {
    $next = $script:ManualPopupQueue[0]
    if ($script:ManualPopupQueue.Count -eq 1) { $script:ManualPopupQueue = @() }
    else { $script:ManualPopupQueue = @($script:ManualPopupQueue[1..($script:ManualPopupQueue.Count - 1)]) }
    if (Test-QueuedManualEventStillActive $next) { Show-NotifierPopup $next; return }
  }
}

function Get-EventHeading([string]$Status) {
  switch ($Status) {
    'COMPLETE' { return 'Completed' }
    'WAITING_INPUT' { return 'Needs your input' }
    'PAUSED' { return 'Paused - Resume needed' }
    'STUCK_THINKING' { return 'Thinking stuck - Resume needed' }
    'TIMEOUT' { return 'Message timed out' }
    'UNCERTAIN' { return 'Verify manually' }
    'RECOVERY_FAILED' { return 'Recovery needs you' }
    'PAGE_STALE' { return 'ChatGPT page stale' }
    'RECOVERED' { return 'Monitoring recovered' }
    'MONITORING_RECOVERED' { return 'Monitoring recovered' }
    'CONNECTION_LOST' { return 'Connection lost' }
    'FAILED' { return 'Error' }
    'TEST' { return 'Notification test' }
    default { return 'ChatGPT update' }
  }
}

function Get-EventMessage($Event) {
  try { if ($Event.PSObject.Properties['customMessage'] -and $Event.customMessage) { return [string]$Event.customMessage } } catch {}
  $titleText = [string]$Event.title
  if (-not $titleText) { $titleText = 'Managed ChatGPT tab' }
  $progressText = ''
  if ($null -ne $Event.progress) { $progressText = " - $($Event.progress)%" }
  switch ([string]$Event.status) {
    'COMPLETE' { return "$titleText$progressText - work finished." }
    'WAITING_INPUT' { return "$titleText - reply, confirmation, or upload may be required." }
    'PAUSED' { return "$titleText$progressText - work paused. Resume is required and may already be pre-filled; click Send manually." }
    'STUCK_THINKING' { return "$titleText$progressText - ChatGPT is stuck on Thinking. Resume manually." }
    'TIMEOUT' { return "$titleText$progressText - message delivery timed out. Completion is blocked; safe recovery is rate-limited." }
    'UNCERTAIN' { return "$titleText$progressText - completion cannot be verified. Check this tab manually." }
    'RECOVERY_FAILED' { return "$titleText - automatic safe recovery did not clear the problem. Recover manually." }
    'PAGE_STALE' { return "$titleText - controlled stale-page checks are active." }
    'RECOVERED' { return "$titleText - monitoring reattached successfully." }
    'MONITORING_RECOVERED' { return "$titleText - background monitoring is healthy again." }
    'CONNECTION_LOST' { return "$titleText - the local monitoring path was interrupted." }
    'FAILED' { return "$titleText - open the managed tab to inspect or retry." }
    'TEST' { return 'Primary in-program popup alerts are working.' }
    default { return "$titleText$progressText" }
  }
}

function Close-NotifierPopup {
  try { if ($script:PopupForm -and -not $script:PopupForm.IsDisposed) { $script:PopupForm.Close(); $script:PopupForm.Dispose() } } catch {}
  $script:PopupForm = $null
  $script:PopupEvent = $null
}

function Show-NotifierPopup($Event) {
  $newManual = Test-ManualPopupStatus ([string]$Event.status)
  $currentManual = ($script:PopupEvent -and (Test-ManualPopupStatus ([string]$script:PopupEvent.status)))
  if ($script:PopupForm -and -not $script:PopupForm.IsDisposed) {
    if ($currentManual) {
      if ($newManual) { Add-ManualPopupQueue $Event }
      return
    }
    Close-NotifierPopup
  }
  $popup = New-Object System.Windows.Forms.Form
  $popup.Text = 'ChatGPT Work Notifier'
  $popup.Size = New-Object System.Drawing.Size(450, 196)
  $popup.FormBorderStyle = 'None'
  $popup.StartPosition = 'Manual'
  $popup.BackColor = [System.Drawing.Color]::White
  $popup.TopMost = $true
  $popup.ShowInTaskbar = $false
  $popup.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
  $area = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
  $popup.Location = New-Object System.Drawing.Point(($area.Right - $popup.Width - 22), ($area.Bottom - $popup.Height - 22))

  $border = New-Object System.Windows.Forms.Panel
  $border.Dock = 'Fill'
  $border.BackColor = [System.Drawing.Color]::FromArgb(210,226,246)
  $popup.Controls.Add($border)

  $surface = New-Object System.Windows.Forms.Panel
  $surface.Location = New-Object System.Drawing.Point(1,1)
  $surface.Size = New-Object System.Drawing.Size(448,194)
  $surface.BackColor = [System.Drawing.Color]::White
  $popup.Controls.Add($surface)
  $border.SendToBack()
  $surface.BringToFront()

  $accent = New-Object System.Windows.Forms.Panel
  $accent.Location = New-Object System.Drawing.Point(0,0)
  $accent.Size = New-Object System.Drawing.Size(6,194)
  $accent.BackColor = [System.Drawing.Color]::FromArgb(37,99,235)
  $surface.Controls.Add($accent)

  $iconPath = Join-Path $root 'icons\icon48.png'
  if (Test-Path $iconPath) {
    $pic = New-Object System.Windows.Forms.PictureBox
    $sourceImage = [System.Drawing.Image]::FromFile($iconPath)
    try { $pic.Image = New-Object System.Drawing.Bitmap($sourceImage) }
    finally { $sourceImage.Dispose() }
    $pic.SizeMode = 'Zoom'
    $pic.Location = New-Object System.Drawing.Point(20,18)
    $pic.Size = New-Object System.Drawing.Size(44,44)
    $surface.Controls.Add($pic)
  }

  $app = New-Object System.Windows.Forms.Label
  $app.Text = 'ChatGPT Work Notifier'
  $app.ForeColor = [System.Drawing.Color]::FromArgb(83,101,125)
  $app.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9)
  $app.AutoSize = $true
  $app.Location = New-Object System.Drawing.Point(78,18)
  $surface.Controls.Add($app)

  $heading = New-Object System.Windows.Forms.Label
  $heading.Text = Get-EventHeading ([string]$Event.status)
  $heading.ForeColor = [System.Drawing.Color]::FromArgb(17,35,58)
  $heading.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 15)
  $heading.AutoSize = $true
  $heading.Location = New-Object System.Drawing.Point(76,38)
  $surface.Controls.Add($heading)

  $message = New-Object System.Windows.Forms.Label
  $message.Text = Get-EventMessage $Event
  $message.ForeColor = [System.Drawing.Color]::FromArgb(75,96,120)
  $message.Location = New-Object System.Drawing.Point(20,78)
  $message.Size = New-Object System.Drawing.Size(405,42)
  $surface.Controls.Add($message)

  $open = New-Object System.Windows.Forms.Button
  $open.Text = 'Open correct ChatGPT tab'
  $open.FlatStyle = 'Flat'
  $open.FlatAppearance.BorderSize = 0
  $open.BackColor = [System.Drawing.Color]::FromArgb(37,99,235)
  $open.ForeColor = [System.Drawing.Color]::White
  $open.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9.5)
  $open.Location = New-Object System.Drawing.Point(20,135)
  $open.Size = New-Object System.Drawing.Size(215,38)
  $surface.Controls.Add($open)

  $dismiss = New-Object System.Windows.Forms.Button
  $dismiss.Text = 'Dismiss'
  $dismiss.FlatStyle = 'Flat'
  $dismiss.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(198,215,235)
  $dismiss.BackColor = [System.Drawing.Color]::White
  $dismiss.ForeColor = [System.Drawing.Color]::FromArgb(39,65,94)
  $dismiss.Location = New-Object System.Drawing.Point(246,135)
  $dismiss.Size = New-Object System.Drawing.Size(105,38)
  $surface.Controls.Add($dismiss)

  $open.Add_Click({
    $activeEvent = $script:PopupEvent
    $targetTab = -1
    try { if ($activeEvent -and $null -ne $activeEvent.tabId) { $targetTab = [int]$activeEvent.tabId } } catch {}
    if ($targetTab -ge 0) { Request-TargetTabFocus $targetTab } else { Show-ManagedChrome }
    if (-not $activeEvent -or -not (Test-ManualPopupStatus ([string]$activeEvent.status))) { Close-NotifierPopup }
  })
  $dismiss.Add_Click({
    $wasManual = ($script:PopupEvent -and (Test-ManualPopupStatus ([string]$script:PopupEvent.status)))
    Close-NotifierPopup
    if ($wasManual) { Show-NextManualPopup }
  })
  $script:PopupForm = $popup
  $script:PopupEvent = $Event
  $popup.Show()
  [CwnWin32]::ShowWindow($popup.Handle, 4) | Out-Null
  $loggedTargetTab = -1
  try { if ($null -ne $Event.tabId) { $loggedTargetTab = [int]$Event.tabId } } catch {}
  Log "Custom popup shown status=$($Event.status) tab=$loggedTargetTab."
}

function Acknowledge-CompletionEvent($Event) {
  try {
    $eventId = [string]$Event.eventId
    if ($eventId -and [string]$Event.status -eq 'COMPLETE' -and [bool]$Event.safeCompletion) {
      [void](Invoke-Bridge '/browser-event-ack' 'POST' @{ eventId = $eventId } 1)
      Log "Completion event acknowledged eventId=$eventId."
    }
  } catch { Log 'Completion acknowledgement failed; service-worker outbox will retry.' 'WARN' }
}

function Show-SyntheticPopup([string]$Status, [string]$Message) {
  $event = [pscustomobject]@{ status = $Status; title = 'Background reliability'; progress = $null; tabId = -1 }
  if ($Message) { $event | Add-Member -MemberType NoteProperty -Name customMessage -Value $Message -Force }
  Show-NotifierPopup $event
}

function Write-RuntimeState($BridgeState) {
  try {
    $obj = [ordered]@{
      version = $Version
      at = (Get-Date).ToUniversalTime().ToString('o')
      monitoringEnabled = [bool]$script:Settings.monitoringEnabled
      awakeProtection = [bool]$script:AwakeActive
      keepDisplayAwake = [bool]$script:Settings.keepDisplayAwake
      managedHwnd = $script:ManagedHwnd.ToInt64()
      managedHidden = [bool]$script:IsHidden
      chromeAlive = ($script:ManagedHwnd -ne [IntPtr]::Zero -and [CwnWin32]::IsChromeTopLevelWindow($script:ManagedHwnd))
      chromeHung = ($script:ManagedHwnd -ne [IntPtr]::Zero -and [CwnWin32]::IsChromeTopLevelWindow($script:ManagedHwnd) -and [CwnWin32]::IsHungAppWindow($script:ManagedHwnd))
      chromeProfile = $script:Profile
      usesOriginalChromeProfile = $true
      chromeProcessId = if ($script:ManagedHwnd -ne [IntPtr]::Zero) { [CwnWin32]::ProcessIdForWindow($script:ManagedHwnd) } else { $null }
      bridgeOnline = [bool]$BridgeState
      bridgeVersion = if ($BridgeState) { [string]$BridgeState.version } else { $null }
      monitoredTabs = if ($BridgeState) { [int]$BridgeState.browser.tabCount } else { 0 }
      lastExtensionHeartbeatAt = if ($BridgeState) { $BridgeState.browser.lastExtensionHeartbeatAt } else { $null }
      recoveryStatus = $script:RecoveryStatus
      settings = $script:Settings
    }
    Write-JsonAtomic $runtimeStateFile $obj 8
  } catch { Log ("Runtime state write failed: " + $_.Exception.Message) }
}

# ---------- Professional white/blue dashboard ----------
$form = New-Object System.Windows.Forms.Form
$form.Text = 'ChatGPT Work Notifier'
$form.Size = New-Object System.Drawing.Size(860, 700)
$form.AutoScroll = $false
$form.StartPosition = 'CenterScreen'
$form.BackColor = [System.Drawing.Color]::FromArgb(246,249,253)
$form.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
$ico = Join-Path $runtimeDir 'notifier.ico'
if (Test-Path $ico) {
  $sourceIcon = New-Object System.Drawing.Icon($ico)
  try { $form.Icon = $sourceIcon.Clone() }
  finally { $sourceIcon.Dispose() }
}

$header = New-Object System.Windows.Forms.Panel
$header.Location = New-Object System.Drawing.Point(0,0)
$header.Size = New-Object System.Drawing.Size(844,90)
$header.BackColor = [System.Drawing.Color]::White
$form.Controls.Add($header)

$headerAccent = New-Object System.Windows.Forms.Panel
$headerAccent.Location = New-Object System.Drawing.Point(0,86)
$headerAccent.Size = New-Object System.Drawing.Size(844,4)
$headerAccent.BackColor = [System.Drawing.Color]::FromArgb(37,99,235)
$header.Controls.Add($headerAccent)

$icon48 = Join-Path $root 'icons\icon48.png'
if (Test-Path $icon48) {
  $logo = New-Object System.Windows.Forms.PictureBox
  $sourceLogo = [System.Drawing.Image]::FromFile($icon48)
  try { $logo.Image = New-Object System.Drawing.Bitmap($sourceLogo) }
  finally { $sourceLogo.Dispose() }
  $logo.SizeMode = 'Zoom'
  $logo.Location = New-Object System.Drawing.Point(24,17)
  $logo.Size = New-Object System.Drawing.Size(52,52)
  $header.Controls.Add($logo)
}

$title = New-Object System.Windows.Forms.Label
$title.Text = 'ChatGPT Work Notifier'
$title.ForeColor = [System.Drawing.Color]::FromArgb(17,35,58)
$title.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 20)
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(88,14)
$header.Controls.Add($title)

$sub = New-Object System.Windows.Forms.Label
$sub.Text = 'Managed Chrome background reliability - v2.4.0'
$sub.ForeColor = [System.Drawing.Color]::FromArgb(78,101,128)
$sub.AutoSize = $true
$sub.Location = New-Object System.Drawing.Point(91,51)
$header.Controls.Add($sub)

$modePill = New-Object System.Windows.Forms.Label
$modePill.Text = 'CHROME ONLY'
$modePill.TextAlign = 'MiddleCenter'
$modePill.ForeColor = [System.Drawing.Color]::FromArgb(37,99,235)
$modePill.BackColor = [System.Drawing.Color]::FromArgb(235,244,255)
$modePill.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 8.5)
$modePill.Location = New-Object System.Drawing.Point(700,25)
$modePill.Size = New-Object System.Drawing.Size(118,30)
$header.Controls.Add($modePill)

function Hide-DashboardUi($Dashboard) {
  if ($Dashboard -and -not $Dashboard.IsDisposed) { $Dashboard.Hide() }
}

$btnHideDashboard = New-Object System.Windows.Forms.Button
$btnHideDashboard.Text = 'Hide UI to tray'
$btnHideDashboard.Location = New-Object System.Drawing.Point(548,24)
$btnHideDashboard.Size = New-Object System.Drawing.Size(132,34)
$btnHideDashboard.FlatStyle = 'Flat'
$btnHideDashboard.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(196,214,235)
$btnHideDashboard.BackColor = [System.Drawing.Color]::White
$btnHideDashboard.ForeColor = [System.Drawing.Color]::FromArgb(31,63,95)
$btnHideDashboard.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9)
$btnHideDashboard.Add_Click({
  Hide-DashboardUi $form
  Log 'Dashboard hidden to tray from the header button.'
})
$header.Controls.Add($btnHideDashboard)

function New-DashboardTabShell($Form) {
  $tabs = New-Object System.Windows.Forms.TabControl
  $tabs.Location = New-Object System.Drawing.Point(12,102)
  $tabs.Size = New-Object System.Drawing.Size(824,548)
  $tabs.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9.5)
  $Form.Controls.Add($tabs)

  $tasks = New-Object System.Windows.Forms.TabPage
  $tasks.Text = 'Tasks'
  $tasks.BackColor = [System.Drawing.Color]::FromArgb(246,249,253)
  $tasks.AutoScroll = $true
  $tabs.TabPages.Add($tasks)

  $controls = New-Object System.Windows.Forms.TabPage
  $controls.Text = 'Controls'
  $controls.BackColor = [System.Drawing.Color]::FromArgb(246,249,253)
  $controls.AutoScroll = $true
  $tabs.TabPages.Add($controls)

  $reliability = New-Object System.Windows.Forms.TabPage
  $reliability.Text = 'Reliability'
  $reliability.BackColor = [System.Drawing.Color]::FromArgb(246,249,253)
  $reliability.AutoScroll = $true
  $tabs.TabPages.Add($reliability)
  $tabs.SelectedIndex = 0
  return [pscustomobject]@{ Tabs = $tabs; Tasks = $tasks; Controls = $controls; Reliability = $reliability }
}

$dashboardShell = New-DashboardTabShell $form
$dashboardTabs = $dashboardShell.Tabs
$overviewPage = $dashboardShell.Tasks
$controlsPage = $dashboardShell.Controls
$reliabilityPage = $dashboardShell.Reliability

$currentSectionTitle = New-Object System.Windows.Forms.Label
$currentSectionTitle.Text = 'CURRENT CHATGPT TASK'
$currentSectionTitle.ForeColor = [System.Drawing.Color]::FromArgb(42,66,94)
$currentSectionTitle.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 11)
$currentSectionTitle.Location = New-Object System.Drawing.Point(12,14)
$currentSectionTitle.Size = New-Object System.Drawing.Size(300,24)
$overviewPage.Controls.Add($currentSectionTitle)

$currentTaskPanel = New-Object System.Windows.Forms.Panel
$currentTaskPanel.Location = New-Object System.Drawing.Point(12,40)
$currentTaskPanel.Size = New-Object System.Drawing.Size(778,142)
$currentTaskPanel.BackColor = [System.Drawing.Color]::White
$currentTaskPanel.BorderStyle = 'FixedSingle'
$overviewPage.Controls.Add($currentTaskPanel)

$currentTaskTitle = New-Object System.Windows.Forms.Label
$currentTaskTitle.Text = 'No active ChatGPT task'
$currentTaskTitle.ForeColor = [System.Drawing.Color]::FromArgb(23,46,72)
$currentTaskTitle.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 12)
$currentTaskTitle.Location = New-Object System.Drawing.Point(18,12)
$currentTaskTitle.Size = New-Object System.Drawing.Size(560,25)
$currentTaskPanel.Controls.Add($currentTaskTitle)

$currentTaskState = New-Object System.Windows.Forms.Label
$currentTaskState.Text = 'NO ACTIVE TASK'
$currentTaskState.TextAlign = 'MiddleCenter'
$currentTaskState.ForeColor = [System.Drawing.Color]::FromArgb(82,105,131)
$currentTaskState.BackColor = [System.Drawing.Color]::FromArgb(241,245,249)
$currentTaskState.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9)
$currentTaskState.Location = New-Object System.Drawing.Point(18,48)
$currentTaskState.Size = New-Object System.Drawing.Size(180,30)
$currentTaskPanel.Controls.Add($currentTaskState)

$currentTaskProgress = New-Object System.Windows.Forms.Label
$currentTaskProgress.Text = 'N/A'
$currentTaskProgress.TextAlign = 'MiddleRight'
$currentTaskProgress.ForeColor = [System.Drawing.Color]::FromArgb(29,78,216)
$currentTaskProgress.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 19)
$currentTaskProgress.Location = New-Object System.Drawing.Point(600,8)
$currentTaskProgress.Size = New-Object System.Drawing.Size(150,36)
$currentTaskPanel.Controls.Add($currentTaskProgress)

$currentProgressTrack = New-Object System.Windows.Forms.Panel
$currentProgressTrack.Location = New-Object System.Drawing.Point(190,52)
$currentProgressTrack.Size = New-Object System.Drawing.Size(560,14)
$currentProgressTrack.BackColor = [System.Drawing.Color]::FromArgb(219,234,254)
$currentTaskPanel.Controls.Add($currentProgressTrack)

$currentProgressFill = New-Object System.Windows.Forms.Panel
$currentProgressFill.Location = New-Object System.Drawing.Point(0,0)
$currentProgressFill.Size = New-Object System.Drawing.Size(0,14)
$currentProgressFill.BackColor = [System.Drawing.Color]::FromArgb(37,99,235)
$currentProgressTrack.Controls.Add($currentProgressFill)

$currentTaskFreshness = New-Object System.Windows.Forms.Label
$currentTaskFreshness.Text = 'Open a managed ChatGPT tab to begin monitoring.'
$currentTaskFreshness.ForeColor = [System.Drawing.Color]::FromArgb(101,121,145)
$currentTaskFreshness.Location = New-Object System.Drawing.Point(190,78)
$currentTaskFreshness.Size = New-Object System.Drawing.Size(560,24)
$currentTaskPanel.Controls.Add($currentTaskFreshness)

$currentTaskNote = New-Object System.Windows.Forms.Label
$currentTaskNote.Text = 'No progress is currently reported.'
$currentTaskNote.ForeColor = [System.Drawing.Color]::FromArgb(71,85,105)
$currentTaskNote.Location = New-Object System.Drawing.Point(18,108)
$currentTaskNote.Size = New-Object System.Drawing.Size(732,22)
$currentTaskPanel.Controls.Add($currentTaskNote)

$allTabsSectionTitle = New-Object System.Windows.Forms.Label
$allTabsSectionTitle.Text = 'ALL MANAGED CHATGPT TABS'
$allTabsSectionTitle.ForeColor = [System.Drawing.Color]::FromArgb(42,66,94)
$allTabsSectionTitle.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 11)
$allTabsSectionTitle.Location = New-Object System.Drawing.Point(12,198)
$allTabsSectionTitle.Size = New-Object System.Drawing.Size(360,24)
$overviewPage.Controls.Add($allTabsSectionTitle)

$allTabsPanel = New-Object System.Windows.Forms.Panel
$allTabsPanel.Location = New-Object System.Drawing.Point(12,224)
$allTabsPanel.Size = New-Object System.Drawing.Size(778,190)
$allTabsPanel.BackColor = [System.Drawing.Color]::White
$allTabsPanel.BorderStyle = 'FixedSingle'
$overviewPage.Controls.Add($allTabsPanel)

$allTabsHeader = New-Object System.Windows.Forms.Label
$allTabsHeader.Text = 'TAB TITLE                         STATE             PROGRESS                         UPDATED'
$allTabsHeader.ForeColor = [System.Drawing.Color]::FromArgb(100,116,139)
$allTabsHeader.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 8)
$allTabsHeader.Location = New-Object System.Drawing.Point(12,8)
$allTabsHeader.Size = New-Object System.Drawing.Size(742,20)
$allTabsPanel.Controls.Add($allTabsHeader)

$allTabsHost = New-Object System.Windows.Forms.Panel
$allTabsHost.Location = New-Object System.Drawing.Point(10,32)
$allTabsHost.Size = New-Object System.Drawing.Size(754,145)
$allTabsHost.BackColor = [System.Drawing.Color]::White
$allTabsHost.AutoScroll = $true
$allTabsPanel.Controls.Add($allTabsHost)

$allTabsEmpty = New-Object System.Windows.Forms.Label
$allTabsEmpty.Text = 'No managed ChatGPT tabs are currently reporting state.'
$allTabsEmpty.ForeColor = [System.Drawing.Color]::FromArgb(100,116,139)
$allTabsEmpty.Location = New-Object System.Drawing.Point(10,12)
$allTabsEmpty.Size = New-Object System.Drawing.Size(700,24)
$allTabsHost.Controls.Add($allTabsEmpty)

$script:TabProgressRows = @{}

$sectionTitle = New-Object System.Windows.Forms.Label
$sectionTitle.Text = 'BACKGROUND RELIABILITY'
$sectionTitle.ForeColor = [System.Drawing.Color]::FromArgb(42,66,94)
$sectionTitle.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 11)
$sectionTitle.Location = New-Object System.Drawing.Point(12,18)
$sectionTitle.Size = New-Object System.Drawing.Size(280,24)
$reliabilityPage.Controls.Add($sectionTitle)

$reliabilityPanel = New-Object System.Windows.Forms.Panel
$reliabilityPanel.Location = New-Object System.Drawing.Point(12,48)
$reliabilityPanel.Size = New-Object System.Drawing.Size(778,330)
$reliabilityPanel.BackColor = [System.Drawing.Color]::White
$reliabilityPanel.BorderStyle = 'FixedSingle'
$reliabilityPage.Controls.Add($reliabilityPanel)

$script:Rows = @{}
function New-ReliabilityRow([string]$Key, [string]$Name, [int]$Column, [int]$Row) {
  $x = if ($Column -eq 0) { 14 } else { 390 }
  $y = 14 + ($Row * 50)
  $nameLabel = New-Object System.Windows.Forms.Label
  $nameLabel.Text = $Name
  $nameLabel.ForeColor = [System.Drawing.Color]::FromArgb(42,62,87)
  $nameLabel.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9.5)
  $nameLabel.Location = New-Object System.Drawing.Point($x,$y)
  $nameLabel.Size = New-Object System.Drawing.Size(195,20)
  $reliabilityPanel.Controls.Add($nameLabel)

  $status = New-Object System.Windows.Forms.Label
  $status.Text = 'Unavailable'
  $status.TextAlign = 'MiddleCenter'
  $status.ForeColor = [System.Drawing.Color]::FromArgb(82,105,131)
  $status.BackColor = [System.Drawing.Color]::FromArgb(241,245,249)
  $status.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 8.5)
  $status.Location = New-Object System.Drawing.Point(($x + 205),($y - 2))
  $status.Size = New-Object System.Drawing.Size(100,24)
  $reliabilityPanel.Controls.Add($status)

  $detail = New-Object System.Windows.Forms.Label
  $detail.Text = 'Checking...'
  $detail.ForeColor = [System.Drawing.Color]::FromArgb(101,121,145)
  $detail.Location = New-Object System.Drawing.Point($x,($y + 21))
  $detail.Size = New-Object System.Drawing.Size(360,24)
  $reliabilityPanel.Controls.Add($detail)
  $script:Rows[$Key] = [pscustomobject]@{ Status = $status; Detail = $detail }
}

function Set-ReliabilityRow([string]$Key, [string]$Status, [string]$Detail) {
  $row = $script:Rows[$Key]
  if (-not $row) { return }
  $row.Status.Text = $Status
  $row.Detail.Text = $Detail
  switch ($Status) {
    'Protected' { $row.Status.ForeColor = [System.Drawing.Color]::FromArgb(29,78,216); $row.Status.BackColor = [System.Drawing.Color]::FromArgb(239,246,255) }
    'Running' { $row.Status.ForeColor = [System.Drawing.Color]::FromArgb(29,78,216); $row.Status.BackColor = [System.Drawing.Color]::FromArgb(239,246,255) }
    'Connected' { $row.Status.ForeColor = [System.Drawing.Color]::FromArgb(29,78,216); $row.Status.BackColor = [System.Drawing.Color]::FromArgb(239,246,255) }
    'Recovering' { $row.Status.ForeColor = [System.Drawing.Color]::FromArgb(180,83,9); $row.Status.BackColor = [System.Drawing.Color]::FromArgb(255,247,237) }
    'Needs attention' { $row.Status.ForeColor = [System.Drawing.Color]::FromArgb(180,83,9); $row.Status.BackColor = [System.Drawing.Color]::FromArgb(255,247,237) }
    default { $row.Status.ForeColor = [System.Drawing.Color]::FromArgb(82,105,131); $row.Status.BackColor = [System.Drawing.Color]::FromArgb(241,245,249) }
  }
}

New-ReliabilityRow 'awake' 'Windows awake protection' 0 0
New-ReliabilityRow 'timers' 'Original Chrome profile' 0 1
New-ReliabilityRow 'renderer' 'Managed-window isolation' 0 2
New-ReliabilityRow 'occluded' 'Background tab monitoring' 0 3
New-ReliabilityRow 'memory' 'Memory Saver tab protection' 0 4
New-ReliabilityRow 'energy' 'Windows power source' 0 5
New-ReliabilityRow 'heartbeat' 'Extension heartbeat' 1 0
New-ReliabilityRow 'bridge' 'Browser bridge' 1 1
New-ReliabilityRow 'chrome' 'Managed Chrome' 1 2
New-ReliabilityRow 'tabs' 'Monitored ChatGPT tabs' 1 3
New-ReliabilityRow 'event' 'Last monitoring event' 1 4
New-ReliabilityRow 'recovery' 'Recovery status' 1 5

$settingsPanel = New-Object System.Windows.Forms.Panel
$settingsPanel.Location = New-Object System.Drawing.Point(12,20)
$settingsPanel.Size = New-Object System.Drawing.Size(460,250)
$settingsPanel.BackColor = [System.Drawing.Color]::White
$settingsPanel.BorderStyle = 'FixedSingle'
$controlsPage.Controls.Add($settingsPanel)

$settingsTitle = New-Object System.Windows.Forms.Label
$settingsTitle.Text = 'Settings'
$settingsTitle.ForeColor = [System.Drawing.Color]::FromArgb(23,46,72)
$settingsTitle.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 11)
$settingsTitle.Location = New-Object System.Drawing.Point(16,14)
$settingsTitle.Size = New-Object System.Drawing.Size(160,24)
$settingsPanel.Controls.Add($settingsTitle)

function New-SettingCheckbox([string]$Text, [string]$Key, [int]$Y) {
  $c = New-Object System.Windows.Forms.CheckBox
  $c.Text = $Text
  $c.Checked = [bool]$script:Settings[$Key]
  $c.ForeColor = [System.Drawing.Color]::FromArgb(49,70,96)
  $c.Location = New-Object System.Drawing.Point(18,$Y)
  $c.Size = New-Object System.Drawing.Size(420,25)
  $settingsPanel.Controls.Add($c)
  $c.Add_CheckedChanged({
    $script:Settings[$Key] = [bool]$this.Checked
    Save-Settings
    Update-AwakeProtection
  }.GetNewClosure())
  return $c
}

$chkAwake = New-SettingCheckbox 'Keep computer awake while monitoring' 'keepComputerAwake' 47
$chkDisplay = New-SettingCheckbox 'Keep display awake' 'keepDisplayAwake' 78
$chkRecover = New-SettingCheckbox 'Automatically recover managed Chrome' 'autoRecoverChrome' 109
$chkRepair = New-SettingCheckbox 'Automatically repair extension connection' 'autoRepairConnection' 140
$chkStale = New-SettingCheckbox 'Allow controlled stale-page recovery' 'allowControlledStaleRecovery' 171
$chkDiag = New-SettingCheckbox 'Background reliability diagnostics' 'backgroundReliabilityDiagnostics' 202

$actionsPanel = New-Object System.Windows.Forms.Panel
$actionsPanel.Location = New-Object System.Drawing.Point(486,20)
$actionsPanel.Size = New-Object System.Drawing.Size(304,250)
$actionsPanel.BackColor = [System.Drawing.Color]::White
$actionsPanel.BorderStyle = 'FixedSingle'
$controlsPage.Controls.Add($actionsPanel)

$actionsTitle = New-Object System.Windows.Forms.Label
$actionsTitle.Text = 'Quick actions'
$actionsTitle.ForeColor = [System.Drawing.Color]::FromArgb(23,46,72)
$actionsTitle.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 11)
$actionsTitle.Location = New-Object System.Drawing.Point(16,14)
$actionsTitle.Size = New-Object System.Drawing.Size(160,24)
$actionsPanel.Controls.Add($actionsTitle)

function Style-Button($Button, [bool]$Primary) {
  $Button.FlatStyle = 'Flat'
  if ($Primary) {
    $Button.FlatAppearance.BorderSize = 0
    $Button.BackColor = [System.Drawing.Color]::FromArgb(37,99,235)
    $Button.ForeColor = [System.Drawing.Color]::White
    $Button.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9.2)
  } else {
    $Button.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(196,214,235)
    $Button.BackColor = [System.Drawing.Color]::White
    $Button.ForeColor = [System.Drawing.Color]::FromArgb(31,63,95)
  }
}

function New-ActionButton([string]$Text, [int]$X, [int]$Y, [bool]$Primary) {
  $b = New-Object System.Windows.Forms.Button
  $b.Text = $Text
  $b.Location = New-Object System.Drawing.Point($X,$Y)
  $b.Size = New-Object System.Drawing.Size(128,42)
  Style-Button $b $Primary
  $actionsPanel.Controls.Add($b)
  return $b
}

function Move-ChromeButtonsToTasks($TasksPage, $ShowButton, $HideButton, $HideUiButton) {
  $TasksPage.Controls.Add($ShowButton)
  $TasksPage.Controls.Add($HideButton)
  $TasksPage.Controls.Add($HideUiButton)
  $ShowButton.Location = New-Object System.Drawing.Point(13,462)
  $HideButton.Location = New-Object System.Drawing.Point(155,462)
  $HideUiButton.Location = New-Object System.Drawing.Point(297,462)
  $HideUiButton.Size = New-Object System.Drawing.Size(128,42)
}

$btnShow = New-ActionButton 'Show Chrome' 16 48 $true
$btnHide = New-ActionButton 'Hide Chrome' 160 48 $false
$btnRepair = New-ActionButton 'Repair connection' 16 48 $false
$btnRestart = New-ActionButton 'Restart Chrome' 160 48 $false
$btnDiagnostics = New-ActionButton 'Run diagnostics' 16 100 $false
$btnExtension = New-ActionButton 'Extension setup' 160 100 $false
Move-ChromeButtonsToTasks $overviewPage $btnShow $btnHide $btnHideDashboard

$lid = New-Object System.Windows.Forms.Label
$lid.Text = 'Lid-close protection: Windows may suspend the laptop if the lid is closed. This program does not change the lid policy.'
$lid.ForeColor = [System.Drawing.Color]::FromArgb(101,121,145)
$lid.Location = New-Object System.Drawing.Point(16,154)
$lid.Size = New-Object System.Drawing.Size(272,38)
$actionsPanel.Controls.Add($lid)

$footer = New-Object System.Windows.Forms.Label
$footer.Text = 'Private loopback: 127.0.0.1:38765  |  your original Chrome profile  |  managed window only'
$footer.ForeColor = [System.Drawing.Color]::FromArgb(93,116,141)
$footer.Location = New-Object System.Drawing.Point(13,430)
$footer.Size = New-Object System.Drawing.Size(740,22)
$overviewPage.Controls.Add($footer)

function Show-DiagnosticsWindow {
  $diagScript = Join-Path $runtimeDir 'diagnostics.ps1'
  if (-not (Test-Path $diagScript)) { [System.Windows.Forms.MessageBox]::Show('Diagnostics script is missing.','ChatGPT Work Notifier') | Out-Null; return }
  $output = ''
  try {
    $psExe = Get-WindowsPowerShellPath
    if (-not $psExe) { throw 'Windows PowerShell executable not found.' }
    $output = & $psExe -NoProfile -ExecutionPolicy Bypass -File $diagScript -Text 2>&1 | Out-String
  } catch { $output = "FAIL - diagnostics could not run.`r`n$($_.Exception.Message)" }
  $d = New-Object System.Windows.Forms.Form
  $d.Text = 'Background Reliability Diagnostics'
  $d.Size = New-Object System.Drawing.Size(720,560)
  $d.StartPosition = 'CenterParent'
  $d.BackColor = [System.Drawing.Color]::White
  if (Test-Path $ico) { $d.Icon = New-Object System.Drawing.Icon($ico) }
  $tb = New-Object System.Windows.Forms.TextBox
  $tb.Multiline = $true
  $tb.ReadOnly = $true
  $tb.ScrollBars = 'Vertical'
  $tb.BorderStyle = 'None'
  $tb.BackColor = [System.Drawing.Color]::White
  $tb.ForeColor = [System.Drawing.Color]::FromArgb(25,48,76)
  $tb.Font = New-Object System.Drawing.Font('Consolas', 10)
  $tb.Location = New-Object System.Drawing.Point(18,18)
  $tb.Size = New-Object System.Drawing.Size(666,480)
  $tb.Text = $output.Trim()
  $d.Controls.Add($tb)
  $d.ShowDialog($form) | Out-Null
  $d.Dispose()
}

# ---------- Tray controls ----------
$tray = New-Object System.Windows.Forms.NotifyIcon
if (Test-Path $ico) { $tray.Icon = New-Object System.Drawing.Icon($ico) } else { $tray.Icon = [System.Drawing.SystemIcons]::Information }
$tray.Text = 'ChatGPT Work Notifier'
$tray.Visible = $true
$menu = New-Object System.Windows.Forms.ContextMenuStrip
$miCurrent = $menu.Items.Add('Current: No active task')
$miCurrent.Enabled = $false
[void]$menu.Items.Add('-')
$miOpen = $menu.Items.Add('Open Dashboard')
$miShow = $menu.Items.Add('Show Managed Chrome')
$miHide = $menu.Items.Add('Hide Managed Chrome')
[void]$menu.Items.Add('-')
$miPause = $menu.Items.Add('Pause Monitoring')
$miResume = $menu.Items.Add('Resume Monitoring')
$miAwake = $menu.Items.Add('Keep Computer Awake')
$miAwake.CheckOnClick = $true
$miAwake.Checked = [bool]$script:Settings.keepComputerAwake
[void]$menu.Items.Add('-')
$miRestart = $menu.Items.Add('Restart Managed Chrome')
$miRepair = $menu.Items.Add('Repair Connection')
$miDiagnostics = $menu.Items.Add('Run Diagnostics')
[void]$menu.Items.Add('-')
$miExit = $menu.Items.Add('Exit')
$tray.ContextMenuStrip = $menu

function Set-TrayTooltip([string]$Text) {
  if (-not $Text) { $Text = 'ChatGPT Work Notifier' }
  if ($Text.Length -gt 63) { $Text = $Text.Substring(0,63) }
  $tray.Text = $Text
}

function Get-TaskNumericProgress($Task) {
  if (-not $Task -or $null -eq $Task.progress) { return $null }
  $numericTypes = @(
    [System.TypeCode]::Byte, [System.TypeCode]::SByte, [System.TypeCode]::Int16, [System.TypeCode]::UInt16,
    [System.TypeCode]::Int32, [System.TypeCode]::UInt32, [System.TypeCode]::Int64, [System.TypeCode]::UInt64,
    [System.TypeCode]::Single, [System.TypeCode]::Double, [System.TypeCode]::Decimal
  )
  if ($numericTypes -notcontains [System.Type]::GetTypeCode($Task.progress.GetType())) { return $null }
  [double]$value = $Task.progress
  if ([double]::IsNaN($value) -or [double]::IsInfinity($value) -or $value -lt 0 -or $value -gt 100) { return $null }
  return $value
}

function Update-CurrentTaskPresentation($BridgeState) {
  $task = Select-CurrentTask $BridgeState
  if (-not $task) {
    $currentTaskTitle.Text = 'No active ChatGPT task'
    $currentTaskState.Text = 'NO ACTIVE TASK'
    $currentTaskState.ForeColor = [System.Drawing.Color]::FromArgb(82,105,131)
    $currentTaskState.BackColor = [System.Drawing.Color]::FromArgb(241,245,249)
    $currentTaskProgress.Text = 'N/A'
    $currentProgressFill.Width = 0
    $currentTaskFreshness.Text = 'Open a managed ChatGPT tab to begin monitoring.'
    $currentTaskNote.Text = 'No progress is currently reported.'
    $miCurrent.Text = 'Current: No active task'
    Set-TrayTooltip 'ChatGPT Work Notifier | No active task'
    return
  }

  $status = [string]$task.status
  $claimedStatus = $status
  $safeComplete = ($status -eq 'COMPLETE' -and [bool]$task.safeCompletion)
  if ($status -eq 'COMPLETE' -and -not $safeComplete) { $status = 'UNCERTAIN' }
  $progress = Get-TaskNumericProgress $task
  if ($claimedStatus -eq 'COMPLETE' -and -not $safeComplete) { $progress = $null }
  if ($safeComplete) { $progress = 100.0 }
  $taskTitle = [string]$task.title
  if (-not $taskTitle) { $taskTitle = "ChatGPT tab $($task.tabId)" }
  $currentTaskTitle.Text = $taskTitle
  $currentTaskState.Text = $status

  if ($status -in @('TIMEOUT','PAUSED','STUCK_THINKING','UNCERTAIN','WAITING_INPUT','PAGE_STALE','FAILED','CONNECTION_LOST','RECOVERY_FAILED')) {
    $currentTaskState.ForeColor = [System.Drawing.Color]::FromArgb(180,83,9)
    $currentTaskState.BackColor = [System.Drawing.Color]::FromArgb(255,247,237)
  } else {
    $currentTaskState.ForeColor = [System.Drawing.Color]::FromArgb(29,78,216)
    $currentTaskState.BackColor = [System.Drawing.Color]::FromArgb(239,246,255)
  }

  if ($null -ne $progress) {
    $rounded = [math]::Round($progress, 1)
    $displayProgress = if ($rounded -eq [math]::Truncate($rounded)) { [string][int]$rounded } else { [string]$rounded }
    $estimateSuffix = if ($task.progressEstimated -eq $true -and -not $safeComplete) { ' est.' } else { '' }
    $currentTaskProgress.Text = "$displayProgress%$estimateSuffix"
    $currentProgressFill.Width = [int][math]::Round($currentProgressTrack.Width * $progress / 100.0)
    $currentProgressFill.BackColor = [System.Drawing.Color]::FromArgb(37,99,235)
    $currentTaskNote.Text = if ($status -eq 'COMPLETE') { 'Safe completion proof verified.' } elseif ($task.progressEstimated -eq $true) { 'Estimated progress.' } else { 'Current reported task progress.' }
    $miCurrent.Text = "Current: $displayProgress%$estimateSuffix | $status"
    Set-TrayTooltip "CWN | $displayProgress%$estimateSuffix | $status | $taskTitle"
  } else {
    $currentTaskProgress.Text = if ($status -eq 'RUNNING') { '% unavailable' } else { 'N/A' }
    $currentProgressFill.Width = if ($status -eq 'RUNNING') { 180 } else { 0 }
    $currentProgressFill.BackColor = [System.Drawing.Color]::FromArgb(147,197,253)
    $currentTaskNote.Text = if ($status -eq 'RUNNING') { 'Working - percentage not reported' } else { 'No percentage reported for this state.' }
    $miCurrent.Text = if ($status -eq 'RUNNING') { 'Current: RUNNING | % unavailable' } else { "Current: $status | % unavailable" }
    Set-TrayTooltip "CWN | $status | % unavailable | $taskTitle"
  }

  $updatedAt = if ($task.updatedAt) { [long]$task.updatedAt } elseif ($task.lastHeartbeat) { [long]$task.lastHeartbeat } else { 0 }
  if ($updatedAt -gt 0) {
    $ageSeconds = [math]::Max(0, [math]::Round(((Get-NowMs) - $updatedAt) / 1000.0, 0))
    $currentTaskFreshness.Text = if ($ageSeconds -lt 2) { 'Updated just now.' } else { "Updated ${ageSeconds}s ago." }
  } else { $currentTaskFreshness.Text = 'Update time unavailable.' }
}

function New-TabProgressRow([int]$TabId) {
  $rowPanel = New-Object System.Windows.Forms.Panel
  $rowPanel.Size = New-Object System.Drawing.Size(742,44)
  $rowPanel.BackColor = [System.Drawing.Color]::FromArgb(248,250,252)

  $titleLabel = New-Object System.Windows.Forms.Label
  $titleLabel.Text = "ChatGPT tab $TabId"
  $titleLabel.ForeColor = [System.Drawing.Color]::FromArgb(30,41,59)
  $titleLabel.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9)
  $titleLabel.Location = New-Object System.Drawing.Point(8,11)
  $titleLabel.Size = New-Object System.Drawing.Size(210,22)
  $titleLabel.AutoEllipsis = $true
  $rowPanel.Controls.Add($titleLabel)

  $stateLabel = New-Object System.Windows.Forms.Label
  $stateLabel.Text = 'IDLE'
  $stateLabel.TextAlign = 'MiddleCenter'
  $stateLabel.ForeColor = [System.Drawing.Color]::FromArgb(82,105,131)
  $stateLabel.BackColor = [System.Drawing.Color]::FromArgb(241,245,249)
  $stateLabel.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 8)
  $stateLabel.Location = New-Object System.Drawing.Point(222,9)
  $stateLabel.Size = New-Object System.Drawing.Size(100,26)
  $rowPanel.Controls.Add($stateLabel)

  $progressLabel = New-Object System.Windows.Forms.Label
  $progressLabel.Text = 'N/A'
  $progressLabel.TextAlign = 'MiddleRight'
  $progressLabel.ForeColor = [System.Drawing.Color]::FromArgb(29,78,216)
  $progressLabel.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 10)
  $progressLabel.Location = New-Object System.Drawing.Point(328,9)
  $progressLabel.Size = New-Object System.Drawing.Size(80,26)
  $rowPanel.Controls.Add($progressLabel)

  $trackPanel = New-Object System.Windows.Forms.Panel
  $trackPanel.Location = New-Object System.Drawing.Point(416,16)
  $trackPanel.Size = New-Object System.Drawing.Size(190,12)
  $trackPanel.BackColor = [System.Drawing.Color]::FromArgb(219,234,254)
  $rowPanel.Controls.Add($trackPanel)

  $fillPanel = New-Object System.Windows.Forms.Panel
  $fillPanel.Location = New-Object System.Drawing.Point(0,0)
  $fillPanel.Size = New-Object System.Drawing.Size(0,12)
  $fillPanel.BackColor = [System.Drawing.Color]::FromArgb(37,99,235)
  $trackPanel.Controls.Add($fillPanel)

  $freshnessLabel = New-Object System.Windows.Forms.Label
  $freshnessLabel.Text = 'Update unavailable'
  $freshnessLabel.TextAlign = 'MiddleRight'
  $freshnessLabel.ForeColor = [System.Drawing.Color]::FromArgb(100,116,139)
  $freshnessLabel.Location = New-Object System.Drawing.Point(614,11)
  $freshnessLabel.Size = New-Object System.Drawing.Size(116,22)
  $rowPanel.Controls.Add($freshnessLabel)

  $allTabsHost.Controls.Add($rowPanel)
  return [pscustomobject]@{
    Panel = $rowPanel
    Title = $titleLabel
    State = $stateLabel
    Progress = $progressLabel
    Track = $trackPanel
    Fill = $fillPanel
    Freshness = $freshnessLabel
  }
}

function Update-AllTabProgressPresentation($BridgeState) {
  $tabs = @()
  if ($BridgeState -and $BridgeState.browser) {
    $tabs = @($BridgeState.browser.tabs | Where-Object {
      $_ -and ([string]$_.monitoringState -notin @('DETACHED','CLOSED','PRUNED')) -and ([string]$_.lastLifecycle -notin @('NAVIGATED_AWAY','CLOSED','PRUNED'))
    } | Sort-Object @{ Expression = { if ($null -ne $_.tabId) { [long]$_.tabId } else { [long]::MaxValue } } })
  }

  $wanted = @{}
  $rowIndex = 0
  foreach ($tab in $tabs) {
    $key = [string]$tab.tabId
    $wanted[$key] = $true
    if (-not $script:TabProgressRows.ContainsKey($key)) { $script:TabProgressRows[$key] = New-TabProgressRow ([int]$tab.tabId) }
    $row = $script:TabProgressRows[$key]
    $row.Panel.Location = New-Object System.Drawing.Point(0,($rowIndex * 48))
    $row.Panel.BackColor = if (($rowIndex % 2) -eq 0) { [System.Drawing.Color]::FromArgb(248,250,252) } else { [System.Drawing.Color]::White }

    $title = [string]$tab.title
    if (-not $title) { $title = "ChatGPT tab $($tab.tabId)" }
    $row.Title.Text = $title
    $claimedStatus = [string]$tab.status
    if (-not $claimedStatus) { $claimedStatus = 'IDLE' }
    $safeComplete = ($claimedStatus -eq 'COMPLETE' -and [bool]$tab.safeCompletion)
    $status = if ($claimedStatus -eq 'COMPLETE' -and -not $safeComplete) { 'UNCERTAIN' } else { $claimedStatus }
    $progress = Get-TaskNumericProgress $tab
    if ($claimedStatus -eq 'COMPLETE' -and -not $safeComplete) { $progress = $null }
    if ($safeComplete) { $progress = 100.0 }
    $row.State.Text = $status

    if ($status -in @('TIMEOUT','PAUSED','STUCK_THINKING','UNCERTAIN','WAITING_INPUT','PAGE_STALE','FAILED','CONNECTION_LOST','RECOVERY_FAILED')) {
      $row.State.ForeColor = [System.Drawing.Color]::FromArgb(180,83,9)
      $row.State.BackColor = [System.Drawing.Color]::FromArgb(255,247,237)
    } else {
      $row.State.ForeColor = [System.Drawing.Color]::FromArgb(29,78,216)
      $row.State.BackColor = [System.Drawing.Color]::FromArgb(239,246,255)
    }

    if ($null -ne $progress) {
      $rounded = [math]::Round($progress, 1)
      $displayProgress = if ($rounded -eq [math]::Truncate($rounded)) { [string][int]$rounded } else { [string]$rounded }
      $estimateSuffix = if ($tab.progressEstimated -eq $true -and -not $safeComplete) { ' est.' } else { '' }
      $row.Progress.Text = "$displayProgress%$estimateSuffix"
      $row.Fill.Width = [int][math]::Round($row.Track.Width * $progress / 100.0)
      $row.Fill.BackColor = [System.Drawing.Color]::FromArgb(37,99,235)
    } else {
      $row.Progress.Text = if ($status -eq 'RUNNING') { '% unavailable' } else { 'N/A' }
      $row.Fill.Width = if ($status -eq 'RUNNING') { 58 } else { 0 }
      $row.Fill.BackColor = [System.Drawing.Color]::FromArgb(147,197,253)
    }

    $updatedAt = if ($tab.updatedAt) { [long]$tab.updatedAt } elseif ($tab.lastHeartbeat) { [long]$tab.lastHeartbeat } else { 0 }
    if ($updatedAt -gt 0) {
      $ageSeconds = [math]::Max(0, [math]::Round(((Get-NowMs) - $updatedAt) / 1000.0, 0))
      $row.Freshness.Text = if ($ageSeconds -lt 2) { 'just now' } else { "${ageSeconds}s ago" }
    } else { $row.Freshness.Text = 'unavailable' }
    $rowIndex++
  }

  foreach ($key in @($script:TabProgressRows.Keys)) {
    if (-not $wanted.ContainsKey($key)) {
      $row = $script:TabProgressRows[$key]
      $allTabsHost.Controls.Remove($row.Panel)
      $row.Panel.Dispose()
      [void]$script:TabProgressRows.Remove($key)
    }
  }
  $allTabsEmpty.Visible = ($tabs.Count -eq 0)
  if ($allTabsEmpty.Visible) { $allTabsEmpty.BringToFront() }
  $allTabsHost.AutoScrollMinSize = New-Object System.Drawing.Size(0,($tabs.Count * 48))
}

function Update-MonitoringMenu {
  $miPause.Enabled = [bool]$script:Settings.monitoringEnabled
  $miResume.Enabled = -not [bool]$script:Settings.monitoringEnabled
}

function Pause-Monitoring {
  $script:Settings.monitoringEnabled = $false
  Save-Settings
  Update-AwakeProtection
  Update-MonitoringMenu
  Log 'Monitoring paused by user.'
}

function Resume-Monitoring {
  $script:Settings.monitoringEnabled = $true
  Save-Settings
  Update-AwakeProtection
  Update-MonitoringMenu
  Repair-Connection
  Log 'Monitoring resumed by user.'
}

$btnShow.Add_Click({ Show-ManagedChrome })
$btnHide.Add_Click({ Hide-ManagedChrome })
$btnRepair.Add_Click({ Repair-Connection })
$btnRestart.Add_Click({ [void](Restart-ManagedChrome) })
$btnDiagnostics.Add_Click({ Show-DiagnosticsWindow })
$btnExtension.Add_Click({ Open-ExtensionSetup })
$miOpen.Add_Click({ $form.Show(); $form.WindowState = 'Normal'; $form.Activate() })
$miShow.Add_Click({ Show-ManagedChrome })
$miHide.Add_Click({ Hide-ManagedChrome })
$miPause.Add_Click({ Pause-Monitoring })
$miResume.Add_Click({ Resume-Monitoring })
$miAwake.Add_CheckedChanged({ $script:Settings.keepComputerAwake = [bool]$miAwake.Checked; $chkAwake.Checked = $miAwake.Checked; Save-Settings; Update-AwakeProtection })
$miRestart.Add_Click({ [void](Restart-ManagedChrome) })
$miRepair.Add_Click({ Repair-Connection })
$miDiagnostics.Add_Click({ Show-DiagnosticsWindow })
$tray.Add_DoubleClick({ $form.Show(); $form.WindowState = 'Normal'; $form.Activate() })
$form.Add_FormClosing({ param($s,$e) if ($e.CloseReason -eq [System.Windows.Forms.CloseReason]::UserClosing) { $e.Cancel = $true; $form.Hide() } })
$miExit.Add_Click({
  [void][CwnPower]::SetThreadExecutionState(0x80000000)
  $script:AwakeActive = $false
  $tray.Visible = $false
  Close-NotifierPopup
  $form.Dispose()
  [System.Windows.Forms.Application]::ExitThread()
})
Update-MonitoringMenu
Update-CurrentTaskPresentation $null
Update-AllTabProgressPresentation $null

# ---------- Health/recovery loop ----------
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 2000
$timer.Add_Tick({
  $script:DiagnosticTick++
  Update-AwakeProtection

  [void](Refresh-ManagedWindowHandle)
  $alive = ($script:ManagedHwnd -ne [IntPtr]::Zero -and [CwnWin32]::IsChromeTopLevelWindow($script:ManagedHwnd))
  if (-not $alive -and $script:ManagedHwnd -ne [IntPtr]::Zero) { $script:ManagedHwnd = [IntPtr]::Zero; $script:IsHidden = $false }

  if ($alive) {
    if ([CwnWin32]::IsHungAppWindow($script:ManagedHwnd)) { $script:HungMisses++ } else { $script:HungMisses = 0 }
  } else { $script:HungMisses = 0 }

  $s = Get-BridgeState
  $script:LastBridgeState = $s
  Update-CurrentTaskPresentation $s
  Update-AllTabProgressPresentation $s
  if ($s) {
    if ($script:PopupEvent -and (Test-ManualPopupStatus ([string]$script:PopupEvent.status))) {
      $popupTabId = -1
      try { if ($null -ne $script:PopupEvent.tabId) { $popupTabId = [int]$script:PopupEvent.tabId } } catch {}
      if ($popupTabId -ge 0) {
        $popupTab = @($s.browser.tabs) | Where-Object { [int]$_.tabId -eq $popupTabId } | Select-Object -First 1
        if (-not $popupTab -or -not (Test-ManualPopupStatus ([string]$popupTab.status))) {
          Close-NotifierPopup
          Show-NextManualPopup
        }
      }
    }
    if ($script:BridgeWasDown) {
      $script:BridgeWasDown = $false
      $script:RecoveryStatus = 'RECOVERED'
      if ($script:PopupEvent -and [string]$script:PopupEvent.status -eq 'CONNECTION_LOST') { Close-NotifierPopup; Show-NextManualPopup }
      $event = [pscustomobject]@{ status = 'MONITORING_RECOVERED'; title = 'Background reliability'; tabId = -1; progress = $null }
      Show-NotifierPopup $event
    }
    $script:BridgeMisses = 0

    $focusAt = 0
    if ($s.browser.focusRequestedAt) { $focusAt = [long]$s.browser.focusRequestedAt }
    if ($focusAt -gt $script:LastFocusRequestAt) { $script:LastFocusRequestAt = $focusAt; Show-ManagedChrome }

    $queuedPopups = @($s.browser.popupEvents)
    if ($queuedPopups.Count -gt 0) {
      foreach ($queuedPopup in @($queuedPopups | Sort-Object { [long]$_.popupSequence })) {
        $popupSequence = if ($queuedPopup.popupSequence) { [long]$queuedPopup.popupSequence } else { 0 }
        if ($popupSequence -gt $script:LastPopupSequence) {
          $script:LastPopupSequence = $popupSequence
          if ([bool]$queuedPopup.showPopup) { Show-NotifierPopup $queuedPopup; Acknowledge-CompletionEvent $queuedPopup }
        }
      }
      $script:PopupInitialized = $true
    } elseif ($s.browser.lastEvent) {
      $eventAt = if ($s.browser.lastEventAt) { [long]$s.browser.lastEventAt } else { 0 }
      if (-not $script:PopupInitialized) { $script:LastPopupEventAt = $eventAt; $script:PopupInitialized = $true }
      elseif ($eventAt -gt $script:LastPopupEventAt) {
        $script:LastPopupEventAt = $eventAt
        if ([bool]$s.browser.lastEvent.showPopup) { Show-NotifierPopup $s.browser.lastEvent; Acknowledge-CompletionEvent $s.browser.lastEvent }
      }
    } elseif (-not $script:PopupInitialized) { $script:PopupInitialized = $true }

    $lastHb = 0
    if ($s.browser.lastExtensionHeartbeatAt) { $lastHb = [long]$s.browser.lastExtensionHeartbeatAt }
    $hbAge = if ($lastHb -gt 0) { (Get-NowMs) - $lastHb } else { [long]::MaxValue }
    if ([int]$s.browser.tabCount -gt 0 -and $hbAge -gt 60000) {
      if ($script:ExtensionStaleSince -eq 0) { $script:ExtensionStaleSince = Get-NowMs }
      $script:RecoveryStatus = 'DEGRADED'
      if (-not $script:ExtensionStaleAlerted) {
        $script:ExtensionStaleAlerted = $true
        Log 'Extension heartbeat is stale; automatic repair started without interrupting the user.' 'WARN'
      }
      if ([bool]$script:Settings.autoRepairConnection -and ((Get-NowMs) - $script:LastExtensionRepairAt -gt 30000)) {
        $script:LastExtensionRepairAt = Get-NowMs
        [void](Invoke-Bridge '/request-repair' 'POST' @{})
        $script:RecoveryStatus = 'REPAIRING'
      }
      if ([bool]$script:Settings.autoRecoverChrome -and ((Get-NowMs) - $script:ExtensionStaleSince -gt 180000) -and -not (Has-RunningManagedWork $s)) {
        [void](Restart-ManagedChrome -Automatic)
        $script:ExtensionStaleSince = 0
      }
    } else {
      $script:ExtensionStaleSince = 0
      if ($script:ExtensionStaleAlerted) {
        $script:ExtensionStaleAlerted = $false
        $script:ManualPopupQueue = @($script:ManualPopupQueue | Where-Object { [string]$_.status -ne 'PAGE_STALE' })
        if ($script:PopupEvent -and [string]$script:PopupEvent.status -eq 'PAGE_STALE') {
          Close-NotifierPopup
          Show-NextManualPopup
        }
      }
      if ($script:RecoveryStatus -in @('DEGRADED','REPAIRING','RECOVERED')) { $script:RecoveryStatus = 'HEALTHY' }
    }
  } else {
    $script:BridgeMisses++
    if ($script:BridgeMisses -ge 2 -and -not $script:BridgeWasDown) {
      $script:BridgeWasDown = $true
      $script:RecoveryStatus = 'DEGRADED'
      $event = [pscustomobject]@{ status = 'CONNECTION_LOST'; title = 'Browser bridge'; tabId = -1; progress = $null }
      Show-NotifierPopup $event
    }
    if ($script:BridgeMisses -ge 3 -and [bool]$script:Settings.autoRepairConnection) {
      $script:RecoveryStatus = 'REPAIRING'
      Start-BrowserBridge -Force
      $script:BridgeMisses = 0
    }
  }

  if (-not $alive -and $script:HadManagedWindow) {
    $script:ChromeMisses++
    if ($script:ChromeMisses -ge 3 -and [bool]$script:Settings.autoRecoverChrome) {
      if (Has-RunningManagedWork $s) {
        $script:RecoveryStatus = 'DEGRADED'
        Log 'Automatic managed-window recreation suppressed because a managed tab reports RUNNING.'
      } else {
        $script:RecoveryStatus = 'REPAIRING'
        Launch-ManagedChrome
      }
      $script:ChromeMisses = 0
    }
  } else { $script:ChromeMisses = 0 }

  if ($alive -and $script:HungMisses -ge 6 -and [bool]$script:Settings.autoRecoverChrome) {
    if (-not (Has-RunningManagedWork $s)) {
      [void](Restart-ManagedChrome -Automatic)
      $script:HungMisses = 0
    } else { $script:RecoveryStatus = 'DEGRADED' }
  }

  # Dashboard rendering.
  if ($script:Settings.monitoringEnabled -and $script:Settings.keepComputerAwake -and $script:AwakeActive) {
    $display = if ($script:Settings.keepDisplayAwake) { 'display kept awake' } else { 'display may turn off' }
    Set-ReliabilityRow 'awake' 'Protected' "System sleep blocked while monitoring; $display."
  } elseif (-not $script:Settings.monitoringEnabled) {
    Set-ReliabilityRow 'awake' 'Unavailable' 'Monitoring is paused; normal Windows sleep behaviour restored.'
  } else { Set-ReliabilityRow 'awake' 'Needs attention' 'Keep Computer Awake is disabled.' }

  if ($alive) {
    Set-ReliabilityRow 'timers' 'Protected' "Using existing Chrome profile: $($script:Profile)."
    Set-ReliabilityRow 'renderer' 'Protected' 'Only the captured managed Chrome window is monitored and controlled.'
    Set-ReliabilityRow 'occluded' 'Protected' 'Extension heartbeat and per-tab events continue when another tab or app is active.'
  } else {
    Set-ReliabilityRow 'timers' 'Unavailable' 'Managed Chrome is not running.'
    Set-ReliabilityRow 'renderer' 'Unavailable' 'No managed window is currently captured.'
    Set-ReliabilityRow 'occluded' 'Unavailable' 'Background monitoring waits for the managed window.'
  }

  $tabCountForProtection = if ($s) { [int]$s.browser.tabCount } else { 0 }
  $allTabsProtected = ($tabCountForProtection -gt 0)
  $tabRuntimeProblem = $false
  if ($s -and $tabCountForProtection -gt 0) {
    foreach ($tab in @($s.browser.tabs)) {
      if (-not [bool]$tab.autoDiscardableProtected) { $allTabsProtected = $false }
      if ([bool]$tab.discarded -or [bool]$tab.frozen) { $tabRuntimeProblem = $true }
    }
  }
  if ($tabCountForProtection -eq 0) {
    Set-ReliabilityRow 'memory' 'Needs attention' 'Memory Saver protection: ACTION REQUIRED - open a managed ChatGPT tab so protection can be verified.'
  } elseif ($allTabsProtected -and -not $tabRuntimeProblem) {
    Set-ReliabilityRow 'memory' 'Protected' 'Memory Saver protection: ACTIVE - every monitored tab is verified non-discardable by Chrome.'
  } else {
    Set-ReliabilityRow 'memory' 'Needs attention' 'Memory Saver protection: ACTION REQUIRED - open Managed Chrome > Settings > Performance and add chatgpt.com to Always keep these sites active.'
  }

  $powerState = Get-PowerSourceState
  if ($powerState -eq 'AC') {
    Set-ReliabilityRow 'energy' 'Protected' 'Connected to AC power; Windows awake protection is available.'
  } elseif ($powerState -eq 'BATTERY') {
    Set-ReliabilityRow 'energy' 'Running' 'On battery power; monitoring remains active while Windows stays awake.'
  } else {
    Set-ReliabilityRow 'energy' 'Unavailable' 'Windows power-source status is unavailable.'
  }

  if ($s) {
    $hbAgeSec = $null
    if ($s.browser.lastExtensionHeartbeatAt) { $hbAgeSec = [math]::Round(((Get-NowMs) - [long]$s.browser.lastExtensionHeartbeatAt) / 1000.0, 0) }
    if ([int]$s.browser.tabCount -eq 0) { Set-ReliabilityRow 'heartbeat' 'Needs attention' 'Open a ChatGPT tab in Managed Chrome to establish monitoring.' }
    elseif ($hbAgeSec -ne $null -and $hbAgeSec -le 60) { Set-ReliabilityRow 'heartbeat' 'Connected' "Last extension heartbeat ${hbAgeSec}s ago." }
    else { Set-ReliabilityRow 'heartbeat' 'Recovering' 'Extension heartbeat is stale; automatic repair is active.' }
    Set-ReliabilityRow 'bridge' 'Connected' 'Private browser bridge is listening on 127.0.0.1:38765.'
  } else {
    Set-ReliabilityRow 'heartbeat' 'Unavailable' 'Extension health cannot be verified while the bridge is offline.'
    Set-ReliabilityRow 'bridge' 'Recovering' 'Local browser bridge is reconnecting.'
  }

  if ($alive) {
    $detail = if ($script:IsHidden) { 'Managed Chrome windows hidden to tray; browser remains running.' } else { 'Managed Chrome is running.' }
    if ($script:HungMisses -gt 0) { Set-ReliabilityRow 'chrome' 'Recovering' 'Chrome appears unresponsive; recovery escalation is active.' }
    else { Set-ReliabilityRow 'chrome' 'Running' $detail }
  } else { Set-ReliabilityRow 'chrome' 'Unavailable' 'Managed Chrome is not running.' }

  if ($s -and [int]$s.browser.tabCount -gt 0) { Set-ReliabilityRow 'tabs' 'Running' ("$($s.browser.tabCount) ChatGPT tab(s) independently tracked.") }
  else { Set-ReliabilityRow 'tabs' 'Needs attention' 'No managed ChatGPT tabs are currently tracked.' }

  if ($s -and $s.browser.lastEvent) {
    $eventDetail = Get-EventMessage $s.browser.lastEvent
    Set-ReliabilityRow 'event' 'Running' $eventDetail
  } else { Set-ReliabilityRow 'event' 'Unavailable' 'No monitoring state transition has been recorded yet.' }

  switch ($script:RecoveryStatus) {
    'HEALTHY' { Set-ReliabilityRow 'recovery' 'Protected' 'Recovery state: HEALTHY.' }
    'RECOVERED' { Set-ReliabilityRow 'recovery' 'Protected' 'Recovery state: RECOVERED.' }
    'REPAIRING' { Set-ReliabilityRow 'recovery' 'Recovering' 'Recovery state: REPAIRING.' }
    default { Set-ReliabilityRow 'recovery' 'Needs attention' 'Recovery state: DEGRADED.' }
  }

  Write-RuntimeState $s
})

Load-ManagedState
if ($script:ManagedToken -notmatch '^[a-f0-9]{32}$') { $script:ManagedToken = [Guid]::NewGuid().ToString('N') }
Start-BrowserBridge
Update-AwakeProtection
$timer.Start()
if (-not $NoAutoLaunch -and $script:ManagedHwnd -eq [IntPtr]::Zero) { Launch-ManagedChrome }
$form.Show()
$form.Activate()
[System.Windows.Forms.Application]::Run()

try {
  $timer.Stop()
  [void][CwnPower]::SetThreadExecutionState(0x80000000)
  $script:AwakeActive = $false
  Close-NotifierPopup
  $tray.Visible = $false
  $tray.Dispose()
  $mutex.ReleaseMutex()
  $mutex.Dispose()
} catch {}
