$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$rootNeedle = $root.ToLowerInvariant()
$rk = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$runtimeBase = Join-Path $env:LOCALAPPDATA 'ChatGPT Work Notifier'
$settingsFile = Join-Path $runtimeBase 'settings.json'

New-Item -ItemType Directory -Path $runtimeBase -Force | Out-Null

# Stop the currently running notifier components before an in-place upgrade so
# the next launch is guaranteed to load this build. Ordinary Chrome is never stopped here.
try {
  Get-CimInstance Win32_Process | Where-Object {
    $_.Name -eq 'powershell.exe' -and $_.CommandLine -and $_.CommandLine.ToLowerInvariant().Contains($rootNeedle) -and (
      $_.CommandLine -like '*tray-host.ps1*' -or
      $_.CommandLine -like '*browser-bridge.ps1*'
    )
  } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
} catch {}

# A previous release may run from a different folder and therefore own the
# product-wide single-instance mutex. Stop it only after its on-disk root is
# positively identified as another ChatGPT Work Notifier release.
function Get-VerifiedNotifierRootFromCommandLine([string]$CommandLine) {
  if (-not $CommandLine -or $CommandLine -notmatch '(?i)-File\s+(?:"([^"]+)"|''([^'']+)''|(\S+))') { return $null }
  $scriptPath = @($matches[1],$matches[2],$matches[3]) | Where-Object { $_ } | Select-Object -First 1
  if (-not $scriptPath) { return $null }
  try { $scriptPath = [System.IO.Path]::GetFullPath($scriptPath) } catch { return $null }
  if ([System.IO.Path]::GetFileName($scriptPath) -notin @('tray-host.ps1','browser-bridge.ps1')) { return $null }
  $candidateRuntime = Split-Path -Parent $scriptPath
  if ([System.IO.Path]::GetFileName($candidateRuntime) -ne 'runtime') { return $null }
  $candidateRoot = Split-Path -Parent $candidateRuntime
  if (-not (Test-Path -LiteralPath (Join-Path $candidateRoot 'manifest.json') -PathType Leaf) -or
      -not (Test-Path -LiteralPath (Join-Path $candidateRoot 'runtime\tray-host.ps1') -PathType Leaf) -or
      -not (Test-Path -LiteralPath (Join-Path $candidateRoot 'runtime\browser-bridge.ps1') -PathType Leaf) -or
      -not (Test-Path -LiteralPath (Join-Path $candidateRoot 'START_CHATGPT_WORK_NOTIFIER.bat') -PathType Leaf)) { return $null }
  try {
    $manifest = Get-Content -LiteralPath (Join-Path $candidateRoot 'manifest.json') -Raw | ConvertFrom-Json
    if ([string]$manifest.name -ne 'ChatGPT Work Notifier' -or [int]$manifest.manifest_version -ne 3) { return $null }
    return [System.IO.Path]::GetFullPath($candidateRoot)
  } catch { return $null }
}

try {
  $currentRootPath = [System.IO.Path]::GetFullPath($root)
  Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'powershell.exe' -and $_.CommandLine } | ForEach-Object {
    $candidateRoot = Get-VerifiedNotifierRootFromCommandLine ([string]$_.CommandLine)
    if ($candidateRoot -and -not $candidateRoot.Equals($currentRootPath, [System.StringComparison]::OrdinalIgnoreCase)) {
      Write-Output "Stopping verified previous notifier release: $candidateRoot"
      Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
    }
  }
  Start-Sleep -Milliseconds 400
} catch {}

# Migration cleanup only. This obsolete startup/process name belongs to a pre-Chrome-only build.
Remove-ItemProperty -Path $rk -Name 'ChatGPTWorkNotifierCompanion' -ErrorAction SilentlyContinue
try {
  Get-CimInstance Win32_Process | Where-Object {
    $_.Name -eq 'powershell.exe' -and $_.CommandLine -like '*chatgpt-app-watcher.ps1*'
  } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
} catch {}

# Safe v2.1 defaults. Preserve existing user choices during upgrades.
if (-not (Test-Path $settingsFile)) {
  $defaults = [ordered]@{
    monitoringEnabled = $true
    keepComputerAwake = $true
    keepDisplayAwake = $false
    autoRecoverChrome = $true
    autoRepairConnection = $true
    allowControlledStaleRecovery = $true
    backgroundReliabilityDiagnostics = $true
  }
  [System.IO.File]::WriteAllText($settingsFile, ($defaults | ConvertTo-Json -Depth 4), [System.Text.UTF8Encoding]::new($false))
}

$launchVbs = Join-Path $root 'runtime\launch-hidden.vbs'
$loggerStartPs1 = Join-Path $root 'ADVANCED_LOGGER\start-advanced-logger.ps1'
$wscript = Join-Path $env:SystemRoot 'System32\wscript.exe'
if (-not (Test-Path -LiteralPath $wscript -PathType Leaf)) { throw 'Windows Script Host executable not found.' }
if (-not (Test-Path -LiteralPath $loggerStartPs1 -PathType Leaf)) { throw 'Advanced logger startup script not found.' }
# Windows logon must enter through the same verified logger bootstrap as the
# root launcher. This guarantees every normal app start gets a live recorder
# session before the hidden notifier is launched; the bootstrap deduplicates
# an already-running recorder safely.
$value = '"{0}" "{1}" "{2}"' -f $wscript,$launchVbs,$loggerStartPs1
New-ItemProperty -Path $rk -Name 'ChatGPTWorkNotifierV2' -Value $value -PropertyType String -Force | Out-Null

Write-Output 'ChatGPT Work Notifier v2.4.0 startup entry installed.'
Write-Output 'The notifier opens one managed window in your original Chrome profile. Other Chrome windows are not modified.'
Write-Output 'If the heartbeat is not connected, load or reload this unpacked extension once in the same original Chrome profile.'
