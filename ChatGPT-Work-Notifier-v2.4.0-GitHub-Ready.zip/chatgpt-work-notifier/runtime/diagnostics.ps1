param([switch]$Text)

$ErrorActionPreference = 'SilentlyContinue'
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$runtimeBase = Join-Path $env:LOCALAPPDATA 'ChatGPT Work Notifier'
$runtimeStateFile = Join-Path $runtimeBase 'runtime-state.json'
$settingsFile = Join-Path $runtimeBase 'settings.json'
$managedStateFile = Join-Path $runtimeBase 'managed-window.json'
$launchConfig = Get-Content -LiteralPath (Join-Path $root 'runtime\chrome-launch.json') -Raw | ConvertFrom-Json
$checks = New-Object System.Collections.ArrayList

function Add-Check([string]$Name, [string]$Status, [string]$Detail) {
  [void]$checks.Add([ordered]@{ name = $Name; status = $Status; detail = $Detail })
}

function Read-JsonSnapshot([string]$Path) {
  for ($attempt = 0; $attempt -lt 10; $attempt++) {
    try {
      if (Test-Path -LiteralPath $Path) {
        return (Get-Content -LiteralPath $Path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop)
      }
    } catch {}
    Start-Sleep -Milliseconds 100
  }
  return $null
}

function Find-Chrome {
  $candidates = @(
    (Join-Path ${env:ProgramFiles} 'Google\Chrome\Application\chrome.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
    (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
  )
  foreach ($c in $candidates) { if ($c -and (Test-Path $c)) { return $c } }
  return $null
}

$runtimeState = Read-JsonSnapshot $runtimeStateFile
$chrome = Find-Chrome
Add-Check 'Chrome detected' $(if($chrome){'PASS'}else{'FAIL'}) $(if($chrome){$chrome}else{'Google Chrome executable was not found.'})

$managedProcess = $null
try {
  if ($runtimeState.chromeProcessId) { $managedProcess = Get-CimInstance Win32_Process -Filter "ProcessId=$([int]$runtimeState.chromeProcessId)" }
} catch {}
Add-Check 'Managed Chrome window process detected' $(if($managedProcess -and $managedProcess.Name -eq 'chrome.exe'){'PASS'}else{'FAIL'}) $(if($managedProcess){"PID $($managedProcess.ProcessId)"}else{'No captured managed Chrome window process detected.'})

if ($managedProcess) {
  $dangerous = @()
  foreach ($switch in @($launchConfig.prohibitedSwitches)) { if ([string]$managedProcess.CommandLine -like "*$switch*") { $dangerous += [string]$switch } }
  $sameProfile = [bool]$runtimeState.usesOriginalChromeProfile -and [string]$managedProcess.CommandLine -notlike '*ChatGPT Work Notifier*ManagedChrome*'
  Add-Check 'Original Chrome profile active' $(if($sameProfile){'PASS'}else{'FAIL'}) $(if($sameProfile){"Using the existing Chrome profile $($runtimeState.chromeProfile)."}else{'Managed window is not using the original Chrome profile.'})
  Add-Check 'Dangerous Chrome switches absent' $(if($dangerous.Count -eq 0){'PASS'}else{'FAIL'}) $(if($dangerous.Count -eq 0){'No prohibited sandbox, web-security, or certificate bypass switch detected.'}else{"Present: $($dangerous -join ', ')"})
} else {
  Add-Check 'Original Chrome profile active' 'FAIL' 'Managed Chrome is not running.'
  Add-Check 'Dangerous Chrome switches absent' 'WARN' 'Cannot inspect command line until Managed Chrome is running.'
}

$bridge = $null
try { $bridge = Invoke-RestMethod 'http://127.0.0.1:38765/state' -TimeoutSec 2 } catch {}
Add-Check 'Browser bridge listening' $(if($bridge){'PASS'}else{'FAIL'}) $(if($bridge){"Version $($bridge.version), mode $($bridge.mode)"}else{'Bridge did not answer on 127.0.0.1:38765.'})

$loopbackOnly = $false
try {
  $listeners = @([System.Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners() | Where-Object { $_.Port -eq 38765 })
  $bad = @($listeners | Where-Object { -not [System.Net.IPAddress]::IsLoopback($_.Address) })
  $loopbackOnly = ($listeners.Count -gt 0 -and $bad.Count -eq 0)
} catch {}
Add-Check 'Browser bridge localhost-only' $(if($loopbackOnly){'PASS'}else{'FAIL'}) $(if($loopbackOnly){'Listener is restricted to loopback.'}else{'Could not prove loopback-only listener binding.'})

if ($bridge) {
  $tabCount = [int]$bridge.browser.tabCount
  Add-Check 'ChatGPT tab detection working' $(if($tabCount -gt 0){'PASS'}else{'WARN'}) $(if($tabCount -gt 0){"$tabCount monitored ChatGPT tab(s)."}else{'No managed ChatGPT tab is currently open.'})

  $fresh = $false
  $age = $null
  if ($bridge.browser.lastExtensionHeartbeatAt) {
    $age = [math]::Round(([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() - [long]$bridge.browser.lastExtensionHeartbeatAt) / 1000.0, 1)
    $fresh = ($age -le 60)
  }
  Add-Check 'Extension heartbeat working' $(if($tabCount -eq 0){'WARN'}elseif($fresh){'PASS'}else{'FAIL'}) $(if($age -ne $null){"Last heartbeat ${age}s ago."}else{'No extension heartbeat recorded.'})

  $protected = $true
  if ($tabCount -eq 0) { $protected = $false }
  foreach ($tab in @($bridge.browser.tabs)) { if (-not [bool]$tab.autoDiscardableProtected) { $protected = $false } }
  Add-Check 'Memory Saver tab protection' $(if($tabCount -eq 0){'WARN'}elseif($protected){'PASS'}else{'FAIL'}) $(if($protected){'Every tracked ChatGPT tab reports autoDiscardable=false.'}else{'A tracked tab is not verified as non-discardable, or no tab is open.'})

  $backgroundDelivery = ($tabCount -gt 0 -and $fresh)
  Add-Check 'Background event delivery working' $(if($backgroundDelivery){'PASS'}else{'WARN'}) $(if($backgroundDelivery){'Controlled extension heartbeat reaches the local bridge.'}else{'Open a managed ChatGPT tab and rerun diagnostics.'})

  $testAccepted = $false
  try {
    $managedState = Get-Content -LiteralPath $managedStateFile -Raw | ConvertFrom-Json
    $token = [string]$managedState.token
    if ($token -notmatch '^[a-f0-9]{32}$') { throw 'Managed session token unavailable.' }
    $headers = @{ Origin='chrome-extension://aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'; 'X-CWN-Token'=$token }
    $payload = @{ tabId=-1; windowId=$bridge.browser.managedWindowId; status='TEST'; title='Diagnostics'; url=''; conversationId=$null; progress=$null; runSeconds=$null; showPopup=$true; transient=$true; at=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() } | ConvertTo-Json -Compress
    $r = Invoke-RestMethod 'http://127.0.0.1:38765/browser-event' -Method Post -Headers $headers -ContentType 'application/json' -Body $payload -TimeoutSec 2
    $testAccepted = [bool]$r.ok
  } catch {}
  Add-Check 'Notification popup pipeline' $(if($testAccepted){'WARN'}else{'FAIL'}) $(if($testAccepted){'Authenticated popup test event accepted. Visual popup appearance requires user confirmation.'}else{'Bridge rejected the authenticated popup test event.'})

  $routing = $false
  try {
    $request = Invoke-RestMethod 'http://127.0.0.1:38765/diagnostic-ping' -Method Post -Headers $headers -ContentType 'application/json' -Body '{}' -TimeoutSec 2
    $requestId = [string]$request.requestId
    # Background Chrome can throttle the content-script poller to one minute;
    # allow one bounded cycle while remaining below the 75-second expiry.
    for ($i=0; $i -lt 140; $i++) {
      Start-Sleep -Milliseconds 500
      $s2 = Invoke-RestMethod 'http://127.0.0.1:38765/state' -TimeoutSec 2
      if ($s2.browser.commandAckAt -and [bool]$s2.browser.commandAckOk -and -not $s2.browser.pendingCommand) { $routing = $true; break }
    }
  } catch {}
  Add-Check 'Notification routing command channel' $(if($tabCount -eq 0){'WARN'}elseif($routing){'PASS'}else{'FAIL'}) $(if($routing){'Extension acknowledged the local command channel.'}else{'No command acknowledgement received.'})
} else {
  Add-Check 'ChatGPT tab detection working' 'FAIL' 'Bridge unavailable.'
  Add-Check 'Extension heartbeat working' 'FAIL' 'Bridge unavailable.'
  Add-Check 'Memory Saver tab protection' 'FAIL' 'Bridge unavailable.'
  Add-Check 'Background event delivery working' 'FAIL' 'Bridge unavailable.'
  Add-Check 'Notification popup pipeline' 'FAIL' 'Bridge unavailable.'
  Add-Check 'Notification routing command channel' 'FAIL' 'Bridge unavailable.'
}

if ($runtimeState) {
  Add-Check 'Original profile preserved' $(if([bool]$runtimeState.usesOriginalChromeProfile){'PASS'}else{'FAIL'}) $(if([bool]$runtimeState.usesOriginalChromeProfile){'No copied or isolated Chrome user-data directory is used.'}else{'Runtime does not report the original Chrome profile.'})
  Add-Check 'Awake protection active' $(if([bool]$runtimeState.monitoringEnabled -and [bool]$runtimeState.settings.keepComputerAwake -and [bool]$runtimeState.awakeProtection){'PASS'}elseif(-not [bool]$runtimeState.settings.keepComputerAwake){'WARN'}else{'FAIL'}) $(if([bool]$runtimeState.awakeProtection){'SetThreadExecutionState protection is active.'}else{'Awake protection is not active.'})
  Add-Check 'Recovery mechanism configured' $(if([bool]$runtimeState.settings.autoRecoverChrome -and [bool]$runtimeState.settings.autoRepairConnection){'PASS'}else{'WARN'}) "Recovery state: $($runtimeState.recoveryStatus)"
  Add-Check 'Hidden-window state known' 'PASS' $(if([bool]$runtimeState.managedHidden){'Managed Chrome is currently hidden to tray.'}else{'Managed Chrome is currently visible or not hidden.'})
} else {
  Add-Check 'Original profile preserved' 'FAIL' 'Tray runtime state file was not found.'
  Add-Check 'Awake protection active' 'FAIL' 'Tray runtime state file was not found.'
  Add-Check 'Recovery mechanism configured' 'FAIL' 'Tray runtime state file was not found.'
  Add-Check 'Hidden-window state known' 'FAIL' 'Tray runtime state file was not found.'
}

$fail = @($checks | Where-Object { $_.status -eq 'FAIL' }).Count
$warn = @($checks | Where-Object { $_.status -eq 'WARN' }).Count
if ($Text) {
  foreach ($c in $checks) { Write-Output ("{0,-4}  {1} - {2}" -f $c.status,$c.name,$c.detail) }
  Write-Output ''
  Write-Output ("Summary: {0} PASS, {1} WARN, {2} FAIL" -f (@($checks | Where-Object {$_.status -eq 'PASS'}).Count),$warn,$fail)
} else {
  [ordered]@{ version='2.4.0'; checks=$checks } | ConvertTo-Json -Depth 8
}
if ($fail -gt 0) { exit 1 }
