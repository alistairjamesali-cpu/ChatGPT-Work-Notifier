$ErrorActionPreference = 'SilentlyContinue'
$rk = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$runtimeBase = Join-Path $env:LOCALAPPDATA 'ChatGPT Work Notifier'
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$rootNeedle = $root.ToLowerInvariant()
$stateFile = Join-Path $runtimeBase 'managed-window.json'

Remove-ItemProperty -Path $rk -Name 'ChatGPTWorkNotifierV2' -ErrorAction SilentlyContinue

# Migration cleanup only: obsolete pre-Chrome-only startup state.
Remove-ItemProperty -Path $rk -Name 'ChatGPTWorkNotifierCompanion' -ErrorAction SilentlyContinue

# Close only the captured managed Chrome window. The user's other Chrome windows
# share the same real profile/process and must never be terminated.
try {
  Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class CwnUninstallWindow {
  [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr hWnd);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr hWnd, System.Text.StringBuilder lpClassName, int nMaxCount);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
  [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);
  public static bool IsChromeTopLevelWindow(IntPtr hWnd) {
    if (!IsWindow(hWnd)) return false;
    var cls = new System.Text.StringBuilder(128); GetClassName(hWnd, cls, cls.Capacity);
    if (!cls.ToString().StartsWith("Chrome_WidgetWin_", StringComparison.Ordinal)) return false;
    uint pid; GetWindowThreadProcessId(hWnd, out pid);
    try { return System.Diagnostics.Process.GetProcessById((int)pid).ProcessName.Equals("chrome", StringComparison.OrdinalIgnoreCase); } catch { return false; }
  }
}
'@
  if (Test-Path $stateFile) {
    $saved = Get-Content -LiteralPath $stateFile -Raw | ConvertFrom-Json
    $hwnd = [IntPtr][long]$saved.hwnd
    if ($hwnd -ne [IntPtr]::Zero -and [CwnUninstallWindow]::IsChromeTopLevelWindow($hwnd)) {
      [CwnUninstallWindow]::PostMessage($hwnd, 0x0010, [IntPtr]::Zero, [IntPtr]::Zero) | Out-Null
    }
  }
} catch {}

# Stop only notifier PowerShell components.
try {
  Get-CimInstance Win32_Process | Where-Object {
    $_.Name -eq 'powershell.exe' -and $_.CommandLine -and (
      ($_.CommandLine.ToLowerInvariant().Contains($rootNeedle) -and ($_.CommandLine -like '*tray-host.ps1*' -or $_.CommandLine -like '*browser-bridge.ps1*')) -or
      $_.CommandLine -like '*chatgpt-app-watcher.ps1*' # migration cleanup only
    )
  } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
} catch {}

Write-Output 'ChatGPT Work Notifier v2.4.0 uninstalled. Your original Chrome profile and other Chrome windows were not changed.'
