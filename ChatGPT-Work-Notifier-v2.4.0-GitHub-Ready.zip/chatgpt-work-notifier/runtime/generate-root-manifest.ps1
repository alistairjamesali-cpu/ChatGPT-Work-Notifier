param(
  [string]$Root = (Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path))
)

$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path -LiteralPath $Root).Path
$output = Join-Path $Root 'ROOT_FILE_MANIFEST_V240.tsv'
$integrity = Join-Path $Root 'FILE_SHA256SUMS.txt'
$rows = New-Object System.Collections.Generic.List[string]
[void]$rows.Add("relative_path`tbyte_size`tsha256")
Get-ChildItem -LiteralPath $Root -File -Recurse | Where-Object {
  $_.FullName -ne $output -and $_.FullName -ne $integrity -and $_.Extension -notin @('.zip','.sha256')
} | Sort-Object FullName | ForEach-Object {
  $relative = $_.FullName.Substring($Root.Length).TrimStart([char[]]@('\','/')) -replace '\\','/'
  $hash = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
  [void]$rows.Add("$relative`t$($_.Length)`t$hash")
}
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllLines($output, $rows, $utf8NoBom)
Write-Output "Wrote $($rows.Count - 1) root-manifest entries to $output"
