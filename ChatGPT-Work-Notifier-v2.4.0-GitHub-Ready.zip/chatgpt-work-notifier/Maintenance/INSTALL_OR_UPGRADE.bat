@echo off
setlocal
cd /d "%~dp0.."
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\runtime\install.ps1"
if errorlevel 1 (
  echo.
  echo ERROR: Installation failed. The error is shown above.
  pause
  exit /b 1
)
call "%~dp0..\START_CHATGPT_WORK_NOTIFIER.bat"
if errorlevel 1 (
  echo.
  echo ERROR: The notifier launcher failed.
  pause
  exit /b 1
)
echo.
echo Installation complete. Opening the v2.4.0 dashboard...
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -Command "Start-Sleep -Seconds 3"
exit /b 0
