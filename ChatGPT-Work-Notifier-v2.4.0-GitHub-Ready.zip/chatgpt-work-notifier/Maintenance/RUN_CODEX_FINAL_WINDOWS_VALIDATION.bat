@echo off
setlocal EnableExtensions
cd /d "%~dp0.."
echo ============================================================
echo ChatGPT Work Notifier v2.4.0 - Codex source validation
echo ============================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo FAIL: Node.js is required for JavaScript validation.
  exit /b 1
)

set "PYTHON_CMD=py -3"
py -3 -c "import sys" >nul 2>nul
if errorlevel 1 (
  set "PYTHON_CMD=python"
  python -c "import sys" >nul 2>nul
  if errorlevel 1 (
    echo FAIL: Python 3 is required for static/material audits.
    exit /b 1
  )
)

echo [10%%] JavaScript syntax...
for %%F in (state-engine.js reliability-core.js service-worker.js managed-bootstrap.js content.js popup.js) do (
  node --check "%%F" || exit /b 1
)

echo [30%%] State engine tests...
node tests\state-engine-v221.test.js || exit /b 1

echo [40%%] Request-regression tests...
node tests\request-regression-v221.test.js || exit /b 1

echo [48%%] Reliability core tests...
node tests\reliability-core.test.js || exit /b 1

echo [58%%] Multi-tab and service-worker tests...
node tests\service-worker-multitab.test.js || exit /b 1

echo [60%%] Episode and completion delivery regression...
node tests\lifecycle-episode-outbox.test.js || exit /b 1
node tests\autopilot-progress.test.js || exit /b 1

echo [63%%] v2.4.0 repair regression matrix...
node tests\v240-repair-regression.test.js || exit /b 1

echo [65%%] Current-task ranking regression...
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "tests\TRAY_SELECTION_TEST.ps1" || exit /b 1

echo [66%%] Flexible per-tab progress regression...
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -STA -File "tests\TRAY_PROGRESS_PRESENTATION_TEST.ps1" || exit /b 1

echo [67%%] Safe cross-root upgrade regression...
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "tests\INSTALL_MIGRATION_TEST.ps1" || exit /b 1

echo [68%%] Security hardening audit...
%PYTHON_CMD% tests\security-hardening-v230.py || exit /b 1

echo [76%%] Expanded static audit...
%PYTHON_CMD% tests\static-audit.py || exit /b 1

echo [88%%] 100-point material audit...
%PYTHON_CMD% tests\final-100-audit.py || exit /b 1

echo [96%%] Windows PowerShell 5.1 parser gate...
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $bad=@(); Get-ChildItem -Path . -Filter '*.ps1' -Recurse | ForEach-Object { $t=$null; $e=$null; [void][System.Management.Automation.Language.Parser]::ParseFile($_.FullName,[ref]$t,[ref]$e); foreach($x in @($e)){ $bad += ($_.FullName + ': ' + $x.Message) } }; if($bad.Count){ $bad | ForEach-Object { Write-Host $_ }; exit 1 } else { Write-Host 'PASS: all PowerShell files parse.' }" || exit /b 1

echo.
echo [100%%] SOURCE VALIDATION PASS
echo Next: install/launch, reload the unpacked extension if needed,
echo then run tests\VERIFY_RUNTIME.ps1 and runtime\diagnostics.ps1.
exit /b 0
