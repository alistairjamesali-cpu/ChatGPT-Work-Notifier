@echo off
setlocal EnableExtensions
set "BASE=%LOCALAPPDATA%\ChatGPT Work Notifier\AdvancedLogger"
echo.
echo ChatGPT Work Notifier - Advanced Logger status
echo ==============================================
echo.
if not exist "%BASE%\bootstrap-status.json" (
  echo No bootstrap status exists yet.
  echo Run ..\START_CHATGPT_WORK_NOTIFIER.bat first.
  echo.
  pause
  exit /b 1
)
type "%BASE%\bootstrap-status.json"
echo.
echo.
if exist "%BASE%\LATEST_SESSION.txt" (
  echo Latest session:
  type "%BASE%\LATEST_SESSION.txt"
  echo.
)
echo.
pause
exit /b 0
