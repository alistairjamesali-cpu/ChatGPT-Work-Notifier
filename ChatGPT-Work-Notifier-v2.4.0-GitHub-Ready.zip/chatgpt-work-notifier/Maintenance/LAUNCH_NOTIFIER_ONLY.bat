@echo off
setlocal
cd /d "%~dp0.."
"%SystemRoot%\System32\wscript.exe" "%~dp0..\runtime\launch-hidden.vbs" "%~dp0..\runtime\tray-host.ps1"
exit /b 0
