@echo off
setlocal EnableExtensions
set "BASE=%LOCALAPPDATA%\ChatGPT Work Notifier\AdvancedLogger"
if not exist "%BASE%" mkdir "%BASE%" >nul 2>&1
>"%BASE%\STOP" echo stop
echo Advanced logger stop requested.
timeout /t 2 /nobreak >nul 2>&1
exit /b 0
