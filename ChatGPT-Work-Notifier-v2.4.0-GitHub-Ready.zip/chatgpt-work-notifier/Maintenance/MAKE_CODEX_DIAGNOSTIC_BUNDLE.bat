@echo off
setlocal EnableExtensions
cd /d "%~dp0.."
if not exist "%~dp0..\ADVANCED_LOGGER\package-latest.ps1" (
  echo ERROR: Advanced logger files are missing.
  echo Extract the entire ZIP before running this BAT.
  pause
  exit /b 2
)
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\ADVANCED_LOGGER\package-latest.ps1" -OpenFolder
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" pause
exit /b %RC%
