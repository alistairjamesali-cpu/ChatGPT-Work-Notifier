# Advanced Flight Recorder — additive only

This logger is an additive sidecar. The 49 original notifier files remain byte-for-byte frozen.

## Start

Extract the entire ZIP to a normal Windows folder first. Do not run the BAT directly from inside a ZIP preview.

Run:

Double-click the sole root launcher: `START_CHATGPT_WORK_NOTIFIER.bat`.

The launcher performs a visible bootstrap. It validates `flight-recorder.ps1` with the Windows PowerShell parser, starts the recorder, waits for a real session to be created, records the recorder PID, and only reports success after the recorder is confirmed alive. It then invokes `Maintenance\LAUNCH_NOTIFIER_ONLY.bat`. The bootstrap resolves the program directory from `$PSScriptRoot` and does not pass `%~dp0` as a trailing-backslash argument, avoiding the Windows `Illegal characters in path` failure.

If startup fails, the BAT stays open and gives the error. Full startup evidence is written to:

`%LOCALAPPDATA%\ChatGPT Work Notifier\AdvancedLogger\bootstrap.log`

and:

`bootstrap-status.json`

You can also run `Maintenance\CHECK_ADVANCED_LOGGER_STATUS.bat`.

## What it records

The flight recorder samples the notifier bridge every 2 seconds and system health every 10 seconds by default. It preserves raw state evidence and emits diagnostic classifications.

Important classifications include `RESPONSE_GIVEN_CONFIRMED`, `RUN_TO_RESPONSE_COMPLETION`, `GENERATION_RUNNING_CONFIRMED`, `STUCK_THINKING_CONFIRMED`, `MESSAGE_TIMEOUT_CONFIRMED`, `COMPLETION_UNCERTAIN_CONFIRMED`, `SAFE_RECOVERY_FAILED`, `GENERATION_STALL_SUSPECTED`, `CHROME_FROZEN_CONFIRMED`, `PAGE_STALE_CONFIRMED`, `EXTENSION_HEARTBEAT_STALE_CONFIRMED`, `BRIDGE_UNAVAILABLE_CONFIRMED`, `TAB_DISCARDED_CONFIRMED`, `CONNECTION_LOST_CONFIRMED`, `RESPONSE_FAILED_CONFIRMED`, and recovery events.

`GENERATION_STALL_SUSPECTED` is deliberately not treated as a confirmed freeze. A real Chrome hang requires stronger Windows/notifier evidence.

It also captures runtime state, settings/state-file hashes, the original tray-host log tail, Chrome process/resource state, TCP/DNS evidence, Windows application errors/hangs, memory, battery/power state, and active power scheme.

## Source freeze

`FROZEN_ORIGINAL_SHA256.txt` is preserved as immutable provenance for the uploaded v2.1.1 base. Runtime integrity for the current program is checked against the root `FILE_SHA256SUMS.txt`, regenerated for v2.4.0. Historical manifests remain provenance and are not relabelled.

## Stop

Run `Maintenance\STOP_ADVANCED_LOGGER.bat`.

## Codex diagnosis

Run `Maintenance\MAKE_CODEX_DIAGNOSTIC_BUNDLE.bat`.

The diagnostic ZIP contains the latest session evidence plus the bootstrap status/log and recorder stdout/stderr. This lets Codex diagnose failures that happen before the recorder itself has fully started.

## Privacy

The sidecar does not copy prompt or assistant response body text. It records diagnostic metadata and state transitions required to establish whether ChatGPT was running, completed, stalled, failed, stale, disconnected, discarded, hung, or recovered.
