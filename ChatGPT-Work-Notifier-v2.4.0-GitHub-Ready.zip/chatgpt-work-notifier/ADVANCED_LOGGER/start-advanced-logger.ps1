param()

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function New-Utf8NoBom {
  return New-Object System.Text.UTF8Encoding($false)
}

# Resolve the program root from this script's physical location.
# Do not accept a quoted %~dp0 argument from cmd.exe: a trailing backslash
# immediately before a closing quote can be parsed inconsistently and can
# leave an embedded quote in the path, causing .NET path normalization to throw
# "Illegal characters in path."
$ProgramRoot = (Get-Item -LiteralPath (Join-Path $PSScriptRoot '..') -ErrorAction Stop).FullName

$loggerDir = Join-Path $ProgramRoot 'ADVANCED_LOGGER'
$flight = Join-Path $loggerDir 'flight-recorder.ps1'
$notifierBat = Join-Path $ProgramRoot 'Maintenance\LAUNCH_NOTIFIER_ONLY.bat'

$runtimeBase = Join-Path $env:LOCALAPPDATA 'ChatGPT Work Notifier'
$loggerBase = Join-Path $runtimeBase 'AdvancedLogger'
$latestFile = Join-Path $loggerBase 'LATEST_SESSION.txt'
$bootstrapLog = Join-Path $loggerBase 'bootstrap.log'
$bootstrapStatus = Join-Path $loggerBase 'bootstrap-status.json'
$stdoutLog = Join-Path $loggerBase 'flight-recorder.stdout.log'
$stderrLog = Join-Path $loggerBase 'flight-recorder.stderr.log'
$pidFile = Join-Path $loggerBase 'RECORDER.pid'

New-Item -ItemType Directory -Path $loggerBase -Force | Out-Null

function Log([string]$Message) {
  $line = ('{0:o} {1}' -f [DateTimeOffset]::UtcNow, $Message)
  [System.IO.File]::AppendAllText($bootstrapLog, $line + [Environment]::NewLine, (New-Utf8NoBom))
}

function Write-Status([string]$State, [string]$Message, $Extra) {
  $obj = [ordered]@{
    schemaVersion = 1
    updatedAtUtc = [DateTimeOffset]::UtcNow.ToString('o')
    state = $State
    message = $Message
    programRoot = $ProgramRoot
    flightRecorder = $flight
    notifierLauncher = $notifierBat
    extra = $Extra
  }
  [System.IO.File]::WriteAllText($bootstrapStatus, ($obj | ConvertTo-Json -Depth 8), (New-Utf8NoBom))
}

function Test-RecorderPid([int]$PidValue) {
  try {
    $p = Get-Process -Id $PidValue -ErrorAction Stop
    if ($p.HasExited) { return $false }
    try {
      $cim = Get-CimInstance Win32_Process -Filter ("ProcessId = " + $PidValue) -ErrorAction Stop
      if ($cim -and $cim.CommandLine -and ([string]$cim.CommandLine).IndexOf('flight-recorder.ps1',[System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
        return $true
      }
    } catch {
      # If CIM is unavailable but the PID is alive, do not kill or disturb it.
      return $true
    }
  } catch {}
  return $false
}

try {
  Log 'BOOTSTRAP_BEGIN'

  if (-not (Test-Path -LiteralPath $flight)) {
    throw "Missing flight recorder: $flight"
  }
  if (-not (Test-Path -LiteralPath $notifierBat)) {
    throw "Missing notifier launcher: $notifierBat"
  }

  # Parse the recorder before hiding it. Any syntax error becomes visible and logged.
  $tokens = $null
  $parseErrors = $null
  [void][System.Management.Automation.Language.Parser]::ParseFile($flight, [ref]$tokens, [ref]$parseErrors)
  if ($parseErrors -and $parseErrors.Count -gt 0) {
    $msg = ($parseErrors | ForEach-Object {
      'Line ' + $_.Extent.StartLineNumber + ', column ' + $_.Extent.StartColumnNumber + ': ' + $_.Message
    }) -join ' | '
    throw "flight-recorder.ps1 parser failure: $msg"
  }
  Log 'FLIGHT_RECORDER_PARSE_OK'

  # Avoid duplicate recorders when the launcher is double-clicked twice.
  $existingPid = 0
  if (Test-Path -LiteralPath $pidFile) {
    try { $existingPid = [int](Get-Content -LiteralPath $pidFile -Raw).Trim() } catch { $existingPid = 0 }
  }

  $sessionDir = $null
  $recorderPid = $null
  if ($existingPid -gt 0 -and (Test-RecorderPid $existingPid)) {
    $recorderPid = $existingPid
    if (Test-Path -LiteralPath $latestFile) {
      try { $sessionDir = (Get-Content -LiteralPath $latestFile -Raw).Trim() } catch {}
    }
    Log ("RECORDER_ALREADY_RUNNING PID=" + $recorderPid)
  } else {
    try { Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue } catch {}
    try { Remove-Item -LiteralPath $stdoutLog -Force -ErrorAction SilentlyContinue } catch {}
    try { Remove-Item -LiteralPath $stderrLog -Force -ErrorAction SilentlyContinue } catch {}

    $oldLatest = $null
    if (Test-Path -LiteralPath $latestFile) {
      try { $oldLatest = (Get-Content -LiteralPath $latestFile -Raw).Trim() } catch {}
    }

    $psExe = Join-Path $PSHOME 'powershell.exe'
    if (-not (Test-Path -LiteralPath $psExe)) { $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe' }
    if (-not (Test-Path -LiteralPath $psExe -PathType Leaf)) { throw 'Windows PowerShell executable not found.' }

    $arguments = '-NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $flight.Replace('"','""') + '"'
    $proc = Start-Process -FilePath $psExe `
                          -ArgumentList $arguments `
                          -WindowStyle Hidden `
                          -RedirectStandardOutput $stdoutLog `
                          -RedirectStandardError $stderrLog `
                          -PassThru
    $recorderPid = $proc.Id
    [System.IO.File]::WriteAllText($pidFile, [string]$recorderPid, (New-Utf8NoBom))
    Log ("RECORDER_PROCESS_STARTED PID=" + $recorderPid)

    $deadline = [DateTimeOffset]::UtcNow.AddSeconds(12)
    do {
      Start-Sleep -Milliseconds 250

      try {
        $pcheck = Get-Process -Id $recorderPid -ErrorAction Stop
        if ($pcheck.HasExited) {
          throw "flight recorder exited during startup with exit code $($pcheck.ExitCode)"
        }
      } catch {
        $stderr = ''
        if (Test-Path -LiteralPath $stderrLog) {
          try { $stderr = (Get-Content -LiteralPath $stderrLog -Raw -ErrorAction SilentlyContinue).Trim() } catch {}
        }
        if ($stderr) { throw "flight recorder exited during startup. stderr: $stderr" }
        throw "flight recorder exited during startup before a session was created."
      }

      if (Test-Path -LiteralPath $latestFile) {
        try {
          $candidate = (Get-Content -LiteralPath $latestFile -Raw).Trim()
          if ($candidate -and $candidate -ne $oldLatest -and (Test-Path -LiteralPath $candidate)) {
            $sessionFile = Join-Path $candidate 'session.json'
            if (Test-Path -LiteralPath $sessionFile) {
              $sessionDir = $candidate
              break
            }
          }
        } catch {}
      }
    } while ([DateTimeOffset]::UtcNow -lt $deadline)

    if (-not $sessionDir) {
      $stderr = ''
      if (Test-Path -LiteralPath $stderrLog) {
        try { $stderr = (Get-Content -LiteralPath $stderrLog -Raw -ErrorAction SilentlyContinue).Trim() } catch {}
      }
      if ($stderr) { throw "flight recorder did not create a session within 12 seconds. stderr: $stderr" }
      throw 'flight recorder did not create a session within 12 seconds.'
    }

    Log ("RECORDER_SESSION_CONFIRMED " + $sessionDir)
  }

  # Launch the notifier-only maintenance wrapper. PowerShell invokes the BAT through cmd.exe and waits
  # only for that tiny wrapper to return; the notifier itself remains hidden as designed.
  Push-Location $ProgramRoot
  try {
    & $notifierBat
    $launchCode = $LASTEXITCODE
  }
  finally {
    Pop-Location
  }
  if ($null -ne $launchCode -and $launchCode -ne 0) {
    throw "Notifier launcher returned exit code $launchCode"
  }
  Log 'NOTIFIER_V220_LAUNCH_SENT'

  Write-Status 'RUNNING' 'Advanced logger is running and the v2.4.0 notifier launch was sent.' ([ordered]@{
    recorderPid = $recorderPid
    sessionDir = $sessionDir
    bootstrapLog = $bootstrapLog
    recorderStdout = $stdoutLog
    recorderStderr = $stderrLog
    originalFilesEdited = $true
    currentReleaseIntegrityManifest = (Join-Path $ProgramRoot 'FILE_SHA256SUMS.txt')
    historicalFrozenBaselinePreserved = $true
  })

  Write-Host ('Recorder PID: ' + $recorderPid)
  Write-Host ('Session: ' + $sessionDir)
  exit 0
}
catch {
  $message = $_.Exception.Message
  Log ("BOOTSTRAP_FAILURE " + $message)
  Write-Status 'FAILED' $message ([ordered]@{
    bootstrapLog = $bootstrapLog
    recorderStdout = $stdoutLog
    recorderStderr = $stderrLog
    originalFilesEdited = $true
    currentReleaseIntegrityManifest = (Join-Path $ProgramRoot 'FILE_SHA256SUMS.txt')
    historicalFrozenBaselinePreserved = $true
  })
  Write-Host ''
  Write-Host ('STARTUP FAILURE: ' + $message) -ForegroundColor Red
  Write-Host ('Bootstrap log: ' + $bootstrapLog)
  if (Test-Path -LiteralPath $stderrLog) {
    try {
      $stderr = (Get-Content -LiteralPath $stderrLog -Raw -ErrorAction SilentlyContinue).Trim()
      if ($stderr) {
        Write-Host ''
        Write-Host 'Recorder stderr:' -ForegroundColor Yellow
        Write-Host $stderr
      }
    } catch {}
  }
  exit 10
}
