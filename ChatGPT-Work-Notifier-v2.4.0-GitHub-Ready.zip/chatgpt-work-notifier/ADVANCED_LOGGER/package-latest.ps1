param([switch]$OpenFolder)
$ErrorActionPreference = 'Stop'
$runtimeBase = Join-Path $env:LOCALAPPDATA 'ChatGPT Work Notifier'
$loggerBase = Join-Path $runtimeBase 'AdvancedLogger'
$latestFile = Join-Path $loggerBase 'LATEST_SESSION.txt'
if (-not (Test-Path -LiteralPath $latestFile)) { throw 'No advanced logger session has been recorded yet.' }
$sessionDir = (Get-Content -LiteralPath $latestFile -Raw).Trim()
if (-not $sessionDir -or -not (Test-Path -LiteralPath $sessionDir)) { throw 'The latest advanced logger session folder does not exist.' }

$bundleDir = Join-Path $loggerBase 'CodexBundles'
New-Item -ItemType Directory -Path $bundleDir -Force | Out-Null
$stamp = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ')
$stage = Join-Path $loggerBase ("BundleStage_" + $stamp + "_" + $PID)
New-Item -ItemType Directory -Path $stage -Force | Out-Null

try {
  Copy-Item -Path (Join-Path $sessionDir '*') -Destination $stage -Recurse -Force

  foreach ($name in @(
    'bootstrap.log',
    'bootstrap-status.json',
    'flight-recorder.stdout.log',
    'flight-recorder.stderr.log',
    'RECORDER.pid'
  )) {
    $p = Join-Path $loggerBase $name
    if (Test-Path -LiteralPath $p) {
      Copy-Item -LiteralPath $p -Destination (Join-Path $stage $name) -Force
    }
  }

  $out = Join-Path $bundleDir ("ChatGPT_Work_Notifier_CODEX_DIAGNOSTICS_${stamp}.zip")
  if (Test-Path -LiteralPath $out) { Remove-Item -LiteralPath $out -Force }
  Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $out -CompressionLevel Optimal
  $hash = (Get-FileHash -LiteralPath $out -Algorithm SHA256).Hash.ToLowerInvariant()
  [System.IO.File]::WriteAllText(($out + '.sha256'), ($hash + ' *' + [System.IO.Path]::GetFileName($out) + [Environment]::NewLine), (New-Object System.Text.UTF8Encoding($false)))

  Write-Host ''
  Write-Host 'Codex diagnostic bundle:'
  Write-Host $out
  Write-Host ('SHA-256: ' + $hash)
  if ($OpenFolder) { $explorer=Join-Path $env:SystemRoot 'explorer.exe'; if(Test-Path -LiteralPath $explorer){ Start-Process -FilePath $explorer -ArgumentList ('/select,"' + $out + '"') } }
}
finally {
  Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
}
