param(
  [ValidateRange(1,30)][int]$SampleSeconds = 2,
  [ValidateRange(5,120)][int]$HealthSeconds = 10,
  [ValidateRange(60,3600)][int]$SuspectedStallSeconds = 180,
  [switch]$NoSourceIntegrityCheck
)

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
Set-StrictMode -Version 2.0

$LoggerVersion = '1.1.1'
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$loggerDir = Join-Path $root 'ADVANCED_LOGGER'
$runtimeBase = Join-Path $env:LOCALAPPDATA 'ChatGPT Work Notifier'
$loggerBase = Join-Path $runtimeBase 'AdvancedLogger'
$sessionsBase = Join-Path $loggerBase 'Sessions'
$sessionId = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ') + '_' + $PID
$sessionDir = Join-Path $sessionsBase $sessionId
$eventsFile = Join-Path $sessionDir 'events.ndjson'
$snapshotsFile = Join-Path $sessionDir 'snapshots.ndjson'
$healthFile = Join-Path $sessionDir 'health.ndjson'
$errorsFile = Join-Path $sessionDir 'errors.ndjson'
$summaryFile = Join-Path $sessionDir 'codex_diagnosis_summary.json'
$sessionFile = Join-Path $sessionDir 'session.json'
$stopFile = Join-Path $loggerBase 'STOP'
$latestFile = Join-Path $loggerBase 'LATEST_SESSION.txt'
$bridgeUrl = 'http://127.0.0.1:38765/state'
$runtimeStateFile = Join-Path $runtimeBase 'runtime-state.json'
$settingsFile = Join-Path $runtimeBase 'settings.json'
$managedStateFile = Join-Path $runtimeBase 'managed-window.json'
$trayLog = Join-Path (Join-Path $runtimeBase 'Logs') 'tray-host.log'
$manifestPath = Join-Path $root 'FILE_SHA256SUMS.txt'
$historicalManifestPath = Join-Path $loggerDir 'FROZEN_ORIGINAL_SHA256.txt'

New-Item -ItemType Directory -Path $sessionDir -Force | Out-Null
try { if (Test-Path -LiteralPath $stopFile) { Remove-Item -LiteralPath $stopFile -Force } } catch {}
[System.IO.File]::WriteAllText($latestFile, $sessionDir, [System.Text.UTF8Encoding]::new($false))

$script:StartUtc = [DateTimeOffset]::UtcNow
$script:Sequence = 0L
$script:BridgeMisses = 0
$script:BridgeDownEventOpen = $false
$script:ChromeHungEventOpen = $false
$script:ChromeMissingEventOpen = $false
$script:LastHealthUtc = [DateTimeOffset]::MinValue
$script:LastEventLogUtc = [DateTimeOffset]::UtcNow.AddSeconds(-30)
$script:LastDnsUtc = [DateTimeOffset]::MinValue
$script:PrevChromeCpu = $null
$script:PrevProcessSampleUtc = $null
$script:TabState = @{}
$script:SeenBridgeEvents = @{}
$script:EventCounts = @{}
$script:IntegrityOk = $null
$script:IntegrityFailures = @()
$script:LatestClassification = 'LOGGER_STARTING'
$script:LastRuntimeHash = $null
$script:LastSettingsHash = $null
$script:LastManagedHash = $null
$script:LastTrayLogLength = 0L

function Get-UtcIso { return [DateTimeOffset]::UtcNow.ToString('o') }
function Get-MonotonicMs { return [math]::Round(([DateTimeOffset]::UtcNow - $script:StartUtc).TotalMilliseconds) }

function Convert-SafeJson($Object, [int]$Depth = 12) {
  try { return ($Object | ConvertTo-Json -Depth $Depth -Compress) }
  catch { return '{"serializationError":true}' }
}

function Write-Ndjson([string]$Path, [string]$Kind, $Payload) {
  try {
    $script:Sequence++
    $record = [ordered]@{
      tsUtc = Get-UtcIso
      monotonicMs = Get-MonotonicMs
      sequence = $script:Sequence
      kind = $Kind
      payload = $Payload
    }
    [System.IO.File]::AppendAllText($Path, (Convert-SafeJson $record 16) + [Environment]::NewLine, [System.Text.UTF8Encoding]::new($false))
  } catch {}
}

function Write-Error([string]$Stage, $ErrorObject) {
  $message = ''
  $type = ''
  try { $message = [string]$ErrorObject.Exception.Message; $type = $ErrorObject.Exception.GetType().FullName } catch { $message = [string]$ErrorObject }
  Write-Ndjson $errorsFile 'LOGGER_ERROR' ([ordered]@{ stage=$Stage; message=$message; exceptionType=$type })
}

function Emit-Event([string]$Code, [string]$Severity, $Evidence, [string]$Meaning) {
  if (-not $script:EventCounts.ContainsKey($Code)) { $script:EventCounts[$Code] = 0 }
  $script:EventCounts[$Code] = [int]$script:EventCounts[$Code] + 1
  $script:LatestClassification = $Code
  Write-Ndjson $eventsFile $Code ([ordered]@{
    severity = $Severity
    meaning = $Meaning
    evidence = $Evidence
  })
}

function Read-JsonFile([string]$Path) {
  if (-not (Test-Path -LiteralPath $Path)) { return $null }
  try { return (Get-Content -LiteralPath $Path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop) }
  catch { Write-Error ('Read-JsonFile:' + $Path) $_; return $null }
}

function Get-FileHashSafe([string]$Path) {
  if (-not (Test-Path -LiteralPath $Path)) { return $null }
  $stream = $null
  $sha = $null
  try {
    $stream = [System.IO.File]::Open($Path,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::ReadWrite)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    return ([System.BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-','').ToLowerInvariant()
  }
  catch { Write-Error ('Get-FileHash:' + $Path) $_; return $null }
  finally {
    if ($sha) { $sha.Dispose() }
    if ($stream) { $stream.Dispose() }
  }
}

function Verify-ReleaseIntegrity {
  if ($NoSourceIntegrityCheck) {
    $script:IntegrityOk = $null
    Emit-Event 'SOURCE_INTEGRITY_CHECK_SKIPPED' 'INFO' @{} 'The optional current-release integrity check was explicitly disabled.'
    return
  }
  if (-not (Test-Path -LiteralPath $manifestPath)) {
    $script:IntegrityOk = $false
    $script:IntegrityFailures += 'Manifest missing.'
    Emit-Event 'SOURCE_INTEGRITY_FAILURE' 'ERROR' @{ manifest=$manifestPath } 'The current-release SHA-256 manifest is missing.'
    return
  }
  $failures = New-Object System.Collections.Generic.List[object]
  $checked = 0
  foreach ($line in (Get-Content -LiteralPath $manifestPath -ErrorAction SilentlyContinue)) {
    if (-not $line -or $line.StartsWith('#')) { continue }
    if ($line -notmatch '^([a-fA-F0-9]{64})\s+\*?(.+)$') { continue }
    $expected = $Matches[1].ToLowerInvariant()
    $relative = $Matches[2]
    $path = Join-Path $root $relative
    $actual = Get-FileHashSafe $path
    $checked++
    if (-not $actual -or $actual -ne $expected) {
      [void]$failures.Add([ordered]@{ path=$relative; expected=$expected; actual=$actual; exists=(Test-Path -LiteralPath $path) })
    }
  }
  $script:IntegrityOk = ($failures.Count -eq 0)
  $script:IntegrityFailures = $failures.ToArray()
  if ($script:IntegrityOk) {
    Emit-Event 'SOURCE_INTEGRITY_VERIFIED' 'INFO' @{ filesChecked=$checked } 'All monitored release files match the current v2.4.0 SHA-256 manifest.'
  } else {
    Emit-Event 'SOURCE_INTEGRITY_FAILURE' 'ERROR' @{ filesChecked=$checked; failures=$failures.ToArray() } 'One or more current release files were changed, missing, or corrupted after packaging.'
  }
}

function Get-BridgeState {
  try { return Invoke-RestMethod -Uri $bridgeUrl -Method Get -TimeoutSec 1 -ErrorAction Stop }
  catch { return $null }
}

function Get-ChromeMetrics($RuntimeState) {
  $processes = @()
  try { $processes = @(Get-Process chrome -ErrorAction SilentlyContinue) } catch {}
  $cpu = 0.0
  $working = 0L
  $private = 0L
  $handles = 0L
  $threads = 0L
  $ioRead = 0L
  $ioWrite = 0L
  foreach ($p in $processes) {
    try { if ($null -ne $p.CPU) { $cpu += [double]$p.CPU } } catch {}
    try { $working += [long]$p.WorkingSet64 } catch {}
    try { $private += [long]$p.PrivateMemorySize64 } catch {}
    try { $handles += [long]$p.HandleCount } catch {}
    try { $threads += [long]$p.Threads.Count } catch {}
    try { $ioRead += [long]$p.IOReadBytes } catch {}
    try { $ioWrite += [long]$p.IOWriteBytes } catch {}
  }
  $now = [DateTimeOffset]::UtcNow
  $cpuPct = $null
  if ($null -ne $script:PrevChromeCpu -and $script:PrevProcessSampleUtc) {
    $elapsed = ($now - $script:PrevProcessSampleUtc).TotalSeconds
    if ($elapsed -gt 0) {
      $logical = [Environment]::ProcessorCount
      if ($logical -lt 1) { $logical = 1 }
      $cpuPct = [math]::Round((($cpu - [double]$script:PrevChromeCpu) / $elapsed) * 100.0 / $logical, 2)
      if ($cpuPct -lt 0) { $cpuPct = 0 }
    }
  }
  $script:PrevChromeCpu = $cpu
  $script:PrevProcessSampleUtc = $now

  $managedPid = $null
  $responding = $null
  if ($RuntimeState -and $RuntimeState.chromeProcessId) {
    try {
      $managedPid = [int]$RuntimeState.chromeProcessId
      $mp = Get-Process -Id $managedPid -ErrorAction Stop
      try { $responding = [bool]$mp.Responding } catch { $responding = $null }
    } catch {}
  }
  return [ordered]@{
    processCount = $processes.Count
    totalCpuSeconds = [math]::Round($cpu,3)
    normalizedCpuPercent = $cpuPct
    workingSetBytes = $working
    privateBytes = $private
    handleCount = $handles
    threadCount = $threads
    ioReadBytes = $ioRead
    ioWriteBytes = $ioWrite
    managedPid = $managedPid
    managedProcessResponding = $responding
  }
}

function Get-NetworkMetrics {
  $result = [ordered]@{ establishedChromeTcp=$null; chatgptDnsOk=$null; resolvedAddresses=@() }
  try {
    $pids = @(Get-Process chrome -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id)
    if ($pids.Count -gt 0) {
      $conns = @(Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue | Where-Object { $pids -contains $_.OwningProcess })
      $result.establishedChromeTcp = $conns.Count
    } else { $result.establishedChromeTcp = 0 }
  } catch {}
  $now = [DateTimeOffset]::UtcNow
  if (($now - $script:LastDnsUtc).TotalSeconds -ge 60) {
    $script:LastDnsUtc = $now
    try {
      $dns = @(Resolve-DnsName chatgpt.com -Type A -DnsOnly -QuickTimeout -ErrorAction Stop | Where-Object {$_.IPAddress} | Select-Object -ExpandProperty IPAddress -Unique)
      $result.chatgptDnsOk = ($dns.Count -gt 0)
      $result.resolvedAddresses = @($dns | Select-Object -First 8)
    } catch { $result.chatgptDnsOk = $false }
  }
  return $result
}

function Get-SystemHealth($RuntimeState, $ChromeMetrics) {
  $os = $null
  try { $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop } catch {}
  $powerScheme = $null
  try { $powercfg=Join-Path $env:SystemRoot 'System32\powercfg.exe'; if(Test-Path -LiteralPath $powercfg){ $powerScheme = (& $powercfg /GETACTIVESCHEME 2>$null | Out-String).Trim() } } catch {}
  $battery = $null
  try {
    $b = Get-CimInstance Win32_Battery -ErrorAction Stop | Select-Object -First 1
    if ($b) { $battery = [ordered]@{ estimatedChargeRemaining=$b.EstimatedChargeRemaining; batteryStatus=$b.BatteryStatus } }
  } catch {}
  return [ordered]@{
    os = if ($os) { [ordered]@{ caption=$os.Caption; version=$os.Version; build=$os.BuildNumber; freePhysicalMemoryKb=$os.FreePhysicalMemory; totalVisibleMemoryKb=$os.TotalVisibleMemorySize; lastBootUpTime=$os.LastBootUpTime } } else { $null }
    powerScheme = $powerScheme
    battery = $battery
    runtimeAwakeProtection = if ($RuntimeState) { $RuntimeState.awakeProtection } else { $null }
    runtimeChromeAlive = if ($RuntimeState) { $RuntimeState.chromeAlive } else { $null }
    runtimeChromeHung = if ($RuntimeState) { $RuntimeState.chromeHung } else { $null }
    runtimeRecoveryStatus = if ($RuntimeState) { $RuntimeState.recoveryStatus } else { $null }
    chrome = $ChromeMetrics
    network = Get-NetworkMetrics
  }
}

function Capture-WindowsEvents {
  $now = [DateTimeOffset]::UtcNow
  try {
    $items = @(Get-WinEvent -FilterHashtable @{ LogName='Application'; StartTime=$script:LastEventLogUtc.LocalDateTime } -ErrorAction Stop |
      Where-Object {
        $_.LevelDisplayName -in @('Critical','Error','Warning') -and
        ($_.ProviderName -match 'Application Hang|Application Error|Windows Error Reporting|Chrome|PowerShell|.NET Runtime')
      } | Select-Object -First 60)
    foreach ($e in $items) {
      Write-Ndjson $healthFile 'WINDOWS_EVENT' ([ordered]@{
        timeCreated = if ($e.TimeCreated) { $e.TimeCreated.ToUniversalTime().ToString('o') } else { $null }
        provider = $e.ProviderName
        id = $e.Id
        level = $e.LevelDisplayName
        message = if ($e.Message) { ([string]$e.Message).Substring(0,[math]::Min(4000,([string]$e.Message).Length)) } else { '' }
      })
    }
  } catch {
    if ([string]$_.FullyQualifiedErrorId -notmatch '^NoMatchingEventsFound') { Write-Error 'Capture-WindowsEvents' $_ }
  }
  $script:LastEventLogUtc = $now
}

function Capture-FileChange([string]$Name, [string]$Path, [ref]$PreviousHash) {
  $hash = Get-FileHashSafe $Path
  if ($hash -ne $PreviousHash.Value) {
    $detail = [ordered]@{ name=$Name; path=$Path; exists=(Test-Path -LiteralPath $Path); sha256=$hash }
    if (Test-Path -LiteralPath $Path) {
      try {
        $fi = Get-Item -LiteralPath $Path -ErrorAction Stop
        $detail.bytes = $fi.Length
        $detail.lastWriteTimeUtc = $fi.LastWriteTimeUtc.ToString('o')
      } catch {}
    }
    Write-Ndjson $healthFile 'RUNTIME_FILE_CHANGED' $detail
    $PreviousHash.Value = $hash
  }
}

function Capture-TrayLogTail {
  if (-not (Test-Path -LiteralPath $trayLog)) { return }
  try {
    $fi = Get-Item -LiteralPath $trayLog -ErrorAction Stop
    if ($fi.Length -lt $script:LastTrayLogLength) { $script:LastTrayLogLength = 0 }
    if ($fi.Length -gt $script:LastTrayLogLength) {
      $fs = [System.IO.File]::Open($trayLog,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::ReadWrite)
      try {
        $fs.Seek($script:LastTrayLogLength,[System.IO.SeekOrigin]::Begin) | Out-Null
        $sr = New-Object System.IO.StreamReader($fs)
        $text = $sr.ReadToEnd()
        $script:LastTrayLogLength = $fi.Length
        if ($text) {
          foreach ($line in ($text -split "`r?`n")) {
            if ($line) { Write-Ndjson $healthFile 'TRAY_HOST_LOG' ([ordered]@{ line=$line }) }
          }
        }
      } finally { $fs.Dispose() }
    }
  } catch { Write-Error 'Capture-TrayLogTail' $_ }
}

function BridgeEventKey($Event) {
  if (-not $Event) { return $null }
  return ('{0}|{1}|{2}|{3}|{4}' -f $Event.tabId,$Event.status,$Event.at,$Event.progress,$Event.runSeconds)
}

function Handle-BridgeEvent($Bridge) {
  if (-not $Bridge -or -not $Bridge.browser -or -not $Bridge.browser.lastEvent) { return }
  $e = $Bridge.browser.lastEvent
  $key = BridgeEventKey $e
  if (-not $key -or $script:SeenBridgeEvents.ContainsKey($key)) { return }
  $script:SeenBridgeEvents[$key] = $true
  if ($script:SeenBridgeEvents.Count -gt 5000) { $script:SeenBridgeEvents = @{}; $script:SeenBridgeEvents[$key] = $true }
  Write-Ndjson $eventsFile 'BRIDGE_EVENT_RAW' $e

  $evidence = [ordered]@{ tabId=$e.tabId; status=$e.status; at=$e.at; progress=$e.progress; runSeconds=$e.runSeconds; showPopup=$e.showPopup; discarded=$e.discarded; autoDiscardableProtected=$e.autoDiscardableProtected; safeCompletion=[bool]$e.safeCompletion; manualAction=[bool]$e.manualAction }
  switch ([string]$e.status) {
    'COMPLETE' { if ([bool]$e.safeCompletion) { Emit-Event 'RESPONSE_GIVEN_CONFIRMED' 'INFO' $evidence 'The v2.4.0 fail-closed page monitor emitted COMPLETE with safeCompletion=true.' } else { Emit-Event 'UNSAFE_COMPLETE_EVENT_REJECTED_BY_DIAGNOSIS' 'ERROR' $evidence 'A COMPLETE bridge event lacked safeCompletion proof and is not treated as confirmed completion.' } }
    'WAITING_INPUT' { Emit-Event 'RESPONSE_GIVEN_WAITING_INPUT' 'INFO' $evidence 'A response was delivered and the page now appears to be waiting for user input.' }
    'PAUSED' { Emit-Event 'GENERATION_PAUSED_CONFIRMED' 'WARNING' $evidence 'Generation stopped below full progress, exposed a continuation condition, or crossed the long-run pause boundary without completion evidence.' }
    'STUCK_THINKING' { Emit-Event 'STUCK_THINKING_CONFIRMED' 'WARNING' $evidence 'The current assistant turn remained on Thinking for the configured threshold with no active Stop control.' }
    'TIMEOUT' { Emit-Event 'MESSAGE_TIMEOUT_CONFIRMED' 'ERROR' $evidence 'The page monitor observed an explicit message-delivery/network timeout. Completion was blocked.' }
    'UNCERTAIN' { Emit-Event 'COMPLETION_UNCERTAIN_CONFIRMED' 'WARNING' $evidence 'The response stopped without enough evidence to safely call it complete.' }
    'RECOVERY_FAILED' { Emit-Event 'SAFE_RECOVERY_FAILED' 'ERROR' $evidence 'The rate-limited safe recovery path could not clear the fault or was blocked.' }
    'FAILED' { Emit-Event 'RESPONSE_FAILED_CONFIRMED' 'ERROR' $evidence 'The page monitor observed a failure condition.' }
    'PAGE_STALE' { Emit-Event 'PAGE_STALE_CONFIRMED' 'ERROR' $evidence 'The page monitor found explicit stale-page evidence.' }
    'CONNECTION_LOST' { Emit-Event 'CONNECTION_LOST_CONFIRMED' 'ERROR' $evidence 'The browser reported loss of network connectivity.' }
    'RECOVERED' { Emit-Event 'GENERATION_RECOVERED_CONFIRMED' 'INFO' $evidence 'The notifier reattached after controlled recovery and observed changed response state.' }
    'MONITORING_RECOVERED' { Emit-Event 'MONITORING_RECOVERED_CONFIRMED' 'INFO' $evidence 'Monitoring or network connectivity recovered.' }
    'RUNNING' { Emit-Event 'GENERATION_RUNNING_CONFIRMED' 'INFO' $evidence 'The page monitor observed an active generation state.' }
  }
}

function Handle-TabStates($Bridge, $RuntimeState, $ChromeMetrics) {
  if (-not $Bridge -or -not $Bridge.browser) { return }
  $nowMs = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
  foreach ($tab in @($Bridge.browser.tabs)) {
    $id = [string]$tab.tabId
    if (-not $script:TabState.ContainsKey($id)) {
      $script:TabState[$id] = [ordered]@{ status=$null; runningSinceMs=$null; staleHeartbeatOpen=$false; discardOpen=$false; stallOpen=$false }
    }
    $state = $script:TabState[$id]
    $status = [string]$tab.status
    if ($status -ne [string]$state.status) {
      Emit-Event 'TAB_STATUS_TRANSITION' 'INFO' ([ordered]@{ tabId=$tab.tabId; from=$state.status; to=$status; heartbeatAgeSeconds=$tab.heartbeatAgeSeconds; lastStateChange=$tab.lastStateChange }) 'The notifier-reported generation state changed.'
      if ($status -eq 'RUNNING') { $state.runningSinceMs = $nowMs; $state.stallOpen = $false }
      elseif ($state.status -eq 'RUNNING') {
        if ($status -eq 'COMPLETE') { Emit-Event 'RUN_TO_RESPONSE_COMPLETION' 'INFO' @{ tabId=$tab.tabId; runDurationSeconds=if($state.runningSinceMs){[math]::Round(($nowMs-[long]$state.runningSinceMs)/1000.0,1)}else{$null} } 'A RUNNING state transitioned to COMPLETE.' }
        $state.runningSinceMs = $null
        $state.stallOpen = $false
      }
      $state.status = $status
    }

    $age = $null
    try { if ($null -ne $tab.heartbeatAgeSeconds) { $age = [double]$tab.heartbeatAgeSeconds } } catch {}
    if ($null -ne $age -and $age -gt 60) {
      if (-not $state.staleHeartbeatOpen) {
        $state.staleHeartbeatOpen = $true
        Emit-Event 'EXTENSION_HEARTBEAT_STALE_CONFIRMED' 'ERROR' @{ tabId=$tab.tabId; heartbeatAgeSeconds=$age; status=$status } 'The monitored tab stopped sending timely extension heartbeats.'
      }
    } elseif ($state.staleHeartbeatOpen) {
      $state.staleHeartbeatOpen = $false
      Emit-Event 'EXTENSION_HEARTBEAT_RECOVERED' 'INFO' @{ tabId=$tab.tabId; heartbeatAgeSeconds=$age; status=$status } 'The extension heartbeat became healthy again.'
    }

    if ([bool]$tab.discarded) {
      if (-not $state.discardOpen) {
        $state.discardOpen = $true
        Emit-Event 'TAB_DISCARDED_CONFIRMED' 'ERROR' @{ tabId=$tab.tabId; status=$status; protected=$tab.autoDiscardableProtected } 'Chrome reports that the monitored ChatGPT tab was discarded.'
      }
    } elseif ($state.discardOpen) {
      $state.discardOpen = $false
      Emit-Event 'TAB_DISCARD_RECOVERED' 'INFO' @{ tabId=$tab.tabId; status=$status } 'The tab is no longer reported as discarded.'
    }

    if ($status -eq 'RUNNING') {
      if (-not $state.runningSinceMs) { $state.runningSinceMs = $nowMs }
      $runningSeconds = ($nowMs - [long]$state.runningSinceMs) / 1000.0
      $cpuLow = ($null -ne $ChromeMetrics.normalizedCpuPercent -and [double]$ChromeMetrics.normalizedCpuPercent -lt 0.5)
      $heartbeatHealthy = ($null -ne $age -and $age -le 30)
      $lastEventAge = $null
      if ($Bridge.browser.lastEventAt) { $lastEventAge = ($nowMs - [long]$Bridge.browser.lastEventAt) / 1000.0 }
      if ($runningSeconds -ge $SuspectedStallSeconds -and $heartbeatHealthy -and $cpuLow -and ($null -eq $lastEventAge -or $lastEventAge -ge $SuspectedStallSeconds)) {
        if (-not $state.stallOpen) {
          $state.stallOpen = $true
          Emit-Event 'GENERATION_STALL_SUSPECTED' 'WARNING' ([ordered]@{ tabId=$tab.tabId; runningSeconds=[math]::Round($runningSeconds,1); heartbeatAgeSeconds=$age; normalizedChromeCpuPercent=$ChromeMetrics.normalizedCpuPercent; lastBridgeEventAgeSeconds=if($null-ne$lastEventAge){[math]::Round($lastEventAge,1)}else{$null}; chromeHung=if($RuntimeState){$RuntimeState.chromeHung}else{$null} }) 'Generation still reports RUNNING, but there has been no bridge event progress and Chrome activity is very low. This is a suspicion, not a false claim of a confirmed freeze.'
        }
      } elseif ($state.stallOpen -and (-not $cpuLow -or ($null -ne $lastEventAge -and $lastEventAge -lt 30))) {
        $state.stallOpen = $false
        Emit-Event 'GENERATION_ACTIVITY_RESUMED' 'INFO' @{ tabId=$tab.tabId; normalizedChromeCpuPercent=$ChromeMetrics.normalizedCpuPercent; lastBridgeEventAgeSeconds=$lastEventAge } 'Evidence of generation/browser activity resumed after a suspected stall.'
      }
    }
  }
}

function Handle-GlobalHealth($Bridge, $RuntimeState, $ChromeMetrics) {
  if ($Bridge) {
    if ($script:BridgeDownEventOpen) {
      $script:BridgeDownEventOpen = $false
      Emit-Event 'BRIDGE_RECOVERED_CONFIRMED' 'INFO' @{ version=$Bridge.version; tabCount=$Bridge.browser.tabCount } 'The local browser bridge became reachable again.'
    }
    $script:BridgeMisses = 0
  } else {
    $script:BridgeMisses++
    if ($script:BridgeMisses -ge 3 -and -not $script:BridgeDownEventOpen) {
      $script:BridgeDownEventOpen = $true
      Emit-Event 'BRIDGE_UNAVAILABLE_CONFIRMED' 'ERROR' @{ consecutiveMisses=$script:BridgeMisses; url=$bridgeUrl } 'The local bridge failed multiple consecutive one-second checks.'
    }
  }

  $hung = $false
  $alive = $null
  if ($RuntimeState) {
    try { $hung = [bool]$RuntimeState.chromeHung } catch {}
    try { $alive = [bool]$RuntimeState.chromeAlive } catch {}
  }
  if ($ChromeMetrics.managedProcessResponding -eq $false) { $hung = $true }
  if ($hung) {
    if (-not $script:ChromeHungEventOpen) {
      $script:ChromeHungEventOpen = $true
      Emit-Event 'CHROME_FROZEN_CONFIRMED' 'CRITICAL' @{ runtimeChromeHung=if($RuntimeState){$RuntimeState.chromeHung}else{$null}; managedProcessResponding=$ChromeMetrics.managedProcessResponding; managedPid=$ChromeMetrics.managedPid } 'Windows/notifier evidence says the managed Chrome window or process is hung/not responding.'
    }
  } elseif ($script:ChromeHungEventOpen) {
    $script:ChromeHungEventOpen = $false
    Emit-Event 'CHROME_HANG_RECOVERED' 'INFO' @{ managedPid=$ChromeMetrics.managedPid } 'The managed Chrome process/window is responsive again.'
  }

  if ($RuntimeState -and $alive -eq $false -and [bool]$RuntimeState.monitoringEnabled) {
    if (-not $script:ChromeMissingEventOpen) {
      $script:ChromeMissingEventOpen = $true
      Emit-Event 'MANAGED_CHROME_MISSING_CONFIRMED' 'ERROR' @{ recoveryStatus=$RuntimeState.recoveryStatus; monitoredTabs=$RuntimeState.monitoredTabs } 'Monitoring is enabled but the managed Chrome window is not alive.'
    }
  } elseif ($script:ChromeMissingEventOpen -and ($alive -eq $true)) {
    $script:ChromeMissingEventOpen = $false
    Emit-Event 'MANAGED_CHROME_RECOVERED' 'INFO' @{ recoveryStatus=if($RuntimeState){$RuntimeState.recoveryStatus}else{$null} } 'The managed Chrome window became alive again.'
  }
}

function Write-Summary($Bridge, $RuntimeState, $ChromeMetrics) {
  $tabs = @()
  if ($Bridge -and $Bridge.browser) {
    foreach ($t in @($Bridge.browser.tabs)) {
      $tabs += [ordered]@{ tabId=$t.tabId; status=$t.status; monitoringState=$t.monitoringState; heartbeatAgeSeconds=$t.heartbeatAgeSeconds; discarded=$t.discarded; protected=$t.autoDiscardableProtected }
    }
  }
  $summary = [ordered]@{
    schemaVersion = 1
    loggerVersion = $LoggerVersion
    sessionId = $sessionId
    updatedAtUtc = Get-UtcIso
    latestClassification = $script:LatestClassification
    sourceIntegrityVerified = $script:IntegrityOk
    sourceIntegrityFailures = @($script:IntegrityFailures)
    eventCounts = $script:EventCounts
    bridgeOnline = [bool]$Bridge
    bridgeVersion = if($Bridge){$Bridge.version}else{$null}
    bridgeLastEvent = if($Bridge -and $Bridge.browser){$Bridge.browser.lastEvent}else{$null}
    runtime = if($RuntimeState){[ordered]@{ monitoringEnabled=$RuntimeState.monitoringEnabled; awakeProtection=$RuntimeState.awakeProtection; chromeAlive=$RuntimeState.chromeAlive; chromeHung=$RuntimeState.chromeHung; chromeProcessId=$RuntimeState.chromeProcessId; bridgeOnline=$RuntimeState.bridgeOnline; monitoredTabs=$RuntimeState.monitoredTabs; recoveryStatus=$RuntimeState.recoveryStatus }}else{$null}
    chrome = $ChromeMetrics
    tabs = $tabs
    evidenceFiles = [ordered]@{ events='events.ndjson'; snapshots='snapshots.ndjson'; health='health.ndjson'; errors='errors.ndjson'; session='session.json'; releaseIntegrity='RELEASE_SHA256.txt'; historicalBaseline='FROZEN_ORIGINAL_SHA256_v2.1.1.txt' }
    interpretation = [ordered]@{
      responseGiven = 'RESPONSE_GIVEN_CONFIRMED is emitted only when the notifier reports COMPLETE with safeCompletion=true.'
      confirmedFreeze = 'CHROME_FROZEN_CONFIRMED requires Windows/notifier hung evidence. PAGE_STALE_CONFIRMED and EXTENSION_HEARTBEAT_STALE_CONFIRMED are separate confirmed failure modes.'
      suspectedStall = 'GENERATION_STALL_SUSPECTED is deliberately non-definitive because a long server-side response can legitimately have low local Chrome CPU activity.'
      contentPrivacy = 'Prompt and response bodies, URLs, and conversation IDs are not copied. Operational state transitions, timings, process health, and failure evidence are recorded.'
    }
  }
  try { [System.IO.File]::WriteAllText($summaryFile, ($summary | ConvertTo-Json -Depth 16), [System.Text.UTF8Encoding]::new($false)) } catch {}
}

$sessionInfo = [ordered]@{
  schemaVersion=1
  loggerVersion=$LoggerVersion
  sessionId=$sessionId
  startedAtUtc=Get-UtcIso
  computerName=$env:COMPUTERNAME
  powershellVersion=$PSVersionTable.PSVersion.ToString()
  sampleSeconds=$SampleSeconds
  healthSeconds=$HealthSeconds
  suspectedStallSeconds=$SuspectedStallSeconds
  runtimeBase=$runtimeBase
  root=$root
  privacy='No prompt or assistant response body text is collected by this sidecar.'
}
[System.IO.File]::WriteAllText($sessionFile, ($sessionInfo | ConvertTo-Json -Depth 6), [System.Text.UTF8Encoding]::new($false))
Emit-Event 'LOGGER_STARTED' 'INFO' @{ sessionId=$sessionId; loggerVersion=$LoggerVersion; sampleSeconds=$SampleSeconds; healthSeconds=$HealthSeconds } 'Advanced flight-recorder sidecar started.'
Verify-ReleaseIntegrity

# Capture logger and source artifacts used for diagnosis.
try { Copy-Item -LiteralPath $manifestPath -Destination (Join-Path $sessionDir 'RELEASE_SHA256.txt') -Force } catch {}
try { if (Test-Path -LiteralPath $historicalManifestPath) { Copy-Item -LiteralPath $historicalManifestPath -Destination (Join-Path $sessionDir 'FROZEN_ORIGINAL_SHA256_v2.1.1.txt') -Force } } catch {}
try { Copy-Item -LiteralPath (Join-Path $loggerDir 'CODEX_DIAGNOSIS_GUIDE.md') -Destination (Join-Path $sessionDir 'CODEX_DIAGNOSIS_GUIDE.md') -Force } catch {}

while ($true) {
  try {
    if (Test-Path -LiteralPath $stopFile) {
      Emit-Event 'LOGGER_STOP_REQUESTED' 'INFO' @{ stopFile=$stopFile } 'A stop request file was detected.'
      break
    }

    $bridge = Get-BridgeState
    $runtime = Read-JsonFile $runtimeStateFile
    $chrome = Get-ChromeMetrics $runtime

    Handle-GlobalHealth $bridge $runtime $chrome
    Handle-BridgeEvent $bridge
    Handle-TabStates $bridge $runtime $chrome

    $snapshot = [ordered]@{
      bridge = $bridge
      runtime = $runtime
      chrome = $chrome
      logger = [ordered]@{ bridgeConsecutiveMisses=$script:BridgeMisses; latestClassification=$script:LatestClassification }
    }
    Write-Ndjson $snapshotsFile 'STATE_SNAPSHOT' $snapshot

    $now = [DateTimeOffset]::UtcNow
    if (($now - $script:LastHealthUtc).TotalSeconds -ge $HealthSeconds) {
      $script:LastHealthUtc = $now
      Write-Ndjson $healthFile 'SYSTEM_HEALTH' (Get-SystemHealth $runtime $chrome)
      Capture-FileChange 'runtime-state.json' $runtimeStateFile ([ref]$script:LastRuntimeHash)
      Capture-FileChange 'settings.json' $settingsFile ([ref]$script:LastSettingsHash)
      Capture-FileChange 'managed-window.json' $managedStateFile ([ref]$script:LastManagedHash)
      Capture-TrayLogTail
      if (($now - $script:LastEventLogUtc).TotalSeconds -ge 30) { Capture-WindowsEvents }
    }

    Write-Summary $bridge $runtime $chrome
  } catch { Write-Error 'MainLoop' $_ }
  Start-Sleep -Seconds $SampleSeconds
}

try {
  $bridge = Get-BridgeState
  $runtime = Read-JsonFile $runtimeStateFile
  $chrome = Get-ChromeMetrics $runtime
  Write-Summary $bridge $runtime $chrome
  Emit-Event 'LOGGER_STOPPED' 'INFO' @{ sessionId=$sessionId } 'Advanced flight-recorder sidecar stopped cleanly.'
} catch {}
